import React from "react";
import { BrowserRouter, Navigate, Outlet, Route, Routes } from "react-router-dom";
import { Toaster } from "sonner";
import { CaseStoreProvider } from "./contexts/CaseStore";
import { SessionProvider, useSession } from "./contexts/SessionContext";
import { BranchProvider } from "./contexts/BranchContext";
import { TaskStoreProvider } from "./contexts/TaskStore";
import { AppLayout } from "./components/layout/AppLayout";
import { Login } from "./pages/Login";
import { Dashboard } from "./pages/Dashboard";
import { DonorCases } from "./pages/DonorCases";
import { NewDonorCase } from "./pages/NewDonorCase";
import { CaseDetail } from "./pages/CaseDetail";
import { CornealAssessment } from "./pages/CornealAssessment";
import { AiAnalysis } from "./pages/AiAnalysis";
import { TransplantDecisionSupport } from "./pages/TransplantDecisionSupport";
import { FollowUp } from "./pages/FollowUp";
import { Reports } from "./pages/Reports";
import { AuditHistory } from "./pages/AuditHistory";
import { Settings } from "./pages/Settings";
import { MyWork } from "./pages/MyWork";
import { Inventory } from "./pages/Inventory";
import { Recipients } from "./pages/Recipients";
import { PostTransplant } from "./pages/PostTransplant";

function RequireSession() {
  const { user } = useSession();
  if (!user) return <Navigate to="/login" replace />;
  return <AppLayout />;
}

function RequireRole({ roles }: { roles: string[] }) {
  const { role } = useSession();
  if (!role || !roles.includes(role)) return <Navigate to="/" replace />;
  return <Outlet />;
}

export function App() {
  return (
    <SessionProvider>
      <CaseStoreProvider>
        <BranchProvider>
          <TaskStoreProvider>
            <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
              <Routes>
                <Route path="/login" element={<Login />} />
                <Route element={<RequireSession />}>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/my-work" element={<MyWork />} />
                  <Route path="/inventory" element={<Inventory />} />
                  <Route path="/recipients" element={<Recipients />} />
                  <Route path="/post-transplant" element={<PostTransplant />} />
                  <Route path="/cases" element={<DonorCases />} />
                  <Route path="/cases/new" element={<NewDonorCase />} />
                  <Route path="/cases/:caseId" element={<CaseDetail />} />
                  <Route path="/assessment" element={<CornealAssessment />} />
                  <Route path="/assessment/:caseId" element={<CornealAssessment />} />
                  <Route path="/analysis" element={<AiAnalysis />} />
                  <Route path="/analysis/:caseId" element={<AiAnalysis />} />
                  {/* Doctor / Specialist only */}
                  <Route element={<RequireRole roles={["Doctor", "Admin", "Manager"]} />}>
                    <Route path="/review" element={<TransplantDecisionSupport />} />
                    <Route path="/review/:caseId" element={<TransplantDecisionSupport />} />
                  </Route>
                  <Route path="/decision" element={<Navigate to="/review" replace />} />
                  <Route path="/decision/:caseId" element={<Navigate to="/review" replace />} />
                  <Route path="/follow-up" element={<FollowUp />} />
                  <Route path="/follow-up/:caseId" element={<FollowUp />} />
                  <Route path="/reports" element={<Reports />} />
                  <Route path="/reports/:caseId" element={<Reports />} />
                  <Route path="/audit" element={<AuditHistory />} />
                  <Route path="/settings" element={<Settings />} />
                  <Route path="*" element={<Navigate to="/" replace />} />
                </Route>
              </Routes>
            </BrowserRouter>
            <Toaster position="bottom-right" toastOptions={{ className: "text-sm" }} />
          </TaskStoreProvider>
        </BranchProvider>
      </CaseStoreProvider>
    </SessionProvider>
  );
}
