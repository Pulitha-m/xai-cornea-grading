import React, { createContext, useCallback, useContext, useMemo, useState } from "react";
import { demoAuditLog, demoCases, emptyModuleResult } from "../data/cases";
import { getModuleName, moduleRegistry } from "../data/moduleRegistry";
import type { AuditEntry, ClinicalNote, DonorCase, FollowUpPoint, ModuleStatus, ReviewStatus, SpecialistDecision, DonorStatus, CorneaStatus, HandoffEntry } from "../types/case";
import { formatTimestamp } from "../utils/format";
import { canTransitionCornea, canTransitionDonor } from "../utils/caseTransitions";
import { useSession } from "./SessionContext";

interface CaseStoreValue {
  cases: DonorCase[];
  auditLog: AuditEntry[];
  currentUser: string;
  getCase: (caseId: string | undefined) => DonorCase | undefined;
  createCase: (donorCase: DonorCase) => void;
  runModule: (caseId: string, moduleId: string) => void;
  recordSpecialistDecision: (caseId: string, decision: SpecialistDecision) => void;
  addNote: (caseId: string, body: string) => void;
  recordFollowUp: (caseId: string, point: FollowUpPoint) => void;
  setReviewStatus: (caseId: string, status: ReviewStatus) => void;
  assignReviewer: (caseId: string, reviewer: string | null) => void;
  logEvent: (entry: Omit<AuditEntry, "id" | "timestamp">) => void;
  updateCaseStatus: (caseId: string, donorStatus: DonorStatus, corneaStatus: CorneaStatus) => boolean;
  recordHandoff: (caseId: string, handoff: HandoffEntry) => void;
}

const CaseStoreContext = createContext<CaseStoreValue | null>(null);

let auditSeq = 1000;

export function CaseStoreProvider({ children }: { children: React.ReactNode }) {
  const [cases, setCases] = useState<DonorCase[]>(demoCases);
  const [auditLog, setAuditLog] = useState<AuditEntry[]>(demoAuditLog);
  const { user } = useSession();
  const currentUser = user?.displayName ?? "Unauthenticated session";

  const logEvent = useCallback((entry: Omit<AuditEntry, "id" | "timestamp">) => {
    auditSeq += 1;
    setAuditLog((prev) => [{ ...entry, id: `a-${auditSeq}`, timestamp: new Date().toISOString() }, ...prev]);
  }, []);

  const patchCase = useCallback((caseId: string, patch: (c: DonorCase) => DonorCase) => {
    setCases((prev) => prev.map((c) => (c.caseId === caseId ? patch(c) : c)));
  }, []);

  const getCase = useCallback((caseId: string | undefined) => cases.find((c) => c.caseId === caseId), [cases]);

  const createCase = useCallback(
    (donorCase: DonorCase) => {
      setCases((prev) => [donorCase, ...prev]);
      logEvent({
        caseId: donorCase.caseId,
        module: "Case Management",
        action: "Case created",
        status: "Completed",
        user: currentUser,
        resultVersion: null,
      });
    },
    [currentUser, logEvent],
  );

  const setModuleStatus = useCallback(
    (caseId: string, moduleId: string, status: ModuleStatus, statusNote?: string) => {
      patchCase(caseId, (c) => {
        const existing = c.modules[moduleId] ?? emptyModuleResult(moduleId);
        return {
          ...c,
          lastUpdated: new Date().toISOString(),
          modules: {
            ...c.modules,
            [moduleId]: {
              ...existing,
              status,
              statusNote: statusNote ?? existing.statusNote,
              lastRun: status === "Running" ? new Date().toISOString() : existing.lastRun,
            },
          },
        };
      });
    },
    [patchCase],
  );

  const runModule = useCallback(
    (caseId: string, moduleId: string) => {
      const definition = moduleRegistry.find((m) => m.id === moduleId);
      setModuleStatus(caseId, moduleId, "Running", "Run requested — awaiting module response.");
      logEvent({
        caseId,
        module: getModuleName(moduleId),
        action: "Analysis run requested",
        status: "Running",
        user: currentUser,
        resultVersion: null,
      });

      window.setTimeout(() => {
        if (definition && !definition.modelConnected) {
          setModuleStatus(caseId, moduleId, "Unavailable", "Analysis not yet connected — no model endpoint is registered for this module. No result was written to the case.");
          logEvent({
            caseId,
            module: getModuleName(moduleId),
            action: "Analysis unavailable — model endpoint not connected",
            status: "Unavailable",
            user: "System",
            resultVersion: null,
          });
        }
      }, 1800);
    },
    [currentUser, logEvent, setModuleStatus],
  );

  const recordSpecialistDecision = useCallback(
    (caseId: string, decision: SpecialistDecision) => {
      patchCase(caseId, (c) => ({
        ...c,
        specialistDecision: decision,
        reviewStatus: "Specialist Reviewed",
        corneaStatus: decision.outcome === "Suitable" ? "Available" : "Not Suitable",
        donorStatus: "Evaluated",
        lastUpdated: new Date().toISOString(),
      }));
      logEvent({
        caseId,
        module: "Specialist Review",
        action: `Specialist decision recorded — ${decision.outcome}`,
        status: "Completed",
        user: decision.decidedBy,
        resultVersion: null,
      });
    },
    [logEvent, patchCase],
  );

  const addNote = useCallback(
    (caseId: string, body: string) => {
      const note: ClinicalNote = {
        id: `n-${Date.now()}`,
        author: currentUser,
        createdAt: new Date().toISOString(),
        body,
      };
      patchCase(caseId, (c) => ({
        ...c,
        notes: [note, ...c.notes],
        lastUpdated: new Date().toISOString(),
      }));
      logEvent({
        caseId,
        module: "Specialist Review",
        action: "Clinical note added",
        status: "Completed",
        user: currentUser,
        resultVersion: null,
      });
    },
    [currentUser, logEvent, patchCase],
  );

  const recordFollowUp = useCallback(
    (caseId: string, point: FollowUpPoint) => {
      patchCase(caseId, (c) => ({
        ...c,
        followUp: c.followUp.map((existing) => (existing.label === point.label ? point : existing)),
        lastUpdated: new Date().toISOString(),
      }));
      logEvent({
        caseId,
        module: "Post-Transplant Follow-up",
        action: `${point.label} measurements recorded`,
        status: "Completed",
        user: currentUser,
        resultVersion: null,
      });
    },
    [currentUser, logEvent, patchCase],
  );

  const setReviewStatus = useCallback(
    (caseId: string, status: ReviewStatus) => {
      patchCase(caseId, (c) => ({ ...c, reviewStatus: status, lastUpdated: new Date().toISOString() }));
      logEvent({
        caseId,
        module: "Case Management",
        action: `Review status changed to ${status}`,
        status: "Completed",
        user: currentUser,
        resultVersion: null,
      });
    },
    [currentUser, logEvent, patchCase],
  );

  const assignReviewer = useCallback(
    (caseId: string, reviewer: string | null) => {
      patchCase(caseId, (c) => ({
        ...c,
        assignedReviewer: reviewer,
        lastUpdated: new Date().toISOString(),
      }));
      logEvent({
        caseId,
        module: "Case Management",
        action: reviewer ? `Reviewer assigned — ${reviewer}` : "Reviewer unassigned",
        status: "Completed",
        user: currentUser,
        resultVersion: null,
      });
    },
    [currentUser, logEvent, patchCase],
  );

  const updateCaseStatus = useCallback(
    (caseId: string, donorStatus: DonorStatus, corneaStatus: CorneaStatus) => {
      const existingCase = cases.find((c) => c.caseId === caseId);
      if (!existingCase || !user || !canTransitionDonor(user.role, existingCase.donorStatus, donorStatus) || !canTransitionCornea(user.role, existingCase.corneaStatus, corneaStatus)) {
        logEvent({
          caseId,
          module: "Case Management",
          action: "Invalid or unauthorized status transition blocked",
          status: "Failed",
          user: currentUser,
          resultVersion: null,
        });
        return false;
      }
      patchCase(caseId, (c) => ({
        ...c,
        donorStatus,
        corneaStatus,
        lastUpdated: new Date().toISOString(),
      }));
      logEvent({
        caseId,
        module: "Case Management",
        action: `Statuses updated: Donor=${donorStatus}, Cornea=${corneaStatus}`,
        status: "Completed",
        user: currentUser,
        resultVersion: null,
      });
      return true;
    },
    [cases, currentUser, logEvent, patchCase, user],
  );

  const recordHandoff = useCallback(
    (caseId: string, handoff: HandoffEntry) => {
      const existingCase = cases.find((c) => c.caseId === caseId);
      if (!existingCase || !user || existingCase.branch !== handoff.branch || !user.allowedBranches.includes(handoff.branch)) {
        logEvent({
          caseId,
          module: "Case Management",
          action: "Unauthorized cross-branch handoff blocked",
          status: "Failed",
          user: currentUser,
          resultVersion: null,
        });
        return;
      }
      patchCase(caseId, (c) => ({
        ...c,
        handoffHistory: [handoff, ...(c.handoffHistory || [])],
        ownership: {
          ...c.ownership,
          currentUser: handoff.toUser,
          currentRole: handoff.toRole,
          nextAction: handoff.note,
        },
        lastUpdated: new Date().toISOString(),
      }));
      logEvent({
        caseId,
        module: "Case Management",
        action: `Case handed off from ${handoff.fromRole} to ${handoff.toRole}`,
        status: "Completed",
        user: currentUser,
        resultVersion: null,
      });
    },
    [cases, currentUser, logEvent, patchCase, user],
  );

  const value = useMemo<CaseStoreValue>(
    () => ({
      cases,
      auditLog,
      currentUser,
      getCase,
      createCase,
      runModule,
      recordSpecialistDecision,
      addNote,
      recordFollowUp,
      setReviewStatus,
      assignReviewer,
      logEvent,
      updateCaseStatus,
      recordHandoff,
    }),
    [cases, auditLog, currentUser, getCase, createCase, runModule, recordSpecialistDecision, addNote, recordFollowUp, setReviewStatus, assignReviewer, logEvent, updateCaseStatus, recordHandoff],
  );

  return <CaseStoreContext.Provider value={value}>{children}</CaseStoreContext.Provider>;
}

export function useCaseStore(): CaseStoreValue {
  const ctx = useContext(CaseStoreContext);
  if (!ctx) throw new Error("useCaseStore must be used within CaseStoreProvider");
  return ctx;
}

export { formatTimestamp };
