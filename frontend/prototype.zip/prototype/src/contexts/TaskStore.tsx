import React, { createContext, useContext, useState } from 'react';
import type { Branch, Role } from '../types/user';

export type TaskPriority = 'Urgent' | 'High' | 'Normal' | 'Low';
export type TaskStatus = 'Pending' | 'In Progress' | 'Waiting' | 'Completed' | 'Cancelled';
export type TaskCategory =
  | 'Intake'
  | 'Collection'
  | 'Imaging'
  | 'Review'
  | 'Transport'
  | 'Storage'
  | 'Delivery'
  | 'Transplant';

export interface TaskItem {
  id: string;
  title: string;
  caseId?: string;
  branch: Branch;
  priority: TaskPriority;
  dueDate: string;
  assignedRole: Role;
  assignedPerson?: string;
  status: TaskStatus;
  category: TaskCategory;
  notes?: string;
}

const INITIAL_TASKS: TaskItem[] = [
  {
    id: 'TSK-101',
    title: 'Collect donor tissue from Ward 4 ICU',
    caseId: 'NEB-2026-00125',
    branch: 'Colombo',
    priority: 'Urgent',
    dueDate: 'Today, 11:30 AM',
    assignedRole: 'Nurse',
    assignedPerson: 'K. Fernando',
    status: 'Pending',
    category: 'Collection',
    notes: 'Preservation fluid box ready at station',
  },
  {
    id: 'TSK-102',
    title: 'Upload specular microscopy image & quality check',
    caseId: 'NEB-2026-00125',
    branch: 'Colombo',
    priority: 'High',
    dueDate: 'Today, 12:00 PM',
    assignedRole: 'Nurse',
    assignedPerson: 'K. Fernando',
    status: 'In Progress',
    category: 'Imaging',
    notes: 'Capture device: Konan CellChek XL',
  },
  {
    id: 'TSK-103',
    title: 'Clinical AI evaluation sign-off',
    caseId: 'NEB-2026-00125',
    branch: 'Colombo',
    priority: 'Urgent',
    dueDate: 'Today, 02:00 PM',
    assignedRole: 'Doctor',
    assignedPerson: 'Dr. A. Perera',
    status: 'Pending',
    category: 'Review',
    notes: 'ECD 2,650 cells/mm² (Suitable for DALK/EK)',
  },
  {
    id: 'TSK-104',
    title: 'Prepare tissue transport container for Kandy transfer',
    caseId: 'NEB-2026-00124',
    branch: 'Colombo',
    priority: 'Urgent',
    dueDate: 'Today, 01:15 PM',
    assignedRole: 'Attendant',
    assignedPerson: 'S. Bandara',
    status: 'Pending',
    category: 'Transport',
    notes: 'Maintain temperature between 2°C – 8°C',
  },
  {
    id: 'TSK-105',
    title: 'Approve inter-branch tissue allocation to Kandy General',
    caseId: 'NEB-2026-00124',
    branch: 'Colombo',
    priority: 'High',
    dueDate: 'Today, 03:00 PM',
    assignedRole: 'Manager',
    assignedPerson: 'H. Jayawardena',
    status: 'Pending',
    category: 'Storage',
    notes: 'Recipient match score 94.2%',
  },
  {
    id: 'TSK-106',
    title: 'Move tissue NEB-2026-00122 to cold storage Bay B3',
    caseId: 'NEB-2026-00122',
    branch: 'Kandy',
    priority: 'Normal',
    dueDate: 'Today, 04:30 PM',
    assignedRole: 'Attendant',
    assignedPerson: 'P. Wickrama',
    status: 'In Progress',
    category: 'Storage',
    notes: 'Optisol-GS medium checked',
  },
  {
    id: 'TSK-107',
    title: 'Conduct 1-month post-transplant follow-up evaluation',
    caseId: 'NEB-2026-00120',
    branch: 'Kurunegala',
    priority: 'Normal',
    dueDate: 'Tomorrow, 09:00 AM',
    assignedRole: 'Doctor',
    assignedPerson: 'Dr. S. Wijesinghe',
    status: 'Pending',
    category: 'Transplant',
    notes: 'Check endothelial cell loss trajectory',
  },
  {
    id: 'TSK-108',
    title: 'Verify system audit log integrity for Q3 compliance',
    branch: 'Colombo',
    priority: 'Low',
    dueDate: 'In 2 days',
    assignedRole: 'Admin',
    assignedPerson: 'R. Gunasekara',
    status: 'Pending',
    category: 'Review',
    notes: 'Generate automated PDF summary',
  },
];

interface TaskStoreValue {
  tasks: TaskItem[];
  updateTaskStatus: (taskId: string, status: TaskStatus) => void;
  addTask: (task: Omit<TaskItem, 'id'>) => void;
}

const TaskStoreContext = createContext<TaskStoreValue | undefined>(undefined);

export function TaskStoreProvider({ children }: { children: React.ReactNode }) {
  const [tasks, setTasks] = useState<TaskItem[]>(INITIAL_TASKS);

  const updateTaskStatus = (taskId: string, status: TaskStatus) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, status } : t))
    );
  };

  const addTask = (newTask: Omit<TaskItem, 'id'>) => {
    const id = `TSK-${Math.floor(100 + Math.random() * 900)}`;
    setTasks((prev) => [{ ...newTask, id }, ...prev]);
  };

  return (
    <TaskStoreContext.Provider value={{ tasks, updateTaskStatus, addTask }}>
      {children}
    </TaskStoreContext.Provider>
  );
}

export function useTaskStore() {
  const ctx = useContext(TaskStoreContext);
  if (!ctx) throw new Error('useTaskStore must be used within TaskStoreProvider');
  return ctx;
}
