import React, { createContext, useContext, useState, useEffect } from "react";
import type { Branch } from "../types/user";
import { useSession } from "./SessionContext";

export type BranchFilter = "All Branches" | Branch;

interface BranchContextValue {
  activeBranch: BranchFilter;
  setActiveBranch: (branch: BranchFilter) => void;
  filterByBranch: <T extends { branch?: Branch }>(items: T[]) => T[];
  canAccessBranch: (branch: Branch) => boolean;
}

const BranchContext = createContext<BranchContextValue | undefined>(undefined);

export function BranchProvider({ children }: { children: React.ReactNode }) {
  const { user } = useSession();
  const [activeBranch, setActiveBranch] = useState<BranchFilter>("All Branches");
  const allowedBranches = user?.allowedBranches ?? [];

  const changeActiveBranch = (branch: BranchFilter) => {
    if (branch === "All Branches") {
      if (user?.role === "Admin" || allowedBranches.length > 1) setActiveBranch(branch);
      return;
    }
    if (user?.role === "Admin" || allowedBranches.includes(branch)) setActiveBranch(branch);
  };

  // Sync user's default branch on login if restricted
  useEffect(() => {
    if (user && user.role !== "Admin") {
      if (allowedBranches.length === 1) {
        setActiveBranch(allowedBranches[0]);
      } else if (activeBranch !== "All Branches" && !allowedBranches.includes(activeBranch)) {
        setActiveBranch("All Branches");
      }
    }
  }, [activeBranch, allowedBranches, user]);

  const canAccessBranch = (branch: Branch): boolean => {
    if (!user) return false;
    if (user.role === "Admin") return true;
    return allowedBranches.includes(branch);
  };

  const filterByBranch = <T extends { branch?: Branch }>(items: T[]): T[] => {
    if (activeBranch === "All Branches") {
      // Filter out any branch user does not have permission to view
      if (!user || user.role === "Admin") return items;
      return items.filter((item) => !item.branch || allowedBranches.includes(item.branch));
    }
    if (user && user.role !== "Admin" && !allowedBranches.includes(activeBranch)) return [];
    return items.filter((item) => item.branch === activeBranch);
  };

  return <BranchContext.Provider value={{ activeBranch, setActiveBranch: changeActiveBranch, filterByBranch, canAccessBranch }}>{children}</BranchContext.Provider>;
}

export function useBranch() {
  const context = useContext(BranchContext);
  if (!context) {
    throw new Error("useBranch must be used within a BranchProvider");
  }
  return context;
}
