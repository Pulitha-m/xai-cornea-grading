import React, { createContext, useCallback, useContext, useMemo, useState, useEffect } from "react";
import { DEMO_STAFF } from "../data/staff";
import type { Role, StaffUser } from "../types/user";
import type { Action, Resource } from "../utils/permissions";
import { hasPermission } from "../utils/permissions";

interface SessionValue {
  user: StaffUser | null;
  role: Role | null;
  signIn: (staffId: string, role: Role) => void;
  signOut: () => void;
  can: (resource: Resource, action: Action) => boolean;
}

const SessionContext = createContext<SessionValue | null>(null);

export function SessionProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<StaffUser | null>(() => {
    try {
      const saved = localStorage.getItem("neb_session_user");
      if (saved) {
        const parsed = JSON.parse(saved) as Partial<StaffUser>;
        const profile = parsed.role ? DEMO_STAFF[parsed.role] : undefined;
        if (profile) {
          return {
            ...profile,
            ...parsed,
            allowedBranches: parsed.allowedBranches ?? profile.allowedBranches,
          };
        }
      }
    } catch {
      // ignore
    }
    return null;
  });

  useEffect(() => {
    try {
      if (user) localStorage.setItem("neb_session_user", JSON.stringify(user));
      else localStorage.removeItem("neb_session_user");
    } catch {
      // ignore
    }
  }, [user]);

  const signIn = useCallback((staffId: string, role: Role) => {
    const profile = DEMO_STAFF[role] || DEMO_STAFF.Admin;
    const trimmed = staffId.trim();
    setUser({ ...profile, staffId: trimmed || profile.staffId });
  }, []);

  const signOut = useCallback(() => setUser(null), []);

  const can = useCallback((resource: Resource, action: Action) => hasPermission(user?.role ?? null, resource, action), [user]);

  const value = useMemo<SessionValue>(() => ({ user, role: user?.role ?? null, signIn, signOut, can }), [user, signIn, signOut, can]);

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export function useSession(): SessionValue {
  const ctx = useContext(SessionContext);
  if (!ctx) throw new Error("useSession must be used within SessionProvider");
  return ctx;
}
