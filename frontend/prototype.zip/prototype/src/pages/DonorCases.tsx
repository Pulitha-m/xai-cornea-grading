import React, { useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { PlusIcon, SearchIcon, XIcon, EyeIcon } from 'lucide-react';
import { useCaseStore } from '../contexts/CaseStore';
import { useSession } from '../contexts/SessionContext';
import { PageHeader } from '../components/ui/PageHeader';
import { Panel } from '../components/ui/Panel';
import { Button } from '../components/ui/Button';
import { StatusBadge } from '../components/ui/StatusBadge';
import { ReviewBadge } from '../components/ui/ReviewBadge';
import { GradeBadge } from '../components/ui/GradeBadge';
import { EmptyState } from '../components/ui/EmptyState';
import { tableClass, tdClass, thClass, theadClass, trClass } from '../components/ui/tableStyles';
import { analysisProgress, diseaseAssessment, predictedGrade } from '../utils/caseHelpers';
import { formatDate, formatDateTime } from '../utils/format';

const selectClass =
  'h-10 rounded-2xl border border-slate-200 bg-slate-50 px-3 text-xs font-semibold text-slate-800 focus:border-sky-500 focus:bg-surface focus:outline-none transition-all';

export function DonorCases() {
  const { cases } = useCaseStore();
  const { can } = useSession();
  const [searchParams] = useSearchParams();
  const [query, setQuery] = useState(searchParams.get('q') ?? '');
  const [fromDate, setFromDate] = useState('');
  const [grade, setGrade] = useState('all');
  const [review, setReview] = useState('all');
  const [analysis, setAnalysis] = useState('all');

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return cases.filter((donorCase) => {
      if (
        term &&
        !donorCase.caseId.toLowerCase().includes(term) &&
        !donorCase.donor.donorId.toLowerCase().includes(term)
      )
        return false;
      if (fromDate && donorCase.donor.collectionDate < fromDate) return false;
      if (grade !== 'all' && predictedGrade(donorCase) !== grade) return false;
      if (review !== 'all' && donorCase.reviewStatus !== review) return false;
      if (analysis !== 'all' && analysisProgress(donorCase).status !== analysis) return false;
      return true;
    });
  }, [cases, query, fromDate, grade, review, analysis]);

  const filtersActive =
    query !== '' || fromDate !== '' || grade !== 'all' || review !== 'all' || analysis !== 'all';

  const clearFilters = () => {
    setQuery('');
    setFromDate('');
    setGrade('all');
    setReview('all');
    setAnalysis('all');
  };

  return (
    <div className="space-y-6 pb-12">
      <PageHeader
        eyebrow="Donor Database"
        title="Donor Cornea Cases"
        description="Search, filter, and inspect donor tissue records. AI grade predictions &amp; endothelial microscopy metrics are decision support tools for specialist sign-off."
        actions={
          can('Donor', 'create') ? (
            <Link to="/cases/new">
              <Button variant="primary" size="md">
                <PlusIcon className="h-4 w-4" />
                New Donor Case
              </Button>
            </Link>
          ) : undefined
        }
      />

      <Panel flush>
        {/* Search & Filter Bar */}
        <div className="flex flex-wrap items-end gap-3 border-b border-slate-100 p-6 bg-slate-50/40">
          <div className="relative min-w-[15rem] flex-1">
            <label htmlFor="case-search" className="mb-1.5 block text-2xs font-bold uppercase tracking-wider text-slate-400">
              Search Case ID / Donor ID
            </label>
            <SearchIcon className="pointer-events-none absolute left-3.5 top-[2.2rem] h-4 w-4 text-slate-400" />
            <input
              id="case-search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g. NEB-2026-000123"
              className="h-10 w-full rounded-2xl border border-slate-200 bg-surface pl-10 pr-4 font-mono text-xs text-slate-900 placeholder:text-slate-400 focus:border-sky-500 focus:outline-none transition-all"
            />
          </div>

          <div>
            <label htmlFor="from-date" className="mb-1.5 block text-2xs font-bold uppercase tracking-wider text-slate-400">
              Collection Date From
            </label>
            <input
              id="from-date"
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className={selectClass}
            />
          </div>

          <div>
            <label htmlFor="grade-filter" className="mb-1.5 block text-2xs font-bold uppercase tracking-wider text-slate-400">
              Predicted Grade
            </label>
            <select id="grade-filter" value={grade} onChange={(e) => setGrade(e.target.value)} className={selectClass}>
              <option value="all">All Grades</option>
              <option value="A+">A+</option>
              <option value="A">A</option>
              <option value="B">B</option>
            </select>
          </div>

          <div>
            <label htmlFor="review-filter" className="mb-1.5 block text-2xs font-bold uppercase tracking-wider text-slate-400">
              Review Status
            </label>
            <select id="review-filter" value={review} onChange={(e) => setReview(e.target.value)} className={selectClass}>
              <option value="all">All Review States</option>
              <option value="Pending Review">Pending Review</option>
              <option value="Under Review">Under Review</option>
              <option value="Specialist Reviewed">Specialist Reviewed</option>
              <option value="Awaiting Information">Awaiting Information</option>
            </select>
          </div>

          <div>
            <label htmlFor="analysis-filter" className="mb-1.5 block text-2xs font-bold uppercase tracking-wider text-slate-400">
              AI Analysis Status
            </label>
            <select
              id="analysis-filter"
              value={analysis}
              onChange={(e) => setAnalysis(e.target.value)}
              className={selectClass}>
              <option value="all">All Analysis States</option>
              <option value="Not Run">Not Run</option>
              <option value="Running">Running</option>
              <option value="Partial">Partial</option>
              <option value="Needs Review">Needs Review</option>
              <option value="Completed">Completed</option>
            </select>
          </div>

          {filtersActive && (
            <Button onClick={clearFilters} variant="ghost">
              <XIcon className="h-4 w-4" />
              Clear
            </Button>
          )}
        </div>

        <div className="flex items-center justify-between px-6 py-3 border-b border-slate-100 text-2xs text-slate-500 bg-slate-50/20">
          <span>
            Showing <strong className="font-bold text-slate-900">{filtered.length}</strong> of {cases.length} donor cases
          </span>
          <span className="font-semibold text-sky-700">National Eye Bank Database</span>
        </div>

        {filtered.length === 0 ? (
          <div className="p-6">
            <EmptyState
              title="No donor cases match these filters"
              description="Adjust search queries or date ranges to view matching cornea cases."
              action={
                <Button onClick={clearFilters} variant="secondary">
                  Clear Filters
                </Button>
              }
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead className={theadClass}>
                <tr>
                  <th scope="col" className={thClass}>Case ID / Donor</th>
                  <th scope="col" className={thClass}>Collection Date</th>
                  <th scope="col" className={thClass}>Age</th>
                  <th scope="col" className={thClass}>Eye</th>
                  <th scope="col" className={thClass}>AI Grade</th>
                  <th scope="col" className={thClass}>Disease Status</th>
                  <th scope="col" className={thClass}>AI Analysis</th>
                  <th scope="col" className={thClass}>Review Status</th>
                  <th scope="col" className={thClass}>Last Updated</th>
                  <th scope="col" className={thClass}>
                    <span className="sr-only">Open</span>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((donorCase) => {
                  const progress = analysisProgress(donorCase);
                  return (
                    <tr key={donorCase.caseId} className={trClass}>
                      <td className={tdClass}>
                        <Link
                          to={`/cases/${donorCase.caseId}`}
                          className="font-mono text-xs font-bold text-sky-700 hover:underline">
                          {donorCase.caseId}
                        </Link>
                        <p className="mt-0.5 font-mono text-2xs text-slate-400">
                          {donorCase.donor.donorId}
                        </p>
                      </td>
                      <td className={`${tdClass} whitespace-nowrap text-xs`}>
                        {formatDate(donorCase.donor.collectionDate)}
                      </td>
                      <td className={`${tdClass} font-mono text-xs`}>{donorCase.donor.age}</td>
                      <td className={`${tdClass} whitespace-nowrap text-xs`}>{donorCase.donor.eye}</td>
                      <td className={tdClass}>
                        <GradeBadge grade={predictedGrade(donorCase)} />
                      </td>
                      <td className={`${tdClass} text-xs`}>
                        {diseaseAssessment(donorCase) ?? (
                          <span className="text-slate-400 italic">Not analysed</span>
                        )}
                      </td>
                      <td className={tdClass}>
                        <StatusBadge status={progress.status} label={`${progress.status}`} />
                      </td>
                      <td className={tdClass}>
                        <ReviewBadge status={donorCase.reviewStatus} />
                      </td>
                      <td className={`${tdClass} whitespace-nowrap text-xs text-slate-400`}>
                        {formatDateTime(donorCase.lastUpdated)}
                      </td>
                      <td className={tdClass}>
                        <Link to={`/cases/${donorCase.caseId}`}>
                          <Button variant="secondary" size="sm">
                            Open Case
                          </Button>
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </div>
  );
}