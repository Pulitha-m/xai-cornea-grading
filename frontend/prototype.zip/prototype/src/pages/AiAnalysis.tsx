import React from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { toast } from 'sonner';
import { PlayIcon } from 'lucide-react';
import { useCaseStore } from '../contexts/CaseStore';
import { moduleRegistry } from '../data/moduleRegistry';
import { PageHeader } from '../components/ui/PageHeader';
import { Panel } from '../components/ui/Panel';
import { Button } from '../components/ui/Button';
import { StatusBadge } from '../components/ui/StatusBadge';
import { EmptyState } from '../components/ui/EmptyState';
import { CaseSelector } from '../components/CaseSelector';
import { ModuleMetadata } from '../components/modules/ModuleMetadata';
import { getModuleDetailPanel } from '../components/modules/registry';
import { getResult } from '../utils/caseHelpers';
import { formatDateTime } from '../utils/format';

export function AiAnalysis() {
  const { caseId } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { cases, getCase, runModule } = useCaseStore();

  const activeCaseId = caseId ?? cases[0]?.caseId;
  const donorCase = getCase(activeCaseId);
  const requestedModule = searchParams.get('module');
  const activeModuleId =
    requestedModule && moduleRegistry.some((m) => m.id === requestedModule)
      ? requestedModule
      : moduleRegistry[0].id;

  if (!donorCase) {
    return (
      <div className="p-8">
        <EmptyState title="No Case Selected" description="Create a donor case to execute AI analysis." />
      </div>
    );
  }

  const definition = moduleRegistry.find((m) => m.id === activeModuleId)!;
  const result = getResult(donorCase, activeModuleId);
  const DetailPanel = getModuleDetailPanel(activeModuleId);

  const handleRun = () => {
    runModule(donorCase.caseId, definition.id);
    toast.info(`${definition.name} run requested`, {
      description: 'Neural analysis simulated for demonstration.'
    });
  };

  return (
    <div className="space-y-6 pb-12">
      <PageHeader
        eyebrow={
          <Link to={`/cases/${donorCase.caseId}`} className="font-mono font-bold text-sky-700 hover:underline">
            #{donorCase.caseId}
          </Link>
        }
        title="Neural Analysis Workspace"
        description="Autonomous module execution space. Module outputs provide decision support for specialist sign-off."
        actions={
          <>
            <CaseSelector
              value={donorCase.caseId}
              onChange={(id) => navigate(`/analysis/${id}?module=${activeModuleId}`)}
            />
            <Link to={`/cases/${donorCase.caseId}`}>
              <Button variant="secondary" size="md">
                Case Record Overview
              </Button>
            </Link>
          </>
        }
      />

      <div className="grid gap-6 xl:grid-cols-[minmax(0,18rem)_minmax(0,1fr)]">
        <div className="space-y-6 xl:sticky xl:top-6 xl:self-start">
          <Panel title="Neural Modules" flush>
            <ul className="divide-y divide-slate-100">
              {moduleRegistry.map((mod) => {
                const modResult = getResult(donorCase, mod.id);
                const active = mod.id === activeModuleId;
                return (
                  <li key={mod.id}>
                    <button
                      type="button"
                      onClick={() => setSearchParams({ module: mod.id })}
                      aria-current={active ? 'true' : undefined}
                      className={`w-full px-5 py-3.5 text-left transition-all ${
                        active
                          ? 'bg-sky-50 border-l-4 border-sky-600'
                          : 'hover:bg-slate-50'
                      }`}>
                      <div className="flex items-start justify-between gap-2">
                        <span
                          className={`text-xs ${
                            active ? 'font-extrabold text-sky-900' : 'font-semibold text-slate-800'
                          }`}>
                          {mod.name}
                        </span>
                      </div>
                      <div className="mt-1.5">
                        <StatusBadge status={modResult.status} />
                      </div>
                    </button>
                  </li>
                );
              })}
            </ul>
          </Panel>

          <Panel title="Module Interface">
            <ModuleMetadata definition={definition} result={result} />
          </Panel>
        </div>

        <div className="min-w-0 space-y-6">
          <Panel
            title={definition.name}
            description={definition.purpose}
            meta={<StatusBadge status={result.status} size="md" />}
            actions={
              <Button variant="primary" onClick={handleRun} disabled={result.status === 'Running'}>
                <PlayIcon className="h-4 w-4" />
                {result.status === 'Running' ? 'Running…' : 'Run Neural Analysis'}
              </Button>
            }>
            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <p className="text-2xs font-bold uppercase tracking-wider text-slate-400">Result Summary</p>
                <p className="mt-1 text-xs font-bold text-slate-900">
                  {result.resultSummary ?? <span className="text-slate-400">No result written</span>}
                </p>
              </div>
              <div>
                <p className="text-2xs font-bold uppercase tracking-wider text-slate-400">Last Execution</p>
                <p className="mt-1 text-xs font-semibold text-slate-800">
                  {result.lastRun ? formatDateTime(result.lastRun) : 'Never'}
                </p>
              </div>
              <div>
                <p className="text-2xs font-bold uppercase tracking-wider text-slate-400">
                  {result.confidence !== null ? 'Confidence Score' : 'Analysis Quality'}
                </p>
                <p className="mt-1 font-mono text-xs font-bold text-slate-900">
                  {result.confidence !== null
                    ? result.confidence.toFixed(2)
                    : result.quality ?? 'Not applicable'}
                </p>
              </div>
            </div>
            {result.statusNote && (
              <p className="mt-4 rounded-2xl border border-slate-200 bg-slate-50 p-3 text-xs leading-relaxed text-slate-600">
                {result.statusNote}
              </p>
            )}
            {result.missingInputs.length > 0 && (
              <p className="mt-2 rounded-2xl border border-amber-200 bg-amber-50 p-3 text-xs leading-relaxed text-amber-900 font-semibold">
                Missing required inputs: {result.missingInputs.join(', ')}
              </p>
            )}
          </Panel>

          <DetailPanel donorCase={donorCase} definition={definition} result={result} />
        </div>
      </div>
    </div>
  );
}