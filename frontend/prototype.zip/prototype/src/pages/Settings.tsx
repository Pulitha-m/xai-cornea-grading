import React from 'react';
import { useCaseStore } from '../contexts/CaseStore';
import { useSession } from '../contexts/SessionContext';
import { getRoleProfile } from '../data/staff';
import { moduleRegistry } from '../data/moduleRegistry';
import { PageHeader } from '../components/ui/PageHeader';
import { Panel } from '../components/ui/Panel';
import { Field } from '../components/ui/Field';
import { tableClass, tdClass, thClass, theadClass } from '../components/ui/tableStyles';

export function Settings() {
  const { currentUser, cases } = useCaseStore();
  const { user } = useSession();
  const roleSummary = user ? getRoleProfile(user.role).summary : '';

  return (
    <div className="space-y-6 pb-12">
      <PageHeader
        eyebrow="System Governance"
        title="Platform &amp; Module Settings"
        description="Configuration rules, neural module registry status, and staff role scopes."
      />

      <div className="space-y-6">
        <Panel
          title="Registered AI Neural Modules"
          description="Integrated modules processing donor cases."
          flush>
          <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead className={theadClass}>
                <tr>
                  <th scope="col" className={thClass}>Module Name</th>
                  <th scope="col" className={thClass}>Module ID</th>
                  <th scope="col" className={thClass}>Owner</th>
                  <th scope="col" className={thClass}>Expected Inputs</th>
                  <th scope="col" className={thClass}>Endpoint Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {moduleRegistry.map((mod) => (
                  <tr key={mod.id}>
                    <td className={`${tdClass} font-bold text-slate-900`}>{mod.name}</td>
                    <td className={`${tdClass} font-mono text-2xs text-sky-700`}>{mod.id}</td>
                    <td className={tdClass}>{mod.owner}</td>
                    <td className={`${tdClass} text-slate-500`}>{mod.expectedInputs.join(', ')}</td>
                    <td className={tdClass}>
                      {mod.modelConnected ? (
                        <span className="inline-flex items-center gap-1 text-2xs font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-600 animate-pulse" />
                          Connected
                        </span>
                      ) : (
                        <span className="text-2xs font-bold text-slate-400 bg-slate-100 px-2.5 py-0.5 rounded-full">
                          Simulated
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>

        <div className="grid gap-6 lg:grid-cols-2">
          <Panel title="Clinical Review Thresholds" description="Specialist threshold triggers.">
            <dl className="space-y-3">
              <Field label="Confidence Threshold" value="0.75" mono />
              <Field label="ECD Minimum Threshold" value="2,000" unit="cells/mm²" mono />
              <Field label="CV Maximum Threshold" value="40" unit="%" mono />
              <Field label="HEX Minimum Threshold" value="55" unit="%" mono />
            </dl>
          </Panel>

          <Panel title="Account &amp; Session Environment">
            <dl className="space-y-3">
              <Field label="Signed In As" value={user?.name ?? currentUser} />
              <Field label="Staff ID" value={user?.staffId ?? null} mono />
              <Field label="Role Clearance" value={user ? `${user.title} — ${roleSummary}` : null} />
              <Field label="Institution" value="National Eye Bank of Sri Lanka" />
              <Field label="System Scope" value="Production Clinical Command Center" />
              <Field label="Active Cases in Vault" value={cases.length} mono />
            </dl>
          </Panel>
        </div>
      </div>
    </div>
  );
}