import React from 'react';
import { useSession } from '../contexts/SessionContext';
import { TechnicianDashboard } from './dashboards/TechnicianDashboard';
import { SpecialistDashboard } from './dashboards/SpecialistDashboard';
import { AdminDashboard } from './dashboards/AdminDashboard';
import { ManagerDashboard } from './dashboards/ManagerDashboard';
import { AttendantDashboard } from './dashboards/AttendantDashboard';

export function Dashboard() {
  const { role } = useSession();

  switch (role) {
    case 'Admin':
      return <AdminDashboard />;
    case 'Manager':
      return <ManagerDashboard />;
    case 'Doctor':
      return <SpecialistDashboard />;
    case 'Nurse':
      return <TechnicianDashboard />;
    case 'Attendant':
      return <AttendantDashboard />;
    default:
      return <TechnicianDashboard />;
  }
}