import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  AlertTriangleIcon,
  ArrowRightIcon,
  StethoscopeIcon,
  CheckCircle2Icon,
  SparklesIcon,
  TrendingDownIcon,
  FileCheckIcon,
} from 'lucide-react';
import { useCaseStore } from '../../contexts/CaseStore';
import { useSession } from '../../contexts/SessionContext';
import { useBranch } from '../../contexts/BranchContext';
import { StatusBadge } from '../../components/ui/StatusBadge';
import { ReviewBadge } from '../../components/ui/ReviewBadge';
import { GradeBadge } from '../../components/ui/GradeBadge';
import { Button } from '../../components/ui/Button';
import { Panel } from '../../components/ui/Panel';
import { tableClass, tdClass, thClass, theadClass, trClass } from '../../components/ui/tableStyles';

export function SpecialistDashboard() {
  const { cases } = useCaseStore();
  const { user } = useSession();
  const { activeBranch, filterByBranch } = useBranch();
  const navigate = useNavigate();

  // Filter cases by branch and doctor role view
  const branchCases = filterByBranch(cases);
  const queue = branchCases.filter((c) => c.reviewStatus === 'Pending Review' || c.reviewStatus === 'Under Review');
  const completedDecisions = branchCases.filter((c) => c.specialistDecision !== null);

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner Card */}
      <div className="relative overflow-hidden rounded-3xl border border-slate-200 bg-surface p-6 sm:p-8 shadow-bento">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-10 pointer-events-none mix-blend-multiply"
          style={{ backgroundImage: `url('/background.jpg')` }}
        />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-2xs font-extrabold uppercase tracking-wider text-amber-700">
              <StethoscopeIcon className="h-4 w-4 text-amber-600" />
              NEBSL Clinical Director &amp; Surgeon Portal
            </div>
            <h1 className="text-xl font-extrabold text-slate-900 tracking-tight mt-1">
              Clinical Assessment &amp; Transplant Authorization
            </h1>
            <p className="text-xs text-slate-500 mt-0.5 max-w-2xl">
              Branch active: <strong>{activeBranch}</strong>. Review specular cell morphology, AI-generated CHI scoring, approve donor-recipient matches, and log post-transplant follow-up logs.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="yellow" size="md" onClick={() => navigate('/recipients')}>
              Matching Board
            </Button>
            <Button variant="primary" size="md" onClick={() => navigate('/post-transplant')}>
              Follow-ups
            </Button>
          </div>
        </div>
      </div>

      {/* Telemetry Stat Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-6 items-stretch">
        <div className="h-full bg-surface rounded-3xl p-5 border border-slate-200 shadow-bento flex flex-col justify-between">
          <div className="text-xs font-semibold text-slate-500">Evaluation Queue</div>
          <div className="text-2xl font-extrabold text-slate-900 mt-1">{queue.length}</div>
          <p className="text-2xs text-slate-400 mt-1">Pending clinical review</p>
        </div>

        <div className="h-full bg-amber-50/70 rounded-3xl p-5 border border-amber-200/80 shadow-bento flex flex-col justify-between">
          <div className="text-xs font-bold text-amber-900">AI Alerts</div>
          <div className="text-2xl font-extrabold text-amber-900 mt-1">
            {branchCases.filter((c) => c.modules.specular_microscopy?.quality === 'Poor').length}
          </div>
          <p className="text-2xs text-amber-700 mt-1">Low specular quality warnings</p>
        </div>

        <div className="h-full bg-rose-50/70 rounded-3xl p-5 border border-rose-200/80 shadow-bento flex flex-col justify-between">
          <div className="text-xs font-bold text-rose-900">Rejection Risk</div>
          <div className="text-2xl font-extrabold text-rose-900 mt-1">1</div>
          <p className="text-2xs text-rose-700 mt-1">Post-transplant cell loss warnings</p>
        </div>

        <div className="h-full bg-emerald-50/70 rounded-3xl p-5 border border-emerald-200/80 shadow-bento flex flex-col justify-between">
          <div className="text-xs font-bold text-emerald-900">Signed Off Today</div>
          <div className="text-2xl font-extrabold text-emerald-900 mt-1">{completedDecisions.length}</div>
          <p className="text-2xs text-emerald-700 mt-1">Released for transplants</p>
        </div>
      </div>

      {/* Main Grid Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Queue Table */}
        <div className="lg:col-span-2">
          <Panel p={0} className="overflow-hidden">
            <div className="border-b border-slate-200 bg-slate-50/80 px-6 py-3">
              <h3 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider">
                My Clinical Evaluation Queue
              </h3>
            </div>
            {queue.length === 0 ? (
              <div className="p-8 text-center text-slate-400">All cases signed off!</div>
            ) : (
              <div className="overflow-x-auto">
                <table className={tableClass}>
                  <thead className={theadClass}>
                    <tr>
                      <th className={thClass}>Case ID</th>
                      <th className={thClass}>Donor Info</th>
                      <th className={thClass}>Preservation Medium</th>
                      <th className={thClass}>AI Suitability</th>
                      <th className={thClass}>Status</th>
                      <th className={thClass}>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {queue.map((c) => (
                      <tr key={c.caseId} className={trClass}>
                        <td className={`${tdClass} font-extrabold text-sky-900`}>{c.caseId}</td>
                        <td className={tdClass}>
                          <div className="font-bold text-slate-900">Age: {c.donor.age} | {c.donor.sex}</div>
                          <div className="text-2xs text-slate-400">Eye: {c.donor.eye}</div>
                        </td>
                        <td className={tdClass}>{c.clinical.storageMedium}</td>
                        <td className={tdClass}>
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-2xs font-extrabold">
                            <SparklesIcon className="h-3 w-3" />
                            Suitable
                          </span>
                        </td>
                        <td className={tdClass}>
                          <StatusBadge status={c.reviewStatus} />
                        </td>
                        <td className={tdClass}>
                          <Button
                            variant="primary"
                            size="xs"
                            onClick={() => navigate(`/cases/${c.caseId}`)}>
                            Evaluate →
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Panel>
        </div>

        {/* Clinical Activity & Alerts */}
        <div className="space-y-6">
          <Panel className="p-5 space-y-4">
            <h3 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider border-b border-slate-100 pb-2">
              Recent Clinical Sign-Offs
            </h3>
            {completedDecisions.length === 0 ? (
              <p className="text-xs text-slate-400">No decisions made yet today.</p>
            ) : (
              <div className="space-y-3">
                {completedDecisions.map((c) => (
                  <div key={c.caseId} className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                    <div className="flex items-center justify-between">
                      <span className="text-2xs font-extrabold text-sky-900">#{c.caseId}</span>
                      <span className="text-2xs font-extrabold text-emerald-700">Suitable</span>
                    </div>
                    <p className="text-2xs text-slate-500 mt-1">Decision: {c.specialistDecision?.outcome}</p>
                  </div>
                ))}
              </div>
            )}
          </Panel>
        </div>
      </div>
    </div>
  );
}