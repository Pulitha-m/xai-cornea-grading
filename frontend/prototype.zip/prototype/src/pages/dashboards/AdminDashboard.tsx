import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRightIcon,
  ActivityIcon,
  CheckCircle2Icon,
  ClockIcon,
  CpuIcon,
  EyeIcon,
  FileCheckIcon,
  TrendingUpIcon,
  TrendingDownIcon,
  UserPlusIcon,
  MoreHorizontalIcon,
  ShieldCheckIcon,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { useCaseStore } from '../../contexts/CaseStore';
import { moduleRegistry } from '../../data/moduleRegistry';
import { Button } from '../../components/ui/Button';
import { StatusBadge } from '../../components/ui/StatusBadge';
import { AdminStaffModal } from '../../components/dashboard/AdminStaffModal';
import { AdminModuleModal } from '../../components/dashboard/AdminModuleModal';

// Recharts Sample Data for Hourly Peak Activity
const HOURLY_ACTIVITY = [
  { time: '8 am', volume: 22 },
  { time: '10 am', volume: 45 },
  { time: '12 am', volume: 58 },
  { time: '2 pm', volume: 52 },
  { time: '4 pm', volume: 88, isPeak: true },
  { time: '6 pm', volume: 40 },
  { time: '8 pm', volume: 28 },
];

// Recharts Sample Data for Donut Caseload
const CASELOAD_DONUT = [
  { name: 'Checkup / Normal', value: 48, color: '#fef08a' }, // Light Yellow
  { name: 'Emergency / Urgent', value: 15, color: '#fecdd3' }, // Soft Pink
  { name: 'Chronic / Risk', value: 8, color: '#bae6fd' }, // Light Blue
  { name: 'Follow-up', value: 29, color: '#a7f3d0' }, // Soft Mint
];

export function AdminDashboard() {
  const { cases } = useCaseStore();
  const [isStaffModalOpen, setIsStaffModalOpen] = useState(false);
  const [isModuleModalOpen, setIsModuleModalOpen] = useState(false);

  const analysed = cases.filter((c) => c.donorCode).length;
  const connected = moduleRegistry.filter((m) => m.modelConnected).length;

  // Donor patient rows for Live Occupancy bento table
  const donorRows = [
    { name: 'Anya K., 44F', initials: 'A', reason: 'Corneal Dystrophy', doctor: 'Dr. Ramirez', doctorPic: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=100&auto=format&fit=crop&q=80', status: 'In Treatment', bg: 'bg-emerald-100 text-emerald-800', room: 'Vault 20A' },
    { name: 'Nazmi J., 22M', initials: 'N', reason: 'Endothelial Trauma', doctor: 'Dr. Patel', doctorPic: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=100&auto=format&fit=crop&q=80', status: 'In Treatment', bg: 'bg-sky-100 text-sky-800', room: 'Vault 21C' },
    { name: 'Meya L., 67F', initials: 'M', reason: 'Keratoconus Grade 3', doctor: 'Dr. Laura', doctorPic: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=100&auto=format&fit=crop&q=80', status: 'Waiting', bg: 'bg-amber-100 text-amber-900', room: 'Vault 22B' },
    { name: 'David M., 51M', initials: 'D', reason: 'Stromal Scarring', doctor: 'Dr. Aris', doctorPic: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=100&auto=format&fit=crop&q=80', status: 'Waiting', bg: 'bg-amber-100 text-amber-900', room: 'Vault 23D' },
    { name: 'Elle S., 33F', initials: 'E', reason: 'Fuchs Dystrophy', doctor: 'Dr. Lopez', doctorPic: 'https://images.unsplash.com/photo-1594824813571-2153349aed06?w=100&auto=format&fit=crop&q=80', status: 'Completed', bg: 'bg-sky-100 text-sky-800', room: 'Vault 24E' },
    { name: 'Finn P., 88M', initials: 'F', reason: 'Post-Cataract Edema', doctor: 'Dr. Chen', doctorPic: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80', status: 'Completed', bg: 'bg-sky-100 text-sky-800', room: 'Vault 22B' },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* TOP BANNER CARD WITH BACKGROUND.JPG ACCENT OVERLAY */}
      <div className="relative overflow-hidden rounded-3xl border border-slate-200 bg-surface p-6 sm:p-8 shadow-bento">
        {/* Background Image Overlay */}
        <div
          className="absolute inset-0 bg-cover bg-center opacity-10 pointer-events-none mix-blend-multiply"
          style={{ backgroundImage: `url('/background.jpg')` }}
        />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-2xs font-extrabold uppercase tracking-wider text-sky-700">
              <ShieldCheckIcon className="h-4 w-4 text-sky-600" />
              National Eye Bank of Sri Lanka Command Center
            </div>
            <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">System Telemetry &amp; Operations</h1>
            <p className="text-xs text-slate-500 max-w-2xl">
              Real-time tissue throughput, AI module latency, staffing authorizations &amp; compliance audit logs.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <Button variant="yellow" size="md" onClick={() => setIsStaffModalOpen(true)}>
              <UserPlusIcon className="h-4 w-4" />
              Provision Staff
            </Button>
            <Button variant="primary" size="md" onClick={() => setIsModuleModalOpen(true)}>
              <CpuIcon className="h-4 w-4" />
              Register AI Module
            </Button>
          </div>
        </div>
      </div>

      {/* ROW 1: TELEMETRY STAT STRIP (4 Metric Cards with Equal Heights) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
        <div className="h-full bg-surface rounded-3xl p-5 border border-slate-200 shadow-bento flex flex-col justify-between transition-all hover:scale-[1.01]">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
              <div className="p-2 rounded-2xl bg-sky-100 text-sky-700">
                <EyeIcon className="h-4 w-4" />
              </div>
              Total Donor Cases
            </div>
            <div className="text-2xl font-extrabold text-slate-900 flex items-baseline gap-2 pt-1">
              {cases.length + 128}
              <span className="inline-flex items-center text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                <TrendingUpIcon className="h-3 w-3 mr-0.5" /> +31%
              </span>
            </div>
          </div>
        </div>

        <div className="h-full bg-surface rounded-3xl p-5 border border-slate-200 shadow-bento flex flex-col justify-between transition-all hover:scale-[1.01]">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
              <div className="p-2 rounded-2xl bg-amber-100 text-amber-800">
                <ActivityIcon className="h-4 w-4" />
              </div>
              Vault Storage Occupancy
            </div>
            <div className="text-2xl font-extrabold text-slate-900 flex items-baseline gap-2 pt-1">
              60<span className="text-sm font-semibold text-slate-400">/100</span>
              <span className="inline-flex items-center text-xs font-bold text-rose-700 bg-rose-100 px-2 py-0.5 rounded-full">
                <TrendingDownIcon className="h-3 w-3 mr-0.5" /> -5%
              </span>
            </div>
          </div>
        </div>

        <div className="h-full bg-surface rounded-3xl p-5 border border-slate-200 shadow-bento flex flex-col justify-between transition-all hover:scale-[1.01]">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
              <div className="p-2 rounded-2xl bg-slate-100 text-slate-700">
                <FileCheckIcon className="h-4 w-4" />
              </div>
              Evaluated vs Queue
            </div>
            <div className="text-2xl font-extrabold text-slate-900 flex items-baseline gap-1 pt-1">
              {analysed + 28}<span className="text-sm font-semibold text-slate-400">/142</span>
            </div>
          </div>
        </div>

        <div className="h-full bg-surface rounded-3xl p-5 border border-slate-200 shadow-bento flex flex-col justify-between transition-all hover:scale-[1.01]">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
              <div className="p-2 rounded-2xl bg-sky-100 text-sky-700">
                <CpuIcon className="h-4 w-4" />
              </div>
              AI Module Health
            </div>
            <div className="text-2xl font-extrabold text-slate-900 flex items-baseline gap-2 pt-1">
              {connected}/{moduleRegistry.length}
              <span className="inline-flex items-center text-2xs font-bold text-sky-900 bg-sky-100 px-2.5 py-0.5 rounded-full">
                OPERATIONAL
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* ROW 2: LIVE CASES TABLE + PEAK ACTIVITY BAR CHART (Aligned Heights) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <div className="lg:col-span-7 h-full bg-surface rounded-3xl p-6 border border-slate-200 shadow-bento flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-sky-100 text-sky-800 font-bold text-xs">
                  <ActivityIcon className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Live Occupancy &amp; Active Cases</h3>
                  <p className="text-2xs text-slate-500">15 active tissue evaluations (8 in triage, 7 in review)</p>
                </div>
              </div>
              <button className="text-slate-400 hover:text-slate-700">
                <MoreHorizontalIcon className="h-5 w-5" />
              </button>
            </div>

            <div className="overflow-x-auto mt-4">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-2xs font-semibold uppercase tracking-wider text-slate-400">
                    <th className="pb-3 font-semibold">Patient / Donor</th>
                    <th className="pb-3 font-semibold">Condition</th>
                    <th className="pb-3 font-semibold">Assignee</th>
                    <th className="pb-3 font-semibold">Status</th>
                    <th className="pb-3 font-semibold text-right">Storage</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {donorRows.map((row, idx) => (
                    <tr key={idx} className="group hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 pr-2">
                        <div className="flex items-center gap-2.5">
                          <span className={`flex h-7 w-7 items-center justify-center rounded-full font-bold text-2xs ${row.bg}`}>
                            {row.initials}
                          </span>
                          <span className="font-semibold text-slate-900">{row.name}</span>
                        </div>
                      </td>
                      <td className="py-3.5 pr-2 text-slate-600">{row.reason}</td>
                      <td className="py-3.5 pr-2">
                        <div className="flex items-center gap-2">
                          <img src={row.doctorPic} alt={row.doctor} className="h-6 w-6 rounded-full object-cover border border-slate-200" />
                          <span className="text-slate-800 font-medium">{row.doctor}</span>
                        </div>
                      </td>
                      <td className="py-3.5 pr-2">
                        <StatusBadge status={row.status} />
                      </td>
                      <td className="py-3.5 text-right font-mono text-2xs font-bold text-slate-600">
                        {row.room}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 h-full bg-surface rounded-3xl p-6 border border-slate-200 shadow-bento flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <ClockIcon className="h-5 w-5 text-sky-600" />
                <h3 className="text-sm font-bold text-slate-900">Peak Activity Times Today</h3>
              </div>
              <button className="text-slate-400 hover:text-slate-700">
                <MoreHorizontalIcon className="h-5 w-5" />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2 mt-4 text-center">
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="text-sm font-bold text-slate-900">12 mins</div>
                <div className="text-2xs text-slate-500">Avg. wait time</div>
              </div>
              <div className="p-3 rounded-2xl bg-sky-50 border border-sky-100">
                <div className="text-sm font-bold text-sky-900">32/142</div>
                <div className="text-2xs text-sky-700">Processed today</div>
              </div>
              <div className="p-3 rounded-2xl bg-amber-50 border border-amber-100">
                <div className="text-sm font-bold text-amber-900">32 mins</div>
                <div className="text-2xs text-amber-700">Avg. processing</div>
              </div>
            </div>

            <div className="h-52 w-full mt-6">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={HOURLY_ACTIVITY} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8' }} />
                  <Tooltip
                    contentStyle={{ borderRadius: '12px', borderColor: '#e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.08)' }}
                    cursor={{ fill: '#f1f5f9' }}
                  />
                  <Bar dataKey="volume" radius={[8, 8, 0, 0]}>
                    {HOURLY_ACTIVITY.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={entry.isPeak ? '#0284c7' : '#f1f5f9'}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="flex items-center justify-between text-2xs font-semibold text-slate-400 mt-2 px-1">
              <span>Less busy</span>
              <span className="text-sky-700 font-bold">Peak (4 PM)</span>
              <span>Busy</span>
            </div>
          </div>
        </div>
      </div>

      {/* ROW 3: 3 BENTO WIDGETS (Dark Calendar, Donut Caseload, Pending Tasks - Matched Heights) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
        <div className="h-full bg-[#1e293b] rounded-3xl p-6 text-white shadow-bento flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-700/60">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-slate-800 text-sky-400">
                  <ClockIcon className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-bold">April Patient Volume</h3>
              </div>
              <MoreHorizontalIcon className="h-5 w-5 text-slate-400" />
            </div>

            <div className="grid grid-cols-7 text-center text-2xs font-semibold text-slate-400 mt-4 mb-2">
              <span>S</span><span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span>
            </div>

            <div className="grid grid-cols-7 gap-2 text-center text-xs">
              <div className="p-2 text-slate-600">.</div>
              <div className="p-2 text-slate-600">.</div>
              <div className="p-2 text-slate-600">.</div>
              <div className="p-2 text-slate-400 font-medium">12</div>
              <div className="p-2 text-slate-400 font-medium">49</div>
              <div className="p-2 text-slate-400 font-medium">41</div>
              <div className="p-2 text-slate-600">.</div>

              <div className="p-2 text-slate-400 font-medium">12</div>
              <div className="p-2 text-slate-400 font-medium">45</div>
              <div className="p-2 rounded-full bg-slate-800 text-white font-bold">14</div>
              <div className="p-2 rounded-full bg-slate-800 text-white font-bold">15</div>
              <div className="p-2 rounded-full bg-slate-800 text-white font-bold">16</div>
              <div className="p-2 rounded-full bg-slate-800 text-white font-bold">17</div>
              <div className="p-2 text-slate-400 font-medium">2</div>

              <div className="p-2 text-slate-400 font-medium">20</div>
              <div className="p-2 rounded-full bg-emerald-500 text-slate-950 font-extrabold shadow-glow">32</div>
              <div className="p-2 rounded-full bg-sky-500 text-slate-950 font-extrabold">51</div>
              <div className="p-2 text-slate-500">.</div>
              <div className="p-2 text-slate-500">.</div>
              <div className="p-2 text-slate-500">.</div>
              <div className="p-2 text-slate-500">.</div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-700/60 flex items-center justify-between text-2xs text-slate-400 mt-4">
            <span>Highlighted date: April 20</span>
            <span className="text-emerald-400 font-bold">+32 admissions today</span>
          </div>
        </div>

        <div className="h-full bg-surface rounded-3xl p-6 border border-slate-200 shadow-bento flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <ActivityIcon className="h-5 w-5 text-amber-600" />
                <h3 className="text-sm font-bold text-slate-900">Daily Caseload Mix</h3>
              </div>
              <MoreHorizontalIcon className="h-5 w-5 text-slate-400" />
            </div>

            <div className="h-44 w-full relative mt-3 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={CASELOAD_DONUT}
                    innerRadius={50}
                    outerRadius={70}
                    paddingAngle={4}
                    dataKey="value">
                    {CASELOAD_DONUT.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute flex flex-col items-center justify-center">
                <span className="text-2xl font-extrabold text-slate-900">48%</span>
                <span className="text-2xs text-slate-400">Normal Cornea</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 mt-2 text-2xs">
              {CASELOAD_DONUT.map((item) => (
                <div key={item.name} className="flex items-center gap-1.5 font-medium text-slate-600">
                  <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                  <span className="truncate">{item.name} ({item.value}%)</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="h-full bg-surface rounded-3xl p-6 border border-slate-200 shadow-bento flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <FileCheckIcon className="h-5 w-5 text-sky-600" />
                <h3 className="text-sm font-bold text-slate-900">Pending Authorizations</h3>
                <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 text-2xs font-extrabold">
                  12
                </span>
              </div>
              <MoreHorizontalIcon className="h-5 w-5 text-slate-400" />
            </div>

            <ul className="space-y-3 mt-4">
              {[
                { title: 'Specialist Signoff for #NEB-2026-089', note: 'Dr. Perera · 4.5h left', action: 'Review', variant: 'yellow' },
                { title: 'Specular Microscopy Recalibration', note: 'Module EC-Count-V2 · 6 days left', action: 'Approve', variant: 'primary' },
                { title: 'Donor Tissue Quality Appeal', note: 'Ben C. · Fungal Infection check', action: 'View', variant: 'secondary' },
                { title: 'HIPAA & NEBSL Audit Verification', note: 'Updated privacy training module', action: 'View', variant: 'secondary' },
              ].map((task, idx) => (
                <li key={idx} className="flex items-center justify-between p-2.5 rounded-2xl border border-slate-100 bg-slate-50/50 hover:bg-slate-50 transition-colors">
                  <div className="min-w-0 pr-2">
                    <p className="text-xs font-bold text-slate-800 truncate">{task.title}</p>
                    <p className="text-2xs text-slate-500 truncate mt-0.5">{task.note}</p>
                  </div>
                  <Button variant={task.variant as any} size="sm">
                    {task.action}
                  </Button>
                </li>
              ))}
            </ul>
          </div>

          <Link to="/audit" className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-center gap-1.5 text-xs font-semibold text-sky-700 hover:underline">
            View full compliance &amp; audit history
            <ArrowRightIcon className="h-3.5 w-3.5" />
          </Link>
        </div>
      </div>

      <AdminStaffModal isOpen={isStaffModalOpen} onClose={() => setIsStaffModalOpen(false)} />
      <AdminModuleModal isOpen={isModuleModalOpen} onClose={() => setIsModuleModalOpen(false)} />
    </div>
  );
}