import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ArrowRightIcon, PlusIcon, UploadIcon, EyeIcon, ClipboardListIcon, SparklesIcon } from 'lucide-react';
import { useCaseStore } from '../../contexts/CaseStore';
import { useSession } from '../../contexts/SessionContext';
import { useBranch } from '../../contexts/BranchContext';
import { StatusBadge } from '../../components/ui/StatusBadge';
import { Button } from '../../components/ui/Button';
import { Panel } from '../../components/ui/Panel';
import { tableClass, tdClass, thClass, theadClass, trClass } from '../../components/ui/tableStyles';

export function TechnicianDashboard() {
  const { cases } = useCaseStore();
  const { user } = useSession();
  const { activeBranch, filterByBranch } = useBranch();
  const navigate = useNavigate();

  const branchCases = filterByBranch(cases);
  const myCases = branchCases.filter((c) => c.createdBy === user?.displayName);
  const workingSet = myCases.length > 0 ? myCases : branchCases;

  const needsImage = workingSet.filter((c) => c.image.uploadStatus !== 'Uploaded');
  const pendingImageUpload = needsImage.length;

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner Card */}
      <div className="relative overflow-hidden rounded-3xl border border-slate-200 bg-surface p-6 sm:p-8 shadow-bento">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-10 pointer-events-none mix-blend-multiply"
          style={{ backgroundImage: `url('/background.jpg')` }}
        />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-2xs font-extrabold uppercase tracking-wider text-sky-700">
              <EyeIcon className="h-4 w-4 text-sky-600" />
              NEBSL Nurse &amp; Technician Workspace
            </div>
            <h1 className="text-xl font-extrabold text-slate-900 tracking-tight mt-1">
              Donor Intake &amp; Specular Microscopy
            </h1>
            <p className="text-xs text-slate-500 mt-0.5 max-w-2xl">
              Active branch: <strong>{activeBranch}</strong>. Complete patient donor forms, upload specular microscopy cell images, and request AI analysis runs.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <Button variant="primary" size="md" onClick={() => navigate('/cases/new')}>
              <PlusIcon className="h-4 w-4" />
              New Donor Intake
            </Button>
          </div>
        </div>
      </div>

      {/* Telemetry Stat Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 items-stretch">
        <div className="h-full bg-surface rounded-3xl p-5 border border-slate-200 shadow-bento flex flex-col justify-between">
          <div className="text-xs font-semibold text-slate-500">Active Intake Cases</div>
          <div className="text-2xl font-extrabold text-slate-900 mt-1">{workingSet.length}</div>
          <p className="text-2xs text-slate-400 mt-1">Grafts in preparation at branch</p>
        </div>

        <div className="h-full bg-amber-50/70 rounded-3xl p-5 border border-amber-200/80 shadow-bento flex flex-col justify-between">
          <div className="text-xs font-bold text-amber-900">Awaiting Specular Image</div>
          <div className="text-2xl font-extrabold text-amber-900 mt-1">{pendingImageUpload}</div>
          <p className="text-2xs text-amber-700 mt-1">Needs specular microscopy upload</p>
        </div>

        <div className="h-full bg-sky-50/70 rounded-3xl p-5 border border-sky-200/80 shadow-bento flex flex-col justify-between">
          <div className="text-xs font-bold text-sky-900">Graft Prep Completed</div>
          <div className="text-2xl font-extrabold text-sky-900 mt-1">
            {workingSet.filter((c) => c.corneaStatus === 'Image Uploaded' || c.corneaStatus === 'AI Analysis').length}
          </div>
          <p className="text-2xs text-sky-700 mt-1">Awaiting specialist review signoff</p>
        </div>
      </div>

      {/* Main Grid Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Panel p={0} className="overflow-hidden">
            <div className="border-b border-slate-200 bg-slate-50/80 px-6 py-3">
              <h3 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider">
                My Recent Case Intake Log
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className={tableClass}>
                <thead className={theadClass}>
                  <tr>
                    <th className={thClass}>Case ID</th>
                    <th className={thClass}>Age/Sex</th>
                    <th className={thClass}>Eye</th>
                    <th className={thClass}>Specular Status</th>
                    <th className={thClass}>Workflow Status</th>
                    <th className={thClass}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {workingSet.slice(0, 5).map((c) => (
                    <tr key={c.caseId} className={trClass}>
                      <td className={`${tdClass} font-extrabold text-sky-900`}>{c.caseId}</td>
                      <td className={tdClass}>{c.donor.age} yrs | {c.donor.sex}</td>
                      <td className={tdClass}>{c.donor.eye}</td>
                      <td className={tdClass}>
                        <span
                          className={`px-2 py-0.5 rounded-md text-2xs font-extrabold ${
                            c.image.uploadStatus === 'Uploaded'
                              ? 'bg-emerald-100 text-emerald-900'
                              : 'bg-amber-100 text-amber-900 border border-amber-200 animate-pulse'
                          }`}>
                          {c.image.uploadStatus}
                        </span>
                      </td>
                      <td className={tdClass}>
                        <StatusBadge status={c.corneaStatus} />
                      </td>
                      <td className={tdClass}>
                        <Button
                          variant="secondary"
                          size="xs"
                          onClick={() => navigate(`/cases/${c.caseId}`)}>
                          View Case →
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>
        </div>

        <div>
          <Panel className="p-5 space-y-4">
            <h3 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider border-b border-slate-100 pb-2">
              Microscopy Quality Alerts
            </h3>
            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200">
                <p className="font-extrabold text-amber-950">Konan XL Calibration Due</p>
                <p className="text-2xs text-amber-800 mt-0.5">Please check specular sensor clean status.</p>
              </div>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}