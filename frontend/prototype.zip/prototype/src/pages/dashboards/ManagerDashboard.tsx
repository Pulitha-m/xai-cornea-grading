import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BuildingIcon,
  PackageIcon,
  UsersIcon,
  CheckSquareIcon,
  TrendingUpIcon,
  AlertTriangleIcon,
  ArrowRightIcon,
  SparklesIcon,
} from 'lucide-react';
import { useBranch } from '../../contexts/BranchContext';
import { useTaskStore } from '../../contexts/TaskStore';
import { useCaseStore } from '../../contexts/CaseStore';
import { Panel } from '../../components/ui/Panel';
import { Button } from '../../components/ui/Button';

export function ManagerDashboard() {
  const { activeBranch } = useBranch();
  const { tasks } = useTaskStore();
  const { cases } = useCaseStore();
  const navigate = useNavigate();

  // Branch specific counts
  const branchCases = cases.filter(
    (c) => activeBranch === 'All Branches' || c.branch === activeBranch
  );
  const pendingReviews = branchCases.filter((c) => c.reviewStatus === 'Pending Review').length;
  const availableCorneas = branchCases.filter((c) => c.corneaStatus === 'Available').length;

  const activeTasks = tasks.filter(
    (t) => (activeBranch === 'All Branches' || t.branch === activeBranch) && t.status !== 'Completed'
  );
  const urgentTasksCount = activeTasks.filter((t) => t.priority === 'Urgent').length;

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-slate-200 bg-surface p-6 sm:p-8 shadow-bento">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-10 pointer-events-none mix-blend-multiply"
          style={{ backgroundImage: `url('/background.jpg')` }}
        />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-2xs font-extrabold uppercase tracking-wider text-amber-700">
              <BuildingIcon className="h-4 w-4 text-amber-600" />
              NEBSL Operational Management Portal
            </div>
            <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
              {activeBranch} Branch Operations
            </h1>
            <p className="text-xs text-slate-500 max-w-2xl">
              Coordinate staff tasks, monitor available tissue inventory, planning recipient matching, and approve inter-branch transfers.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <Button variant="yellow" size="md" onClick={() => navigate('/cases/new')}>
              Register Donor
            </Button>
            <Button variant="primary" size="md" onClick={() => navigate('/inventory')}>
              Manage Inventory
            </Button>
          </div>
        </div>
      </div>

      {/* Action-Oriented Cards: What needs attention today? */}
      <div className="space-y-3">
        <h3 className="text-sm font-extrabold uppercase tracking-wider text-slate-400 px-1">
          Requires Action Today
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Action Card 1: Corneas Awaiting Evaluation */}
          <Panel
            onClick={() => navigate('/cases')}
            className="p-5 border-amber-200 bg-amber-50/40 hover:bg-amber-50/70 hover:shadow-card cursor-pointer transition-all flex flex-col justify-between h-36">
            <div className="flex items-center justify-between">
              <span className="text-2xs font-extrabold uppercase text-amber-800 tracking-wider">Awaiting Evaluation</span>
              <AlertTriangleIcon className="h-5 w-5 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-extrabold text-amber-950">{pendingReviews}</p>
              <p className="text-2xs text-amber-800 font-bold mt-0.5">Donor corneas pending clinical review</p>
            </div>
          </Panel>

          {/* Action Card 2: Recipient Matching */}
          <Panel
            onClick={() => navigate('/recipients')}
            className="p-5 border-sky-200 bg-sky-50/40 hover:bg-sky-50/70 hover:shadow-card cursor-pointer transition-all flex flex-col justify-between h-36">
            <div className="flex items-center justify-between">
              <span className="text-2xs font-extrabold uppercase text-sky-800 tracking-wider">Recipient Matching</span>
              <UsersIcon className="h-5 w-5 text-sky-600" />
            </div>
            <div>
              <p className="text-2xl font-extrabold text-sky-950">2 Cases</p>
              <p className="text-2xs text-sky-800 font-bold mt-0.5">Eligible patients waiting list matching</p>
            </div>
          </Panel>

          {/* Action Card 3: Staff Tasks */}
          <Panel
            onClick={() => navigate('/my-work')}
            className="p-5 border-slate-200 bg-surface hover:bg-slate-50/60 hover:shadow-card cursor-pointer transition-all flex flex-col justify-between h-36">
            <div className="flex items-center justify-between">
              <span className="text-2xs font-extrabold uppercase text-slate-500 tracking-wider">Active Staff Tasks</span>
              <CheckSquareIcon className="h-5 w-5 text-slate-400" />
            </div>
            <div>
              <p className="text-2xl font-extrabold text-slate-900">{activeTasks.length}</p>
              <p className="text-2xs text-rose-700 font-extrabold mt-0.5">{urgentTasksCount} Urgent tasks active</p>
            </div>
          </Panel>
        </div>
      </div>

      {/* Row 3: Inventory Overview & Branch Staffing */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Panel className="lg:col-span-2 p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-extrabold text-slate-900">Tissue & Cornea Inventory</h3>
              <p className="text-2xs text-slate-500 font-semibold">Available cold storage inventory at branch</p>
            </div>
            <Button variant="secondary" size="xs" onClick={() => navigate('/inventory')}>
              Full Inventory →
            </Button>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-100 text-center">
              <span className="text-2xs font-extrabold text-emerald-800 uppercase">Available</span>
              <p className="text-xl font-extrabold text-emerald-950 mt-1">{availableCorneas}</p>
            </div>
            <div className="p-4 rounded-2xl bg-sky-50/80 border border-sky-100 text-center">
              <span className="text-2xs font-extrabold text-sky-800 uppercase">Reserved</span>
              <p className="text-xl font-extrabold text-sky-950 mt-1">1</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-center">
              <span className="text-2xs font-extrabold text-slate-500 uppercase">In Transit</span>
              <p className="text-xl font-extrabold text-slate-900 mt-1">1</p>
            </div>
          </div>
        </Panel>

        <Panel className="p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-extrabold text-slate-900">Active Staff Tasks</h3>
            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-100 text-amber-950 border border-amber-200">
              Today
            </span>
          </div>

          <div className="space-y-3">
            {activeTasks.slice(0, 3).map((task) => (
              <div key={task.id} className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80">
                <div className="flex items-center justify-between text-2xs font-bold">
                  <span className="text-sky-800 font-extrabold">{task.assignedRole}</span>
                  <span className={task.priority === 'Urgent' ? 'text-rose-600' : 'text-slate-500'}>
                    {task.priority}
                  </span>
                </div>
                <h4 className="text-xs font-extrabold text-slate-900 mt-1">{task.title}</h4>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}
