import React from 'react';
import { useNavigate } from 'react-router-dom';
import { TruckIcon, PackageIcon, CheckCircle2Icon, MapPinIcon, ClockIcon, AlertCircleIcon } from 'lucide-react';
import { useSession } from '../../contexts/SessionContext';
import { useBranch } from '../../contexts/BranchContext';
import { useTaskStore } from '../../contexts/TaskStore';
import { PageHeader } from '../../components/ui/PageHeader';
import { Panel } from '../../components/ui/Panel';
import { Button } from '../../components/ui/Button';

export function AttendantDashboard() {
  const { user } = useSession();
  const { activeBranch, filterByBranch } = useBranch();
  const { tasks, updateTaskStatus } = useTaskStore();

  const myTasks = filterByBranch(
    tasks.filter((t) => t.assignedRole === 'Attendant' || t.category === 'Transport' || t.category === 'Storage')
  );

  const pending = myTasks.filter((t) => t.status !== 'Completed');
  const completed = myTasks.filter((t) => t.status === 'Completed');

  return (
    <div className="space-y-6 pb-12">
      {/* Mobile/Tablet Touch Header */}
      <PageHeader
        eyebrow="Logistics & Operational Support"
        title={`Attendant Workstation — ${activeBranch}`}
        description="Touch-optimized task manager for tissue collection, cold-chain transport container preparation, storage movement, and hospital deliveries."
      />

      {/* Metric Quick Cards with Large Text */}
      <div className="grid grid-cols-2 gap-4">
        <Panel className="p-5 bg-amber-50/80 border-amber-200">
          <div className="flex items-center justify-between text-xs font-extrabold uppercase text-amber-900">
            <span>Tasks To Do Today</span>
            <ClockIcon className="h-5 w-5 text-amber-600" />
          </div>
          <p className="mt-3 text-3xl font-extrabold text-amber-950">{pending.length}</p>
          <p className="mt-1 text-xs text-amber-800 font-bold">Tap a task card below to complete</p>
        </Panel>

        <Panel className="p-5 bg-emerald-50/80 border-emerald-200">
          <div className="flex items-center justify-between text-xs font-extrabold uppercase text-emerald-900">
            <span>Completed Tasks</span>
            <CheckCircle2Icon className="h-5 w-5 text-emerald-600" />
          </div>
          <p className="mt-3 text-3xl font-extrabold text-emerald-950">{completed.length}</p>
          <p className="mt-1 text-xs text-emerald-800 font-bold">Successfully logged & confirmed</p>
        </Panel>
      </div>

      {/* Task Action List with Large Buttons */}
      <div className="space-y-4">
        <h3 className="text-base font-extrabold text-slate-900 px-1">My Assigned Tasks</h3>

        {pending.length === 0 ? (
          <Panel className="p-8 text-center bg-slate-50 border-slate-200">
            <CheckCircle2Icon className="h-10 w-10 text-emerald-500 mx-auto mb-2" />
            <h4 className="text-sm font-extrabold text-slate-900">All tasks completed!</h4>
            <p className="text-xs text-slate-500 mt-1">No pending transport or storage tasks assigned to you right now.</p>
          </Panel>
        ) : (
          <div className="space-y-4">
            {pending.map((t) => (
              <Panel
                key={t.id}
                className="p-5 sm:p-6 border-sky-200 bg-surface shadow-bento hover:border-sky-300 transition-all">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="space-y-2 min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-extrabold border border-amber-200">
                        {t.priority} Priority
                      </span>
                      <span className="px-2.5 py-0.5 rounded-md bg-slate-100 text-slate-700 text-2xs font-extrabold">
                        {t.branch} Branch
                      </span>
                    </div>

                    <h4 className="text-base sm:text-lg font-extrabold text-slate-900 leading-snug">{t.title}</h4>
                    {t.notes && (
                      <p className="text-xs sm:text-sm font-medium text-slate-600 bg-slate-50 p-3 rounded-2xl border border-slate-100">
                        📍 {t.notes}
                      </p>
                    )}
                    <div className="flex items-center gap-3 text-xs font-bold text-slate-400">
                      {t.caseId && <span>Case #: <strong className="text-sky-800 font-extrabold">{t.caseId}</strong></span>}
                      <span>Due: {t.dueDate}</span>
                    </div>
                  </div>

                  {/* Large Touchable Action Button */}
                  <Button
                    variant="primary"
                    size="lg"
                    className="w-full sm:w-auto px-6 py-4 text-sm font-extrabold shrink-0 shadow-md"
                    onClick={() => updateTaskStatus(t.id, 'Completed')}>
                    <CheckCircle2Icon className="h-5 w-5" />
                    Complete Task ✓
                  </Button>
                </div>
              </Panel>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
