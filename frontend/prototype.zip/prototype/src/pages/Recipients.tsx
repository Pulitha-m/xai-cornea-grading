import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { UsersIcon, ClockIcon, SparklesIcon, HeartHandshakeIcon } from "lucide-react";
import { useBranch } from "../contexts/BranchContext";
import { useSession } from "../contexts/SessionContext";
import { PageHeader } from "../components/ui/PageHeader";
import { Panel } from "../components/ui/Panel";
import { Button } from "../components/ui/Button";
import { WorkflowDiagram } from "../components/ui/WorkflowDiagram";
import { tableClass, tdClass, thClass, theadClass, trClass } from "../components/ui/tableStyles";
import { AVAILABLE_CORNEA_FIXTURES, RECIPIENT_MATCHING_FIXTURES, type MatchingFixture } from "../data/workflowFixtures";
import { RecipientMatchingWorkspace } from "../components/recipients/RecipientMatchingWorkspace";
import { RecipientRegistrationForm } from "../components/recipients/RecipientRegistrationForm";

export function Recipients() {
  const { filterByBranch, activeBranch } = useBranch();
  const { role, can } = useSession();
  const navigate = useNavigate();
  const [recipients, setRecipients] = useState<MatchingFixture[]>(RECIPIENT_MATCHING_FIXTURES);
  const [selectedRecipient, setSelectedRecipient] = useState(RECIPIENT_MATCHING_FIXTURES[0]);
  const [showRegistration, setShowRegistration] = useState(false);

  const filtered = filterByBranch(recipients.map((r) => ({ ...r, branch: r.assignedBranch })));
  useEffect(() => {
    if (filtered.length > 0 && !filtered.some((recipient) => recipient.recipientId === selectedRecipient.recipientId)) {
      setSelectedRecipient(filtered[0]);
    }
  }, [activeBranch, filtered, selectedRecipient.recipientId]);
  const handleMatchAction = (action: string) => {
    toast.success(`${action} recorded`, { description: "The matching handoff is simulated in this prototype." });
  };

  return (
    <div className="space-y-6 pb-12">
      <PageHeader
        eyebrow="Recipient Intelligence & Allocation"
        title={`Corneal Transplant Waiting List — ${activeBranch}`}
        description="Patient eligibility review, recipient waiting lists, and AI-assisted donor-recipient matching scores based on endothelial density, graft size, blood type, and urgency."
        actions={
          (role === "Doctor" || role === "Nurse") && (
            <Button variant="primary" size="md" onClick={() => setShowRegistration((value) => !value)}>
              + Register recipient
            </Button>
          )
        }
      />

      {showRegistration && (role === "Doctor" || role === "Nurse") && (
        <RecipientRegistrationForm
          onCancel={() => setShowRegistration(false)}
          onSave={(recipient) => {
            setRecipients((current) => [recipient, ...current]);
            setSelectedRecipient(recipient);
            setShowRegistration(false);
          }}
        />
      )}

      <Panel title="Selected recipient" description="Start with the person waiting for a transplant, then run AI-assisted retrieval and ranking for their clinical need." className="border-emerald-200">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-lg font-black text-slate-900">{selectedRecipient.recipientId}</span>
              <span className="rounded-full bg-rose-100 px-2.5 py-1 text-2xs font-extrabold text-rose-800">{selectedRecipient.urgency} priority</span>
              <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-2xs font-extrabold text-emerald-800">{selectedRecipient.status}</span>
            </div>
            <p className="mt-2 text-sm font-extrabold text-slate-900">
              {selectedRecipient.name} · {selectedRecipient.age} years · {selectedRecipient.sex}
            </p>
            <p className="mt-1 text-xs font-semibold text-slate-600">
              {selectedRecipient.diagnosis} · Branch: {selectedRecipient.assignedBranch} · Blood type: {selectedRecipient.bloodType}
            </p>
            <p className="mt-2 text-xs font-bold text-emerald-800">Eligibility: recipient is on the waiting list and ready for personalized cornea matching.</p>
          </div>
          {can("Recipient", "match") && (
            <Button variant="primary" size="md" onClick={() => toast.success("Matching engine retrieved eligible corneas", { description: "Top 3 recommendations are shown below for human review." })}>
              <SparklesIcon className="h-4 w-4" />
              Run AI matching
            </Button>
          )}
        </div>
      </Panel>

      <WorkflowDiagram
        title="Recipient-centered matching workflow"
        steps={[
          { label: "Recipient", detail: "Clinical profile, disease, severity, urgency and graft need.", role: "Doctor / Nurse / Technician", action: "Confirm eligibility", tone: "blue" },
          { label: "Waiting list", detail: "Eligible recipient registered and status tracked.", role: "Doctor / Nurse / Technician", action: "Find available corneas", tone: "green" },
          { label: "Candidate retrieval", detail: "Available and suitable corneas with donor intelligence.", role: "AI decision support", action: "Rank candidates", tone: "slate" },
          { label: "Top 3", detail: "Three recommendations with score and evidence.", role: "AI decision support", action: "Explain ranking", tone: "green" },
          { label: "Human review", detail: "Compare strengths, concerns and clinical factors.", role: "Nurse / Technician", action: "Propose a match", tone: "amber" },
          { label: "Doctor decision", detail: "Clinical rationale, approval, rejection or further review.", role: "Doctor", action: "Send approved match to allocation", tone: "amber" },
        ]}
      />

      <RecipientMatchingWorkspace recipient={selectedRecipient} corneas={AVAILABLE_CORNEA_FIXTURES} can={can} role={role} />

      {/* Telemetry Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Panel className="p-4 bg-rose-50/70 border-rose-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase text-rose-800">
            <span>Emergency / High Priority</span>
            <ClockIcon className="h-4 w-4 text-rose-600" />
          </div>
          <p className="mt-2 text-2xl font-extrabold text-rose-950">{filtered.filter((r) => r.urgency === "Emergency" || r.urgency === "High").length}</p>
          <p className="mt-0.5 text-2xs text-rose-800 font-semibold">Priority matching active</p>
        </Panel>

        <Panel className="p-4 bg-sky-50/70 border-sky-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase text-sky-800">
            <span>Active Waiting List</span>
            <UsersIcon className="h-4 w-4 text-sky-600" />
          </div>
          <p className="mt-2 text-2xl font-extrabold text-sky-950">{filtered.length}</p>
          <p className="mt-0.5 text-2xs text-sky-800 font-semibold">Registered recipients</p>
        </Panel>

        <Panel className="p-4 bg-emerald-50/70 border-emerald-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase text-emerald-800">
            <span>AI Matches Proposed</span>
            <SparklesIcon className="h-4 w-4 text-emerald-600" />
          </div>
          <p className="mt-2 text-2xl font-extrabold text-emerald-950">{filtered.filter((r) => r.matchScore).length}</p>
          <p className="mt-0.5 text-2xs text-emerald-800 font-semibold">High compatibility (&gt;90%)</p>
        </Panel>

        <Panel className="p-4 bg-slate-50 border-slate-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase text-slate-500">
            <span>Transplants Scheduled</span>
            <HeartHandshakeIcon className="h-4 w-4 text-slate-400" />
          </div>
          <p className="mt-2 text-2xl font-extrabold text-slate-900">{filtered.filter((r) => r.status === "Transplant Scheduled").length}</p>
          <p className="mt-0.5 text-2xs text-slate-500 font-semibold">Ready for surgery</p>
        </Panel>
      </div>

      <Panel title="Available donor corneas" description="Mock tissue inputs used by the matching engine. Select a candidate to inspect the signals supplied to AI decision support." flush>
        <div className="grid gap-3 md:grid-cols-3">
          {AVAILABLE_CORNEA_FIXTURES.map((cornea) => (
            <button key={cornea.corneaId} type="button" onClick={() => navigate(`/cases/${cornea.donorCaseId}`)} className="rounded-2xl border border-slate-200 bg-white p-4 text-left transition-colors hover:border-sky-300 hover:bg-sky-50/50">
              <div className="flex items-center justify-between gap-2">
                <span className="font-mono text-xs font-extrabold text-sky-800">{cornea.corneaId}</span>
                <span className={`rounded-full px-2 py-0.5 text-2xs font-extrabold ${cornea.suitability === "Suitable" ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-900"}`}>{cornea.suitability}</span>
              </div>
              <p className="mt-2 text-2xs font-semibold text-slate-500">
                Grade {cornea.grade} · {cornea.branch} · Case {cornea.donorCaseId}
              </p>
              <dl className="mt-3 grid grid-cols-3 gap-2 text-center">
                <div className="rounded-lg bg-sky-50 p-2">
                  <dt className="text-[10px] font-bold text-sky-700">ECD</dt>
                  <dd className="text-xs font-extrabold text-slate-900">{cornea.ecd}</dd>
                </div>
                <div className="rounded-lg bg-slate-50 p-2">
                  <dt className="text-[10px] font-bold text-slate-500">CV</dt>
                  <dd className="text-xs font-extrabold text-slate-900">{cornea.cv}%</dd>
                </div>
                <div className="rounded-lg bg-slate-50 p-2">
                  <dt className="text-[10px] font-bold text-slate-500">HEX</dt>
                  <dd className="text-xs font-extrabold text-slate-900">{cornea.hex}%</dd>
                </div>
              </dl>
              <p className="mt-3 text-2xs font-semibold text-slate-600">Disease screen: {cornea.diseaseScreen}</p>
            </button>
          ))}
        </div>
      </Panel>

      {/* Main Grid: Recipient Table + AI Matching Inspector Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Panel p={0} className="overflow-hidden">
            <div className="border-b border-slate-200 bg-slate-50/80 px-6 py-3">
              <h3 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider">Recipient Waiting List</h3>
            </div>
            <div className="overflow-x-auto">
              <table className={tableClass}>
                <thead className={theadClass}>
                  <tr>
                    <th className={thClass}>Recipient ID</th>
                    <th className={thClass}>Name / Age</th>
                    <th className={thClass}>Diagnosis</th>
                    <th className={thClass}>Waiting</th>
                    <th className={thClass}>Urgency</th>
                    <th className={thClass}>Branch</th>
                    <th className={thClass}>Match Score</th>
                    <th className={thClass}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((r) => (
                    <tr key={r.recipientId} onClick={() => setSelectedRecipient(r)} className={`${trClass} ${selectedRecipient?.recipientId === r.recipientId ? "bg-sky-50/90" : ""}`}>
                      <td className={`${tdClass} font-extrabold text-slate-900`}>{r.recipientId}</td>
                      <td className={tdClass}>
                        <div className="font-bold text-slate-900">{r.name}</div>
                        <div className="text-2xs text-slate-400">
                          {r.age} yrs | {r.sex} | {r.bloodType}
                        </div>
                      </td>
                      <td className={`${tdClass} max-w-xs truncate text-xs text-slate-700 font-medium`}>{r.diagnosis}</td>
                      <td className={`${tdClass} whitespace-nowrap text-xs font-semibold text-slate-600`}>{r.status === "Waiting List" ? "18 days" : r.status === "Eligible" ? "9 days" : "Scheduled"}</td>
                      <td className={tdClass}>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-2xs font-extrabold ${r.urgency === "Emergency" ? "bg-rose-100 text-rose-900 border border-rose-200 animate-pulse" : r.urgency === "High" ? "bg-amber-100 text-amber-900 border border-amber-200" : "bg-slate-100 text-slate-700"}`}
                        >
                          {r.urgency}
                        </span>
                      </td>
                      <td className={tdClass}>{r.assignedBranch}</td>
                      <td className={tdClass}>{r.matchScore ? <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-900 font-extrabold text-xs">{r.matchScore}%</span> : <span className="text-2xs text-slate-400">Pending</span>}</td>
                      <td className={tdClass}>
                        <Button
                          variant="ghost"
                          size="xs"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedRecipient(r);
                          }}
                        >
                          Review Match →
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>
        </div>

        {/* AI Matching Inspector Side Card */}
        <div>
          {selectedRecipient ? (
            <Panel className="p-6 space-y-4 border-sky-200 bg-surface">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <div className="flex items-center gap-1.5 text-2xs font-extrabold text-sky-800 uppercase tracking-wider">
                    <SparklesIcon className="h-3.5 w-3.5 text-sky-600" />
                    AI Recipient Match Matrix
                  </div>
                  <h3 className="text-base font-extrabold text-slate-900 mt-1">{selectedRecipient.name}</h3>
                  <p className="text-2xs text-slate-500 font-bold">{selectedRecipient.recipientId}</p>
                </div>
                {selectedRecipient.matchScore && (
                  <div className="text-right">
                    <span className="text-2xl font-extrabold text-emerald-600">{selectedRecipient.matchScore}%</span>
                    <p className="text-[10px] font-extrabold text-emerald-800 uppercase">Match Compatibility</p>
                  </div>
                )}
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500 font-bold">Diagnosis:</span>
                  <span className="text-slate-900 font-extrabold text-right max-w-[180px] truncate">{selectedRecipient.diagnosis}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500 font-bold">Matched Donor Case:</span>
                  <span className="text-sky-800 font-extrabold">{selectedRecipient.matchedCaseId ?? "Searching..."}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500 font-bold">Assigned Branch:</span>
                  <span className="text-slate-900 font-extrabold">{selectedRecipient.assignedBranch}</span>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-sky-50 border border-sky-200 space-y-1.5">
                <h5 className="text-2xs font-extrabold text-sky-900 uppercase tracking-wider">AI Matching Factors</h5>
                <ul className="text-2xs text-sky-950 font-medium space-y-1 list-disc list-inside">
                  <li>Donor ECD (&gt;2,600 cells/mm²) matches EK surgery requirement</li>
                  <li>Zero endothelial folds detected by AI specular model</li>
                  <li>Compatible blood type ({selectedRecipient.bloodType})</li>
                  <li>Cold preservation duration &lt;48 hours</li>
                </ul>
              </div>

              {selectedRecipient.matchedCaseId && (
                <div className="space-y-2">
                  <Button variant="secondary" size="md" className="w-full justify-center" onClick={() => navigate(`/cases/${selectedRecipient.matchedCaseId}`)}>
                    Open Donor Case #{selectedRecipient.matchedCaseId} →
                  </Button>
                  {can("Recipient", "match") && role !== "Doctor" && (
                    <Button variant="primary" size="md" className="w-full justify-center" onClick={() => handleMatchAction("Match proposed to Doctor")}>
                      Propose Match to Doctor
                    </Button>
                  )}
                  {role === "Doctor" && can("Recipient", "approve") && (
                    <div className="grid grid-cols-2 gap-2">
                      <Button variant="primary" size="sm" onClick={() => handleMatchAction("Match approved")}>
                        Approve Match
                      </Button>
                      <Button variant="secondary" size="sm" onClick={() => handleMatchAction("Match rejected")}>
                        Reject
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </Panel>
          ) : (
            <Panel className="p-8 text-center text-slate-400">Select a recipient to view AI matching scores</Panel>
          )}
        </div>
      </div>
    </div>
  );
}
