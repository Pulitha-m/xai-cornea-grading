import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { TrendingDownIcon, AlertTriangleIcon, CheckCircle2Icon, CalendarIcon, SparklesIcon } from "lucide-react";
import { useBranch } from "../contexts/BranchContext";
import { useSession } from "../contexts/SessionContext";
import { useCaseStore } from "../contexts/CaseStore";
import { PageHeader } from "../components/ui/PageHeader";
import { Panel } from "../components/ui/Panel";
import { Button } from "../components/ui/Button";
import { WorkflowDiagram } from "../components/ui/WorkflowDiagram";
import { tableClass, tdClass, thClass, theadClass, trClass } from "../components/ui/tableStyles";
import type { DonorCase, FollowUpPoint } from "../types/case";

function latestMeasurement(donorCase: DonorCase): FollowUpPoint | undefined {
  return [...donorCase.followUp].reverse().find((point) => point.recorded);
}

export function PostTransplant() {
  const { filterByBranch, activeBranch } = useBranch();
  const { role, can } = useSession();
  const { cases } = useCaseStore();
  const navigate = useNavigate();
  const transplantedCases = cases.filter((donorCase) => donorCase.transplant.intent === "Transplanted");
  const branchRecords = filterByBranch(transplantedCases);
  const records = branchRecords.length > 0 ? branchRecords : transplantedCases;
  const [selectedCaseId, setSelectedCaseId] = useState(records[0]?.caseId);
  const selectedRecord = records.find((donorCase) => donorCase.caseId === selectedCaseId) ?? records[0];
  const selectedMeasurement = selectedRecord ? latestMeasurement(selectedRecord) : undefined;

  const handleWorkflowAction = () => {
    if (selectedRecord) navigate(`/follow-up/${selectedRecord.caseId}`);
  };

  return (
    <div className="space-y-6 pb-12">
      <PageHeader
        eyebrow="Longitudinal Clinical Intelligence"
        title={`Post-Transplant Graft Monitoring — ${activeBranch}`}
        description="Track longitudinal endothelial cell loss (ECD), polymorphism (CV), pleomorphism (HEX), AI cell loss trajectory predictions, and follow-up schedules across 1-month, 3-month, and 1-year visits."
      />

      <WorkflowDiagram
        title="Transplant to graft outcome"
        steps={[
          { label: "Transplant", detail: "Procedure, recipient and baseline endothelial record.", role: "Doctor / Manager", action: "Schedule follow-up", tone: "slate" },
          { label: "Follow-up due", detail: "1 month, 3 months and 1 year checkpoints.", role: "Nurse / Technician", action: "Open visit record", tone: "blue" },
          { label: "Measurements", detail: "ECD, CV, HEX, specular image and observations.", role: "Nurse / Technician", action: "Record and submit data", tone: "green" },
          { label: "AI trajectory", detail: "Trend, anomaly and rejection-risk indicators.", role: "AI decision support", action: "Explain trajectory", tone: "slate" },
          { label: "Clinical outcome", detail: "Longitudinal evidence and clinical findings.", role: "Doctor", action: "Sign off or determine action", tone: "amber" },
        ]}
      />

      {/* Telemetry Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Panel className="p-4 bg-emerald-50/70 border-emerald-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase text-emerald-800">
            <span>Optimal Graft Health</span>
            <CheckCircle2Icon className="h-4 w-4 text-emerald-600" />
          </div>
          <p className="mt-2 text-2xl font-extrabold text-emerald-950">{records.filter((r) => latestMeasurement(r)?.graftHealth === "Optimal" || latestMeasurement(r)?.graftHealth === "Stable").length}</p>
          <p className="mt-0.5 text-2xs text-emerald-800 font-semibold">Normal cell loss trajectory</p>
        </Panel>

        <Panel className="p-4 bg-amber-50/70 border-amber-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase text-amber-800">
            <span>Caution / Rejection Risk</span>
            <AlertTriangleIcon className="h-4 w-4 text-amber-600" />
          </div>
          <p className="mt-2 text-2xl font-extrabold text-amber-950">{records.filter((r) => latestMeasurement(r)?.graftHealth === "Caution" || latestMeasurement(r)?.graftHealth === "Rejection Risk").length}</p>
          <p className="mt-0.5 text-2xs text-amber-800 font-semibold">Requires clinical observation</p>
        </Panel>

        <Panel className="p-4 bg-sky-50/70 border-sky-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase text-sky-800">
            <span>Follow-ups Due Today</span>
            <CalendarIcon className="h-4 w-4 text-sky-600" />
          </div>
          <p className="mt-2 text-2xl font-extrabold text-sky-950">{records.filter((r) => r.followUp.some((point) => !point.recorded)).length}</p>
          <p className="mt-0.5 text-2xs text-sky-800 font-semibold">Scheduled clinic visits</p>
        </Panel>

        <Panel className="p-4 bg-slate-50 border-slate-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase text-slate-500">
            <span>Avg 1-Year Cell Loss</span>
            <TrendingDownIcon className="h-4 w-4 text-slate-400" />
          </div>
          <p className="mt-2 text-2xl font-extrabold text-slate-900">14.8 %</p>
          <p className="mt-0.5 text-2xs text-slate-500 font-semibold">International benchmark &lt;20%</p>
        </Panel>
      </div>

      {/* Main Content Layout */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Panel p={0} className="overflow-hidden">
            <div className="border-b border-slate-200 bg-slate-50/80 px-6 py-3">
              <h3 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider">Post-Transplant Follow-Up Schedule</h3>
            </div>
            <div className="overflow-x-auto">
              <table className={tableClass}>
                <thead className={theadClass}>
                  <tr>
                    <th className={thClass}>Case ID</th>
                    <th className={thClass}>Recipient</th>
                    <th className={thClass}>Visit</th>
                    <th className={thClass}>Baseline → Current ECD</th>
                    <th className={thClass}>Cell Loss %</th>
                    <th className={thClass}>Graft Health</th>
                    <th className={thClass}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {records.map((r) => {
                    const measurement = latestMeasurement(r);
                    return (
                      <tr key={r.caseId} onClick={() => setSelectedCaseId(r.caseId)} className={`${trClass} ${selectedRecord?.caseId === r.caseId ? "bg-sky-50/90" : ""}`}>
                        <td className={`${tdClass} font-extrabold text-sky-900`}>{r.caseId}</td>
                        <td className={tdClass}>
                          <div className="font-bold text-slate-900">{r.transplant.recipientRef ?? "Recipient not recorded"}</div>
                          <div className="text-2xs text-slate-400">Surgeon: {r.transplant.surgeon ?? "Not recorded"}</div>
                        </td>
                        <td className={tdClass}>
                          <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-800 text-2xs font-extrabold">{measurement?.label ?? "Baseline"}</span>
                        </td>
                        <td className={tdClass}>
                          {r.followUp[0]?.ecd?.toLocaleString() ?? "—"} → <strong className="text-slate-900">{measurement?.ecd?.toLocaleString() ?? "—"}</strong> cells/mm²
                        </td>
                        <td className={tdClass}>
                          <span className={`font-extrabold text-xs ${measurement?.ecd !== null && measurement?.ecd !== undefined && r.followUp[0]?.ecd && ((r.followUp[0].ecd - measurement.ecd) / r.followUp[0].ecd) * 100 > 25 ? "text-amber-800" : "text-emerald-700"}`}>
                            {measurement?.ecd && r.followUp[0]?.ecd ? `-${(((r.followUp[0].ecd - measurement.ecd) / r.followUp[0].ecd) * 100).toFixed(1)}%` : "—"}
                          </span>
                        </td>
                        <td className={tdClass}>
                          <span className={`px-2.5 py-0.5 rounded-full text-2xs font-extrabold ${measurement?.graftHealth === "Optimal" ? "bg-emerald-100 text-emerald-900" : measurement?.graftHealth === "Stable" ? "bg-sky-100 text-sky-900" : "bg-amber-100 text-amber-900"}`}>
                            {measurement?.graftHealth ?? "Monitoring"}
                          </span>
                        </td>
                        <td className={tdClass}>
                          <Button
                            variant="ghost"
                            size="xs"
                            onClick={(e) => {
                              e.stopPropagation();
                              navigate(`/cases/${r.caseId}`);
                            }}
                          >
                            View Case →
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Panel>
        </div>

        {/* Selected Graft Longitudinal Detail Panel */}
        <div>
          {selectedRecord ? (
            <Panel className="bg-surface border-sky-200">
              <div className="space-y-5">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <div className="flex items-center gap-1 text-2xs font-extrabold text-sky-800 uppercase tracking-wider">
                      <SparklesIcon className="h-3.5 w-3.5 text-sky-600" />
                      AI Longitudinal Trajectory
                    </div>
                    <h3 className="text-base font-extrabold text-slate-900 mt-1">{selectedRecord.transplant.recipientRef ?? "Recipient not recorded"}</h3>
                    <p className="text-2xs text-slate-500 font-bold">Case #{selectedRecord.caseId}</p>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-extrabold">{selectedMeasurement?.graftHealth ?? "Monitoring"}</span>
                </div>

                {/* Morphology Metrics Grid */}
                <div className="grid grid-cols-1 gap-3 text-center sm:grid-cols-3">
                  <div className="p-2.5 rounded-2xl bg-sky-50 border border-sky-100">
                    <div className="text-[10px] font-extrabold text-sky-800 uppercase">Current ECD</div>
                    <div className="text-sm font-extrabold text-sky-950 mt-0.5">{selectedMeasurement?.ecd?.toLocaleString() ?? "—"}</div>
                    <div className="text-[10px] text-sky-700">cells/mm²</div>
                  </div>

                  <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200">
                    <div className="text-[10px] font-extrabold text-slate-500 uppercase">CV Polymorph</div>
                    <div className="text-sm font-extrabold text-slate-900 mt-0.5">{selectedMeasurement?.cv ?? "—"}%</div>
                    <div className="text-[10px] text-slate-400">Target &lt;33%</div>
                  </div>

                  <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200">
                    <div className="text-[10px] font-extrabold text-slate-500 uppercase">HEX Hexagon</div>
                    <div className="text-sm font-extrabold text-slate-900 mt-0.5">{selectedMeasurement?.hex ?? "—"}%</div>
                    <div className="text-[10px] text-slate-400">Target &gt;60%</div>
                  </div>
                </div>

                <div className="grid gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-3.5 sm:grid-cols-2">
                  <div>
                    <p className="text-2xs font-extrabold uppercase tracking-wider text-slate-500">Specular image</p>
                    <p className="mt-1 text-xs font-bold text-slate-900">{selectedRecord.image.uploadStatus === "Uploaded" ? "Uploaded" : "Pending"}</p>
                  </div>
                  <div>
                    <p className="text-2xs font-extrabold uppercase tracking-wider text-slate-500">AI interpretation</p>
                    <p className="mt-1 text-xs font-bold text-slate-900">{selectedMeasurement?.notes ?? "Record observations during the next visit."}</p>
                  </div>
                </div>

                {/* Follow-up Timeline Visualization */}
                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-3.5">
                  <h5 className="text-2xs font-extrabold text-slate-700 uppercase tracking-wider">Follow-up Visit Schedule</h5>
                  <div className="mt-3 grid grid-cols-2 gap-3 text-2xs font-bold sm:grid-cols-3 xl:grid-cols-5">
                    {selectedRecord.followUp.map((point) => (
                      <div key={point.label} className="min-w-0 rounded-xl border border-slate-200 bg-white p-2 text-center">
                        <span className={`mx-auto mb-1.5 block h-3 w-3 rounded-full ${point.recorded ? "bg-emerald-500 ring-2 ring-emerald-200" : "bg-amber-400 ring-2 ring-amber-100"}`} />
                        <span className="block truncate">{point.label}</span>
                        <span className="mt-0.5 block truncate text-[10px] text-slate-400">{point.ecd?.toLocaleString() ?? (point.recorded ? "Recorded" : "Scheduled")}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <Button variant="primary" size="md" className="w-full justify-center" onClick={() => navigate(`/cases/${selectedRecord.caseId}`)}>
                  Open Full Graft Record →
                </Button>
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {role !== "Doctor" && can("FollowUp", "edit") && (
                    <Button variant="secondary" size="sm" onClick={handleWorkflowAction}>
                      Record Measurements
                    </Button>
                  )}
                  {role !== "Doctor" && can("FollowUp", "escalate") && (
                    <Button variant="yellow" size="sm" onClick={handleWorkflowAction}>
                      Escalate to Doctor
                    </Button>
                  )}
                  {role === "Doctor" && can("FollowUp", "signoff") && (
                    <Button variant="primary" size="sm" onClick={handleWorkflowAction}>
                      Sign Off Follow-up
                    </Button>
                  )}
                </div>
              </div>
            </Panel>
          ) : (
            <Panel className="p-8 text-center text-slate-400">Select a follow-up record to view longitudinal trajectory</Panel>
          )}
        </div>
      </div>
    </div>
  );
}
