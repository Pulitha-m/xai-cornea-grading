import React, { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";
import { PlayIcon } from "lucide-react";
import { useCaseStore } from "../contexts/CaseStore";
import { MODULE_IDS } from "../data/moduleRegistry";
import { PageHeader } from "../components/ui/PageHeader";
import { Panel } from "../components/ui/Panel";
import { Field } from "../components/ui/Field";
import { Button } from "../components/ui/Button";
import { EmptyState } from "../components/ui/EmptyState";
import { StatusBadge } from "../components/ui/StatusBadge";
import { CaseSelector } from "../components/CaseSelector";
import { TrajectoryChart } from "../components/followup/TrajectoryChart";
import { tableClass, tdClass, thClass, theadClass } from "../components/ui/tableStyles";
import { getResult } from "../utils/caseHelpers";
import { formatDate, formatDateTime } from "../utils/format";

export function FollowUp() {
  const { caseId } = useParams();
  const navigate = useNavigate();
  const { cases, getCase, runModule, recordFollowUp } = useCaseStore();
  const [visitLabel, setVisitLabel] = useState<"Baseline" | "1 month" | "3 months" | "6 months" | "1 year">("3 months");
  const [ecd, setEcd] = useState("");
  const [cv, setCv] = useState("");
  const [hex, setHex] = useState("");
  const [notes, setNotes] = useState("");

  const transplanted = cases.filter((c) => c.transplant.intent === "Transplanted");
  const donorCase = getCase(caseId ?? transplanted[0]?.caseId ?? cases[0]?.caseId);

  if (!donorCase) {
    return (
      <div className="p-8">
        <EmptyState title="No Case Available" description="Create a donor case to track post-transplant follow-up." />
      </div>
    );
  }

  const result = getResult(donorCase, MODULE_IDS.followUp);
  const notTransplanted = donorCase.transplant.intent !== "Transplanted";
  const latestRecorded = [...donorCase.followUp].reverse().find((point) => point.recorded);
  const outcomeNeedsReview =
    (latestRecorded?.ecd !== null && latestRecorded?.ecd !== undefined && latestRecorded.ecd < 2000) || (latestRecorded?.cv !== null && latestRecorded?.cv !== undefined && latestRecorded.cv > 40) || (latestRecorded?.hex !== null && latestRecorded?.hex !== undefined && latestRecorded.hex < 55);
  const clinicalOutcome = !latestRecorded ? "Awaiting measurements" : outcomeNeedsReview ? "Clinical review recommended" : "Stable graft trajectory";

  const handleRun = () => {
    runModule(donorCase.caseId, MODULE_IDS.followUp);
    toast.info("Follow-up monitoring run requested", {
      description: "Monitoring analysis simulated for demonstration.",
    });
  };

  const handleRecordMeasurements = (event: React.FormEvent) => {
    event.preventDefault();
    const numericEcd = Number(ecd);
    const numericCv = Number(cv);
    const numericHex = Number(hex);
    if (!ecd || !cv || !hex || [numericEcd, numericCv, numericHex].some((value) => Number.isNaN(value))) {
      toast.error("Enter ECD, CV, and HEX measurements before saving.");
      return;
    }
    const graftHealth = numericEcd < 2000 || numericCv > 40 || numericHex < 55 ? "Caution" : numericEcd < 2200 ? "Stable" : "Optimal";
    recordFollowUp(donorCase.caseId, {
      label: visitLabel,
      date: new Date().toISOString(),
      ecd: numericEcd,
      cv: numericCv,
      hex: numericHex,
      graftHealth,
      recorded: true,
      notes: notes.trim() || "Measurements recorded for clinical review.",
    });
    setEcd("");
    setCv("");
    setHex("");
    setNotes("");
    toast.success(`${visitLabel} measurements recorded`, { description: "Clinical outcome prediction updated below." });
  };

  return (
    <div className="space-y-6 pb-12">
      <PageHeader
        eyebrow={
          <Link to={`/cases/${donorCase.caseId}`} className="font-mono font-bold text-sky-700 hover:underline">
            #{donorCase.caseId}
          </Link>
        }
        title="Post-Transplant Graft Follow-up"
        description="Longitudinal graft metrics from baseline to 1 year post-operative review."
        actions={
          <>
            <CaseSelector value={donorCase.caseId} onChange={(id) => navigate(`/follow-up/${id}`)} />
            <Button variant="primary" size="md" onClick={handleRun} disabled={result.status === "Running"}>
              <PlayIcon className="h-4 w-4" />
              {result.status === "Running" ? "Running…" : "Run Monitoring"}
            </Button>
          </>
        }
      />

      {notTransplanted ? (
        <div className="p-6">
          <EmptyState
            title="Case Has Not Proceeded to Transplantation"
            description={`Allocation status for ${donorCase.caseId} is "${donorCase.transplant.intent}". Follow-up monitoring applies once a transplant occurs.`}
            action={
              transplanted.length > 0 ? (
                <Link to={`/follow-up/${transplanted[0].caseId}`}>
                  <Button variant="secondary" size="md">
                    View Transplanted Case
                  </Button>
                </Link>
              ) : undefined
            }
          />
        </div>
      ) : (
        <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_minmax(0,20rem)]">
          <div className="min-w-0 space-y-8">
            <div className="grid gap-5 lg:grid-cols-3">
              <TrajectoryChart title="Cell Density (ECD)" metric="ecd" unit="cells/mm²" points={donorCase.followUp} />
              <TrajectoryChart title="Variation (CV)" metric="cv" unit="%" points={donorCase.followUp} />
              <TrajectoryChart title="Hexagonality (HEX)" metric="hex" unit="%" points={donorCase.followUp} />
            </div>

            <Panel title="Record Measurements" description="Save the measurements from the selected follow-up visit to update the graft trajectory.">
              <form onSubmit={handleRecordMeasurements} className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                <label className="text-xs font-semibold text-slate-700">
                  Visit
                  <select value={visitLabel} onChange={(event) => setVisitLabel(event.target.value as typeof visitLabel)} className="mt-1 h-10 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-semibold text-slate-800">
                    {donorCase.followUp.map((point) => (
                      <option key={point.label} value={point.label}>
                        {point.label}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="text-xs font-semibold text-slate-700">
                  ECD (cells/mm²)
                  <input type="number" min="0" value={ecd} onChange={(event) => setEcd(event.target.value)} className="mt-1 h-10 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-semibold text-slate-800" required />
                </label>
                <label className="text-xs font-semibold text-slate-700">
                  CV (%)
                  <input type="number" min="0" value={cv} onChange={(event) => setCv(event.target.value)} className="mt-1 h-10 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-semibold text-slate-800" required />
                </label>
                <label className="text-xs font-semibold text-slate-700">
                  HEX (%)
                  <input type="number" min="0" value={hex} onChange={(event) => setHex(event.target.value)} className="mt-1 h-10 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-semibold text-slate-800" required />
                </label>
                <div className="flex items-end">
                  <Button type="submit" variant="primary" className="w-full justify-center">
                    Save Visit
                  </Button>
                </div>
                <label className="text-xs font-semibold text-slate-700 sm:col-span-2 lg:col-span-5">
                  Clinical observations
                  <textarea value={notes} onChange={(event) => setNotes(event.target.value)} rows={2} placeholder="Add findings for the clinical review..." className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-800" />
                </label>
              </form>
            </Panel>

            <Panel title="Longitudinal Measurements" description="Measurements recorded at scheduled check-ups." flush>
              <div className="overflow-x-auto">
                <table className={tableClass}>
                  <thead className={theadClass}>
                    <tr>
                      <th scope="col" className={thClass}>
                        Timepoint
                      </th>
                      <th scope="col" className={thClass}>
                        Date
                      </th>
                      <th scope="col" className={thClass}>
                        ECD (cells/mm²)
                      </th>
                      <th scope="col" className={thClass}>
                        CV (%)
                      </th>
                      <th scope="col" className={thClass}>
                        HEX (%)
                      </th>
                      <th scope="col" className={thClass}>
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {donorCase.followUp.map((point) => (
                      <tr key={point.label}>
                        <td className={`${tdClass} font-bold text-slate-900`}>{point.label}</td>
                        <td className={`${tdClass} whitespace-nowrap text-xs text-slate-600`}>{point.date ? formatDate(point.date) : "—"}</td>
                        <td className={`${tdClass} font-mono text-xs font-bold text-sky-700`}>{point.ecd?.toLocaleString() ?? "—"}</td>
                        <td className={`${tdClass} font-mono text-xs text-slate-700`}>{point.cv ?? "—"}</td>
                        <td className={`${tdClass} font-mono text-xs text-slate-700`}>{point.hex ?? "—"}</td>
                        <td className={`${tdClass} text-xs`}>
                          <span className={`px-2 py-0.5 rounded-full text-2xs font-bold ${point.recorded ? "bg-emerald-100 text-emerald-800" : "bg-slate-100 text-slate-400"}`}>{point.recorded ? "Recorded" : "Scheduled"}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Panel>
          </div>

          <aside className="space-y-8 xl:sticky xl:top-6 xl:self-start">
            <Panel title="Clinical Outcome Prediction" description="Rule-based screening from the latest recorded graft measurements.">
              <p className={`text-sm font-extrabold ${outcomeNeedsReview ? "text-amber-800" : "text-emerald-800"}`}>{clinicalOutcome}</p>
              <p className="mt-2 text-xs leading-relaxed text-slate-600">{latestRecorded ? "A Doctor should confirm the outcome when measurements fall outside the reference range." : "Record a follow-up visit to generate a clinical outcome prediction."}</p>
            </Panel>
            <Panel title="Monitoring Module" meta={<StatusBadge status={result.status} />}>
              <dl className="space-y-3">
                <Field label="Trajectory Status" value={result.outputs.find((o) => o.label === "Trajectory Status")?.value ?? null} provenance="AI Analysis" />
                <Field label="Anomaly Status" value={result.outputs.find((o) => o.label === "Anomaly Status")?.value ?? null} provenance="AI Analysis" />
                <Field label="Cumulative ECD Change" value={result.outputs.find((o) => o.label === "Cumulative ECD change")?.value ?? null} unit="%" mono />
                <Field label="Last Execution" value={result.lastRun ? formatDateTime(result.lastRun) : "Never"} />
              </dl>
            </Panel>

            <Panel title="Transplant Record">
              <dl className="space-y-3">
                <Field label="Recipient Ref" value={donorCase.transplant.recipientRef} mono />
                <Field label="Procedure" value={donorCase.transplant.procedure} />
                <Field label="Surgery Date" value={donorCase.transplant.surgeryDate ? formatDate(donorCase.transplant.surgeryDate) : null} />
                <Field label="Surgeon" value={donorCase.transplant.surgeon} />
              </dl>
            </Panel>
          </aside>
        </div>
      )}
    </div>
  );
}
