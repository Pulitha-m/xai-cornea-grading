import React, { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { toast } from 'sonner';
import { AlertTriangleIcon, FileTextIcon, InfoIcon, MessageSquarePlusIcon, ShieldCheckIcon } from 'lucide-react';
import { useCaseStore } from '../contexts/CaseStore';
import { useSession } from '../contexts/SessionContext';
import { MODULE_IDS } from '../data/moduleRegistry';
import { REVIEWERS } from '../data/cases';
import { PageHeader } from '../components/ui/PageHeader';
import { Panel } from '../components/ui/Panel';
import { Field } from '../components/ui/Field';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { StatusBadge } from '../components/ui/StatusBadge';
import { ProvenanceTag } from '../components/ui/ProvenanceTag';
import { CaseSelector } from '../components/CaseSelector';
import { getResult, missingInformation } from '../utils/caseHelpers';
import { formatDate, formatDateTime } from '../utils/format';

const inputClass =
  'h-10 w-full rounded-2xl border border-slate-200 bg-slate-50 px-3.5 text-xs font-semibold text-slate-800 focus:border-sky-500 focus:bg-surface focus:outline-none transition-all';

export function TransplantDecisionSupport() {
  const { caseId } = useParams();
  const navigate = useNavigate();
  const { cases, getCase, recordSpecialistDecision, addNote } = useCaseStore();
  const { user, can } = useSession();
  const donorCase = getCase(caseId ?? cases[0]?.caseId);
  const canDecide = can('Donor', 'evaluate');

  const [showDecision, setShowDecision] = useState(false);
  const [showNote, setShowNote] = useState(false);
  const [outcome, setOutcome] = useState<'Suitable' | 'Marginal' | 'Not Suitable' | 'Approved' | 'Rejected' | 'Further Review'>('Suitable');
  const [decidedBy, setDecidedBy] = useState(
    user && REVIEWERS.includes(user.name) ? user.name : REVIEWERS[0]
  );
  const [rationale, setRationale] = useState('');
  const [note, setNote] = useState('');

  if (!donorCase) {
    return (
      <div className="p-8">
        <EmptyState title="No Case Available" description="Create a donor case to access specialist review." />
      </div>
    );
  }

  const cellular = getResult(donorCase, MODULE_IDS.cellular);
  const grade = getResult(donorCase, MODULE_IDS.grade);
  const disease = getResult(donorCase, MODULE_IDS.disease);
  const decision = getResult(donorCase, MODULE_IDS.decision);
  const missing = missingInformation(donorCase);

  const numeric = (label: string): number | null => {
    const raw = cellular.outputs.find((o) => o.label === label)?.value;
    if (!raw) return null;
    const parsed = Number(raw.replace(/,/g, ''));
    return Number.isNaN(parsed) ? null : parsed;
  };

  const ecd = numeric('ECD');
  const cv = numeric('CV');
  const hex = numeric('HEX');
  const predictedGradeValue = grade.outputs.find((o) => o.label === 'Predicted Grade')?.value ?? null;
  const severity = disease.outputs.find((o) => o.label === 'Severity')?.value ?? null;

  const concerns: string[] = [];
  if (ecd !== null && ecd < 2000) concerns.push(`Cellular ECD ${ecd.toLocaleString()} cells/mm² is below the eye-bank reference threshold of 2,000.`);
  if (cv !== null && cv > 40) concerns.push(`Coefficient of variation ${cv}% exceeds the 40% maximum threshold.`);
  if (hex !== null && hex < 55) concerns.push(`Hexagonality ${hex}% is below the 55% minimum threshold.`);
  if ((donorCase.donor.deathToPreservationHours ?? 0) > 12)
    concerns.push(`Death-to-preservation interval of ${donorCase.donor.deathToPreservationHours} hours is extended.`);
  if (predictedGradeValue === 'B') concerns.push('Predicted grade B — lowest grade on the eye-bank scale.');
  if (grade.confidence !== null && grade.confidence < 0.75)
    concerns.push(`Grade prediction confidence ${grade.confidence.toFixed(2)} is below the 0.75 review threshold.`);
  if (severity && severity !== 'None') concerns.push(`Disease Intelligence reports ${severity.toLowerCase()} severity indicators.`);

  const evidence = [
    {
      source: 'Donor Information',
      value: `${donorCase.donor.age}y · ${donorCase.donor.sex} · ${donorCase.donor.eye} · ${donorCase.donor.causeOfDeath}`,
      provenance: 'Staff Entered' as const,
      status: 'Available'
    },
    {
      source: 'Clinical Bench Observations',
      value: donorCase.clinical.slitLampFindings,
      provenance: 'Staff Entered' as const,
      status: donorCase.clinical.slitLampFindings === 'Not yet recorded' ? 'Missing' : 'Available'
    },
    {
      source: 'Reference ECD',
      value: donorCase.clinical.referenceEcd ? `${donorCase.clinical.referenceEcd.toLocaleString()} cells/mm²` : 'Not recorded',
      provenance: 'Reference Measurement' as const,
      status: donorCase.clinical.referenceEcd ? 'Available' : 'Missing'
    },
    {
      source: 'Cellular Biomarkers',
      value: cellular.resultSummary ?? 'No result written',
      provenance: 'AI Analysis' as const,
      status: cellular.status
    },
    {
      source: 'Neural Grade Prediction',
      value: predictedGradeValue ? `Predicted Grade ${predictedGradeValue}` : 'Not predicted',
      provenance: 'AI Prediction' as const,
      status: grade.status
    }
  ];

  const handleRecordDecision = () => {
    if (!rationale.trim()) {
      toast.error('A clinical rationale is required to save a specialist decision.');
      return;
    }
    recordSpecialistDecision(donorCase.caseId, {
      outcome,
      decidedBy,
      decidedAt: new Date().toISOString(),
      rationale: rationale.trim(),
      signature: decidedBy
    });
    setShowDecision(false);
    setRationale('');
    toast.success('Specialist decision recorded', { description: `${donorCase.caseId} — ${outcome}` });
  };

  const handleAddNote = () => {
    if (!note.trim()) return;
    addNote(donorCase.caseId, note.trim());
    setNote('');
    setShowNote(false);
    toast.success('Clinical note added');
  };

  return (
    <div className="space-y-6 pb-12">
      <PageHeader
        eyebrow={
          <Link to={`/cases/${donorCase.caseId}`} className="font-mono font-bold text-sky-700 hover:underline">
            #{donorCase.caseId}
          </Link>
        }
        title="Specialist Clinical Review"
        description="Consolidated clinical evidence assembled for corneal specialist decision sign-off."
        actions={
          <>
            <CaseSelector value={donorCase.caseId} onChange={(id) => navigate(`/review/${id}`)} />
            <Link to={`/reports/${donorCase.caseId}`}>
              <Button variant="secondary" size="md">
                <FileTextIcon className="h-4 w-4" />
                Generate Report
              </Button>
            </Link>
          </>
        }
      />

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_minmax(0,21rem)]">
        <div className="min-w-0 space-y-6">
          <Panel
            title="Neural Decision Support Summary"
            description="Aggregated multi-module predictions."
            meta={<StatusBadge status={decision.status} />}>
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Support Summary" value={decision.resultSummary} provenance="AI Analysis" />
              <Field label="Last Execution" value={decision.lastRun ? formatDateTime(decision.lastRun) : 'Never'} />
              <Field label="Module Version" value={decision.version} mono />
            </div>
            <p className="mt-4 flex items-start gap-2 rounded-2xl border border-sky-200 bg-sky-50/70 p-3 text-xs leading-relaxed text-sky-900 font-medium">
              <InfoIcon className="mt-0.5 h-4 w-4 shrink-0 text-sky-600" />
              AI decision support tool. Final tissue release or withholding decisions require specialist authorization.
            </p>
          </Panel>

          <Panel title="Consolidated Evidence Matrix" description="All clinical signals with provenance markers.">
            <ul className="divide-y divide-slate-100">
              {evidence.map((item) => (
                <li key={item.source} className="flex flex-wrap items-center gap-x-4 gap-y-1 py-3">
                  <div className="flex w-52 shrink-0 items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{item.source}</span>
                  </div>
                  <span className="min-w-0 flex-1 text-xs font-medium text-slate-700">{item.value}</span>
                  <ProvenanceTag provenance={item.provenance} />
                </li>
              ))}
            </ul>
          </Panel>

          <Panel title="Potential Clinical Concerns" description="Rule-based checks against reference ranges.">
            {concerns.length === 0 ? (
              <p className="text-xs text-slate-500">No clinical concerns flagged by threshold checks.</p>
            ) : (
              <ul className="space-y-2">
                {concerns.map((concern) => (
                  <li key={concern} className="flex items-start gap-2 rounded-2xl border border-amber-200 bg-amber-50 p-3 text-xs leading-relaxed text-amber-900 font-semibold">
                    <AlertTriangleIcon className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
                    <span>{concern}</span>
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        </div>

        <aside className="space-y-6 xl:sticky xl:top-6 xl:self-start">
          <div className="rounded-3xl border border-slate-200 bg-surface p-6 shadow-bento">
            <p className="text-2xs font-bold uppercase tracking-wider text-slate-400">
              Final Clinical Decision State
            </p>
            <p className="mt-1.5 text-lg font-extrabold leading-tight text-slate-900">
              {donorCase.specialistDecision?.outcome ?? 'Pending Specialist Review'}
            </p>
            <p className="mt-1 text-2xs text-slate-400">
              {donorCase.specialistDecision
                ? `Recorded by ${donorCase.specialistDecision.decidedBy} on ${formatDate(donorCase.specialistDecision.decidedAt)}.`
                : 'Requires authorized specialist sign-off.'}
            </p>

            <div className="mt-5 space-y-2.5">
              {canDecide && (
                <>
                  <Button variant="yellow" size="md" className="w-full" onClick={() => setShowDecision((v) => !v)}>
                    <ShieldCheckIcon className="h-4 w-4" />
                    Record Specialist Decision
                  </Button>
                  <Button variant="secondary" size="md" className="w-full" onClick={() => setShowNote((v) => !v)}>
                    <MessageSquarePlusIcon className="h-4 w-4" />
                    Add Clinical Note
                  </Button>
                </>
              )}

              {canDecide && showDecision && (
                <div className="mt-4 space-y-3 border-t border-slate-100 pt-4">
                  <div>
                    <label htmlFor="decision-outcome" className="mb-1 block text-2xs font-bold uppercase tracking-wider text-slate-400">
                      Decision Outcome
                    </label>
                    <select id="decision-outcome" value={outcome} onChange={(e) => setOutcome(e.target.value as any)} className={inputClass}>
                      <option value="Suitable">Suitable for transplantation</option>
                      <option value="Marginal">Marginal — requires caution</option>
                      <option value="Not Suitable">Not Suitable — withhold from allocation</option>
                      <option value="Further Review">Deferred — further information required</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="decided-by" className="mb-1 block text-2xs font-bold uppercase tracking-wider text-slate-400">
                      Specialist Name
                    </label>
                    <select id="decided-by" value={decidedBy} onChange={(e) => setDecidedBy(e.target.value)} className={inputClass}>
                      {REVIEWERS.map((reviewer) => (
                        <option key={reviewer}>{reviewer}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label htmlFor="decision-rationale" className="mb-1 block text-2xs font-bold uppercase tracking-wider text-slate-400">
                      Clinical Rationale
                    </label>
                    <textarea
                      id="decision-rationale"
                      rows={3}
                      value={rationale}
                      onChange={(e) => setRationale(e.target.value)}
                      placeholder="Enter clinical rationale..."
                      className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-900 focus:border-sky-500 focus:outline-none"
                    />
                  </div>
                  <Button variant="primary" size="md" className="w-full" onClick={handleRecordDecision}>
                    Save Specialist Decision
                  </Button>
                </div>
              )}

              {canDecide && showNote && (
                <div className="mt-4 space-y-2 border-t border-slate-100 pt-4">
                  <textarea
                    rows={3}
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder="Type clinical note..."
                    className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-900 focus:border-sky-500 focus:outline-none"
                  />
                  <Button variant="secondary" size="md" className="w-full" onClick={handleAddNote}>
                    Save Note
                  </Button>
                </div>
              )}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}