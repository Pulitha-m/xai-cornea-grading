import React, { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { ArrowLeftIcon, CheckIcon, ImageIcon, UploadIcon } from 'lucide-react';
import { useCaseStore } from '../contexts/CaseStore';
import { useBranch } from '../contexts/BranchContext';
import { emptyModuleResult } from '../data/cases';
import { moduleRegistry, MODULE_IDS } from '../data/moduleRegistry';
import type { DonorCase, ModuleResult } from '../types/case';
import { PageHeader } from '../components/ui/PageHeader';
import { Panel } from '../components/ui/Panel';
import { Button } from '../components/ui/Button';
import { Field } from '../components/ui/Field';
import { nextCaseId } from '../utils/caseHelpers';
import { formatDate } from '../utils/format';

const STEPS = [
  { id: 1, label: 'Donor Information' },
  { id: 2, label: 'Clinical Information' },
  { id: 3, label: 'Endothelial Image' },
  { id: 4, label: 'Review and Create Case' }
];

const inputClass =
  'h-10 w-full rounded-2xl border border-slate-200 bg-slate-50/50 px-3.5 text-xs font-semibold text-slate-800 focus:border-sky-500 focus:bg-surface focus:outline-none transition-all';
const textareaClass =
  'w-full rounded-2xl border border-slate-200 bg-slate-50/50 p-3 text-xs text-slate-800 focus:border-sky-500 focus:bg-surface focus:outline-none transition-all';
const labelClass = 'mb-1.5 block text-2xs font-bold uppercase tracking-wider text-slate-400';

interface FormState {
  donorId: string;
  age: string;
  sex: 'Male' | 'Female';
  collectionDate: string;
  eye: 'Right (OD)' | 'Left (OS)';
  causeOfDeath: string;
  deathToPreservationHours: string;
  serology: string;
  relevantHistory: string;
  slitLampFindings: string;
  epithelialStatus: string;
  stromalClarity: string;
  endothelialFolds: string;
  arcusSenilis: string;
  storageMedium: string;
  storageTemperatureC: string;
  preservationDate: string;
  referenceEcd: string;
  observationNotes: string;
  imageFileName: string;
  imagePreviewUrl: string | null;
}

const today = new Date().toISOString().slice(0, 10);

const INITIAL: FormState = {
  donorId: '',
  age: '',
  sex: 'Male',
  collectionDate: today,
  eye: 'Right (OD)',
  causeOfDeath: '',
  deathToPreservationHours: '',
  serology: 'Pending',
  relevantHistory: '',
  slitLampFindings: '',
  epithelialStatus: '',
  stromalClarity: '',
  endothelialFolds: '',
  arcusSenilis: '',
  storageMedium: 'Optisol-GS',
  storageTemperatureC: '4',
  preservationDate: today,
  referenceEcd: '',
  observationNotes: '',
  imageFileName: '',
  imagePreviewUrl: null
};

export function NewDonorCase() {
  const { cases, createCase, currentUser } = useCaseStore();
  const { activeBranch } = useBranch();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState<FormState>(INITIAL);

  const caseId = useMemo(() => nextCaseId(cases.map((c) => c.caseId)), [cases]);

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const donorValid = form.donorId.trim() !== '' && form.age.trim() !== '' && form.causeOfDeath.trim() !== '';

  const handleFile = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    set('imageFileName', file.name);
    set('imagePreviewUrl', URL.createObjectURL(file));
  };

  const handleCreate = () => {
    const modules: Record<string, ModuleResult> = {};
    moduleRegistry.forEach((definition) => {
      modules[definition.id] = emptyModuleResult(definition.id, {
        missingInputs:
          definition.id === MODULE_IDS.followUp
            ? []
            : form.imageFileName === '' && definition.expectedInputs.includes('Endothelial image')
            ? ['Endothelial image']
            : [],
        statusNote:
          definition.id === MODULE_IDS.followUp ? 'Case has not proceeded to transplantation.' : undefined
      });
    });

    const actualBranch = activeBranch === 'All Branches' ? 'Colombo' : activeBranch;

    const donorCase: DonorCase = {
      caseId,
      branch: actualBranch,
      donorStatus: 'Registered',
      corneaStatus: 'Collected',
      ownership: {
        primaryOwner: currentUser,
        currentRole: 'Nurse',
        currentUser,
        assignedBranch: actualBranch,
        nextAction: 'Intake created'
      },
      handoffHistory: [],
      donor: {
        donorId: form.donorId.trim(),
        age: Number(form.age) || 0,
        sex: form.sex,
        collectionDate: form.collectionDate,
        eye: form.eye,
        causeOfDeath: form.causeOfDeath.trim(),
        deathToPreservationHours: form.deathToPreservationHours
          ? Number(form.deathToPreservationHours)
          : null,
        serology: form.serology,
        relevantHistory: form.relevantHistory.trim() || 'None recorded',
        branch: activeBranch === 'All Branches' ? 'Colombo' : activeBranch
      },
      clinical: {
        slitLampFindings: form.slitLampFindings.trim() || 'Not yet recorded',
        epithelialStatus: form.epithelialStatus.trim() || 'Not yet recorded',
        stromalClarity: form.stromalClarity.trim() || 'Not yet recorded',
        endothelialFolds: form.endothelialFolds.trim() || 'Not yet recorded',
        arcusSenilis: form.arcusSenilis.trim() || 'Not recorded',
        storageMedium: form.storageMedium,
        storageTemperatureC: form.storageTemperatureC ? Number(form.storageTemperatureC) : null,
        preservationDate: form.preservationDate,
        referenceEcd: form.referenceEcd ? Number(form.referenceEcd) : null,
        observedBy: currentUser,
        observationNotes: form.observationNotes.trim() || 'None recorded'
      },
      image: {
        fileName: form.imageFileName || '—',
        uploadedAt: form.imageFileName ? new Date().toISOString() : '',
        uploadStatus: form.imageFileName ? 'Uploaded' : 'Not uploaded',
        qualityLabel: form.imageFileName ? 'Pending assessment' : null,
        qualityNote: form.imageFileName
          ? 'Placeholder quality label — automated image quality scoring is not connected.'
          : 'No endothelial image has been uploaded for this case.',
        previewUrl: form.imagePreviewUrl,
        magnification: form.imageFileName ? '×200 specular' : null,
        captureDevice: form.imageFileName ? 'Specular microscope' : null
      },
      modules,
      reviewStatus: 'Pending Review',
      assignedReviewer: null,
      lastUpdated: new Date().toISOString(),
      createdBy: currentUser,
      createdAt: new Date().toISOString(),
      transplant: {
        intent: 'Not allocated',
        recipientRef: null,
        procedure: null,
        surgeryDate: null,
        surgeon: null,
        status: 'Planned'
      },
      followUp: [
        { label: 'Baseline', date: null, ecd: null, cv: null, hex: null, recorded: false },
        { label: '1 month', date: null, ecd: null, cv: null, hex: null, recorded: false },
        { label: '3 months', date: null, ecd: null, cv: null, hex: null, recorded: false },
        { label: '6 months', date: null, ecd: null, cv: null, hex: null, recorded: false },
        { label: '1 year', date: null, ecd: null, cv: null, hex: null, recorded: false }
      ],
      specialistDecision: null,
      notes: []
    };

    createCase(donorCase);
    toast.success(`Case ${caseId} created`, {
      description: 'No analysis has been run. Modules can be run independently from the case.'
    });
    navigate(`/cases/${caseId}`);
  };

  return (
    <div className="space-y-6 pb-12">
      <PageHeader
        eyebrow={
          <span className="flex items-center gap-1.5">
            <ArrowLeftIcon className="h-3.5 w-3.5" />
            <Link to="/cases" className="hover:underline">
              Cases
            </Link>
          </span>
        }
        title="New Donor Cornea Case Intake"
        description="Record donor metadata, clinical bench observations, and endothelial microscopy. AI modules run independently once registered."
      />

      <div className="space-y-6">
        {/* Step Progress Pill Navigation */}
        <ol className="flex flex-wrap items-center gap-2" aria-label="Case creation steps">
          {STEPS.map((s) => {
            const state = s.id === step ? 'current' : s.id < step ? 'done' : 'upcoming';
            return (
              <li key={s.id}>
                <button
                  type="button"
                  onClick={() => s.id <= step && setStep(s.id)}
                  aria-current={state === 'current' ? 'step' : undefined}
                  className={`flex items-center gap-2 rounded-2xl border px-4 py-2.5 text-xs font-bold transition-all ${
                    state === 'current'
                      ? 'border-sky-300 bg-sky-100 text-sky-900 shadow-2xs'
                      : state === 'done'
                      ? 'border-slate-200 bg-surface text-slate-700 hover:bg-slate-50'
                      : 'border-slate-100 bg-slate-50 text-slate-400'
                  }`}
                  disabled={s.id > step}>
                  <span
                    className={`flex h-5 w-5 items-center justify-center rounded-full font-mono text-2xs ${
                      state === 'done'
                        ? 'bg-emerald-600 text-white'
                        : state === 'current'
                        ? 'bg-sky-600 text-white'
                        : 'bg-slate-200 text-slate-500'
                    }`}>
                    {state === 'done' ? <CheckIcon className="h-3 w-3" /> : s.id}
                  </span>
                  {s.label}
                </button>
              </li>
            );
          })}
        </ol>

        <div className="max-w-4xl space-y-6">
          {step === 1 && (
            <Panel title="Step 1 — Donor Information" description="All fields are staff-entered.">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className={labelClass} htmlFor="new-case-id">
                    Case ID
                  </label>
                  <input
                    id="new-case-id"
                    value={caseId}
                    readOnly
                    className={`${inputClass} bg-slate-100 font-mono text-slate-500`}
                  />
                  <p className="mt-1 text-2xs text-slate-400">Generated automatically by system sequence.</p>
                </div>
                <div>
                  <label className={labelClass} htmlFor="donor-id">
                    Donor ID
                  </label>
                  <input
                    id="donor-id"
                    value={form.donorId}
                    onChange={(e) => set('donorId', e.target.value)}
                    placeholder="DNR-2026-0455"
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="donor-age">
                    Age
                  </label>
                  <input
                    id="donor-age"
                    type="number"
                    min="0"
                    max="120"
                    value={form.age}
                    onChange={(e) => set('age', e.target.value)}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="donor-sex">
                    Sex
                  </label>
                  <select
                    id="donor-sex"
                    value={form.sex}
                    onChange={(e) => set('sex', e.target.value as FormState['sex'])}
                    className={inputClass}>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>
                <div>
                  <label className={labelClass} htmlFor="collection-date">
                    Collection Date
                  </label>
                  <input
                    id="collection-date"
                    type="date"
                    value={form.collectionDate}
                    onChange={(e) => set('collectionDate', e.target.value)}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="eye">
                    Eye / Cornea
                  </label>
                  <select
                    id="eye"
                    value={form.eye}
                    onChange={(e) => set('eye', e.target.value as FormState['eye'])}
                    className={inputClass}>
                    <option value="Right (OD)">Right (OD)</option>
                    <option value="Left (OS)">Left (OS)</option>
                  </select>
                </div>
                <div>
                  <label className={labelClass} htmlFor="cause-of-death">
                    Cause of Death
                  </label>
                  <input
                    id="cause-of-death"
                    value={form.causeOfDeath}
                    onChange={(e) => set('causeOfDeath', e.target.value)}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="death-to-preservation">
                    Death to Preservation (hours)
                  </label>
                  <input
                    id="death-to-preservation"
                    type="number"
                    step="0.5"
                    min="0"
                    value={form.deathToPreservationHours}
                    onChange={(e) => set('deathToPreservationHours', e.target.value)}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="serology">
                    Serology Status
                  </label>
                  <select
                    id="serology"
                    value={form.serology}
                    onChange={(e) => set('serology', e.target.value)}
                    className={inputClass}>
                    <option value="Pending">Pending</option>
                    <option value="Non-reactive (HIV, HBV, HCV, Syphilis)">Non-reactive (HIV, HBV, HCV, Syphilis)</option>
                    <option value="Reactive — refer to specialist">Reactive — refer to specialist</option>
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <label className={labelClass} htmlFor="relevant-history">
                    Relevant Donor Medical History
                  </label>
                  <textarea
                    id="relevant-history"
                    rows={3}
                    value={form.relevantHistory}
                    onChange={(e) => set('relevantHistory', e.target.value)}
                    placeholder="Ocular surgery, systemic disease, medication…"
                    className={textareaClass}
                  />
                </div>
              </div>
            </Panel>
          )}

          {step === 2 && (
            <Panel title="Step 2 — Clinical Information" description="Bench observations recorded by eye-bank staff.">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <label className={labelClass} htmlFor="slit-lamp">
                    Slit Lamp Findings
                  </label>
                  <textarea
                    id="slit-lamp"
                    rows={2}
                    value={form.slitLampFindings}
                    onChange={(e) => set('slitLampFindings', e.target.value)}
                    className={textareaClass}
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="epithelial">
                    Epithelial Status
                  </label>
                  <input
                    id="epithelial"
                    value={form.epithelialStatus}
                    onChange={(e) => set('epithelialStatus', e.target.value)}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="stromal">
                    Stromal Clarity
                  </label>
                  <input
                    id="stromal"
                    value={form.stromalClarity}
                    onChange={(e) => set('stromalClarity', e.target.value)}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="folds">
                    Endothelial Folds
                  </label>
                  <input
                    id="folds"
                    value={form.endothelialFolds}
                    onChange={(e) => set('endothelialFolds', e.target.value)}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="arcus">
                    Arcus Senilis
                  </label>
                  <input
                    id="arcus"
                    value={form.arcusSenilis}
                    onChange={(e) => set('arcusSenilis', e.target.value)}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="storage-medium">
                    Storage Medium
                  </label>
                  <input
                    id="storage-medium"
                    value={form.storageMedium}
                    onChange={(e) => set('storageMedium', e.target.value)}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="storage-temp">
                    Storage Temperature (°C)
                  </label>
                  <input
                    id="storage-temp"
                    type="number"
                    value={form.storageTemperatureC}
                    onChange={(e) => set('storageTemperatureC', e.target.value)}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="preservation-date">
                    Preservation Date
                  </label>
                  <input
                    id="preservation-date"
                    type="date"
                    value={form.preservationDate}
                    onChange={(e) => set('preservationDate', e.target.value)}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="reference-ecd">
                    Reference ECD (cells/mm²)
                  </label>
                  <input
                    id="reference-ecd"
                    type="number"
                    value={form.referenceEcd}
                    onChange={(e) => set('referenceEcd', e.target.value)}
                    placeholder="Optional"
                    className={inputClass}
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className={labelClass} htmlFor="observation-notes">
                    Observation Notes
                  </label>
                  <textarea
                    id="observation-notes"
                    rows={3}
                    value={form.observationNotes}
                    onChange={(e) => set('observationNotes', e.target.value)}
                    className={textareaClass}
                  />
                </div>
              </div>
            </Panel>
          )}

          {step === 3 && (
            <Panel
              title="Step 3 — Endothelial Image"
              description="Upload specular microscopy capture for this cornea.">
              <div className="grid gap-5 sm:grid-cols-[minmax(0,1fr)_minmax(0,16rem)]">
                <div>
                  <label
                    htmlFor="endothelial-image"
                    className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50/70 px-4 py-8 text-center transition-all hover:border-sky-500 hover:bg-sky-50">
                    <UploadIcon className="h-6 w-6 text-sky-600" />
                    <span className="text-xs font-bold text-slate-800">Select Endothelial Image</span>
                    <span className="text-2xs text-slate-400">TIFF, PNG or JPEG specular microscopy capture</span>
                    <input id="endothelial-image" type="file" accept="image/*" onChange={handleFile} className="sr-only" />
                  </label>

                  <dl className="mt-4 grid grid-cols-2 gap-4">
                    <Field label="Image Filename" value={form.imageFileName || null} mono />
                    <Field label="Upload Status" value={form.imageFileName ? 'Uploaded' : 'Not uploaded'} />
                    <Field label="Image Quality" value={form.imageFileName ? 'Pending Assessment' : null} />
                    <Field label="Magnification" value={form.imageFileName ? '×200 specular' : null} />
                  </dl>
                </div>

                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-2 flex items-center justify-center">
                  {form.imagePreviewUrl ? (
                    <img src={form.imagePreviewUrl} alt="Preview" className="w-full rounded-xl object-cover" />
                  ) : (
                    <div className="flex flex-col items-center gap-1.5 text-slate-400">
                      <ImageIcon className="h-6 w-6" />
                      <p className="text-2xs">No image selected</p>
                    </div>
                  )}
                </div>
              </div>
            </Panel>
          )}

          {step === 4 && (
            <>
              <Panel title="Step 4 — Review &amp; Register Case" description="Confirm details before case registration.">
                <div className="space-y-6">
                  <div>
                    <h3 className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-400">Donor Summary</h3>
                    <dl className="grid gap-4 sm:grid-cols-3">
                      <Field label="Case ID" value={caseId} mono />
                      <Field label="Donor ID" value={form.donorId || null} mono />
                      <Field label="Age / Sex" value={form.age ? `${form.age} y · ${form.sex}` : null} />
                      <Field label="Collection Date" value={formatDate(form.collectionDate)} />
                      <Field label="Eye" value={form.eye} />
                      <Field label="Cause of Death" value={form.causeOfDeath || null} />
                    </dl>
                  </div>

                  <div className="border-t border-slate-100 pt-4">
                    <h3 className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-400">Clinical &amp; Storage Summary</h3>
                    <dl className="grid gap-4 sm:grid-cols-3">
                      <Field label="Slit Lamp" value={form.slitLampFindings || null} />
                      <Field label="Stromal Clarity" value={form.stromalClarity || null} />
                      <Field label="Storage" value={`${form.storageMedium} · ${form.storageTemperatureC || '—'} °C`} />
                    </dl>
                  </div>
                </div>
              </Panel>
            </>
          )}

          <div className="flex items-center justify-between gap-3 pt-2">
            <Button variant="secondary" size="md" onClick={() => setStep((s) => Math.max(1, s - 1))} disabled={step === 1}>
              Back
            </Button>
            <div className="flex items-center gap-3">
              {step === 1 && !donorValid && (
                <span className="text-2xs font-semibold text-amber-800">Donor ID, age and cause of death are required.</span>
              )}
              {step < 4 ? (
                <Button variant="primary" size="md" onClick={() => setStep((s) => s + 1)} disabled={step === 1 && !donorValid}>
                  Continue
                </Button>
              ) : (
                <Button variant="yellow" size="md" onClick={handleCreate}>
                  Create Donor Case
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}