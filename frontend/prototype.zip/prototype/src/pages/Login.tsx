import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRightIcon, EyeIcon, EyeOffIcon, ShieldCheckIcon, UserIcon, ActivityIcon } from "lucide-react";
import { useSession } from "../contexts/SessionContext";
import { Button } from "../components/ui/Button";
import type { Role } from "../types/user";

export function Login() {
  const { signIn } = useSession();
  const navigate = useNavigate();
  const [staffId, setStaffId] = useState("NEB-A-3011");
  const [selectedRole, setSelectedRole] = useState<Role>("Admin");
  const [password, setPassword] = useState("••••••••");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSignIn = (event: React.FormEvent) => {
    event.preventDefault();
    if (!staffId.trim() || !password.trim()) {
      setError("Enter a valid Staff ID and password to sign in.");
      return;
    }

    signIn(staffId, selectedRole);
    navigate("/", { replace: true });
  };

  return (
    <div className="relative min-h-screen w-full flex items-center justify-center bg-[#f4f6f8] p-4 md:p-8 overflow-hidden">
      {/* Background Ambient Glows */}
      <div className="absolute -top-32 -left-32 h-[30rem] w-[30rem] rounded-full bg-sky-200/40 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 h-[30rem] w-[30rem] rounded-full bg-amber-200/40 blur-3xl pointer-events-none" />

      <div className="relative z-10 w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 rounded-3xl border border-slate-200 bg-surface shadow-bento overflow-hidden">
        {/* HERO LEFT PANEL WITH BACKGROUND.JPG & GLASSMORPHISM OVERLAY */}
        <div className="relative lg:col-span-5 hidden lg:flex flex-col justify-between p-8 text-white overflow-hidden bg-slate-900">
          {/* Background image from public folder */}
          <div className="absolute inset-0 bg-cover bg-center opacity-40 scale-105 transition-transform duration-1000" style={{ backgroundImage: `url('/background.jpg')` }} />
          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-sky-950/40" />

          {/* Top Logo Badge */}
          <div className="relative z-10">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-2xl bg-white/95 p-1.5 shadow-bento flex items-center justify-center border border-white/20 backdrop-blur-md">
                <img src="/new-logo.png" alt="National Eye Bank Logo" className="h-full w-full object-contain" />
              </div>
              <div>
                <p className="text-2xs font-extrabold uppercase tracking-wider text-sky-400">National Eye Bank</p>
                <p className="text-sm font-bold text-white">Sri Lanka Division</p>
              </div>
            </div>
          </div>

          {/* Center Telemetry Quote / Mission */}
          <div className="relative z-10 my-auto py-8">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/20 border border-sky-400/30 text-sky-300 text-2xs font-bold uppercase tracking-wider mb-4">
              <ActivityIcon className="h-3.5 w-3.5" />
              Clinical Decision Support System
            </span>
            <h2 className="text-2xl font-extrabold text-white leading-tight tracking-tight">Precision Corneal Evaluation &amp; Graft Intelligence</h2>
            <p className="text-xs text-slate-300 mt-3 leading-relaxed">Reducing clinical cognitive load with real-time specular microscopy telemetry, neural cell count predictions, and gated decision sign-offs.</p>
          </div>

          {/* Bottom Telemetry Badges */}
          <div className="relative z-10 pt-4 border-t border-white/10 flex items-center justify-between text-2xs text-slate-400 font-semibold">
            <div className="flex items-center gap-1.5 text-emerald-400">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              NEBSL Live Node Active
            </div>
            <span>v2.4 Production</span>
          </div>
        </div>

        {/* RIGHT PANEL: AUTHENTICATION FORM & DEMO PRESETS */}
        <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-between">
          <div>
            {/* Header branding for mobile / top */}
            <div className="flex items-center gap-3 mb-6">
              <div className="h-11 w-11 rounded-2xl bg-slate-50 p-1.5 border border-slate-200 flex items-center justify-center shrink-0">
                <img src="/new-logo.png" alt="National Eye Bank Logo" className="h-full w-full object-contain" />
              </div>
              <div>
                <span className="text-2xs font-extrabold uppercase tracking-wider text-sky-700">National Eye Bank of Sri Lanka</span>
                <h1 className="text-lg font-extrabold text-slate-900 tracking-tight leading-tight">Corneal Command Center Sign-In</h1>
              </div>
            </div>

            <p className="text-xs text-slate-500 mb-6">Enter your assigned eye-bank staff ID to access real-time tissue throughput and specialist review queues.</p>

            {/* Form */}
            <form onSubmit={handleSignIn} className="space-y-4">
              <div>
                <label htmlFor="staff-id" className="mb-1.5 block text-xs font-semibold text-slate-700">
                  Staff Identifier
                </label>
                <div className="relative">
                  <input
                    id="staff-id"
                    value={staffId}
                    onChange={(e) => setStaffId(e.target.value)}
                    placeholder="e.g. NEB-A-3011"
                    autoComplete="username"
                    className="h-11 w-full rounded-2xl border border-slate-200 bg-slate-50/50 px-4 pr-10 font-mono text-sm text-slate-900 placeholder:text-slate-400 focus:border-sky-500 focus:bg-surface focus:outline-none transition-all"
                  />
                  <UserIcon className="absolute right-3.5 top-3 h-5 w-5 text-slate-400 pointer-events-none" />
                </div>
              </div>

              <div>
                <label htmlFor="role" className="mb-1.5 block text-xs font-semibold text-slate-700">
                  Sign in as
                </label>
                <select
                  id="role"
                  value={selectedRole}
                  onChange={(event) => setSelectedRole(event.target.value as Role)}
                  className="h-11 w-full rounded-2xl border border-slate-200 bg-slate-50/50 px-4 text-sm font-semibold text-slate-900 focus:border-sky-500 focus:bg-surface focus:outline-none transition-all"
                >
                  <option value="Admin">Admin - System administration</option>
                  <option value="Manager">Manager - Branch operations</option>
                  <option value="Doctor">Doctor - Clinical review</option>
                  <option value="Nurse">Nurse - Intake and processing</option>
                  <option value="Attendant">Attendant - Transport and storage</option>
                </select>
              </div>

              <div>
                <label htmlFor="password" className="mb-1.5 block text-xs font-semibold text-slate-700">
                  Password
                </label>
                <div className="relative">
                  <input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    autoComplete="current-password"
                    className="h-11 w-full rounded-2xl border border-slate-200 bg-slate-50/50 px-4 pr-10 text-sm text-slate-900 placeholder:text-slate-400 focus:border-sky-500 focus:bg-surface focus:outline-none transition-all"
                  />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 transition-colors">
                    {showPassword ? <EyeOffIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}
                  </button>
                </div>
              </div>

              {error && (
                <p role="alert" className="text-xs font-semibold text-rose-600 bg-rose-50 border border-rose-200 px-3.5 py-2 rounded-xl">
                  {error}
                </p>
              )}

              <Button type="submit" variant="primary" size="md" className="w-full mt-2 py-3">
                Sign In to Command Center
                <ArrowRightIcon className="h-4 w-4" />
              </Button>
            </form>
          </div>

          <div className="mt-6 flex items-center justify-center gap-1.5 text-2xs font-medium text-slate-400">
            <ShieldCheckIcon className="h-4 w-4 text-emerald-600" />
            <span>NEBSL HIPAA &amp; Medical Audit Trail Compliant</span>
          </div>
        </div>
      </div>
    </div>
  );
}
