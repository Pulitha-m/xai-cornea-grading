import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  CheckSquareIcon,
  ClockIcon,
  AlertTriangleIcon,
  CheckCircle2Icon,
  FileTextIcon,
  ArrowRightIcon,
  BuildingIcon,
  FilterIcon,
} from 'lucide-react';
import { useSession } from '../contexts/SessionContext';
import { useBranch } from '../contexts/BranchContext';
import { useTaskStore, type TaskItem, type TaskStatus } from '../contexts/TaskStore';
import { useCaseStore } from '../contexts/CaseStore';
import { PageHeader } from '../components/ui/PageHeader';
import { Panel } from '../components/ui/Panel';
import { Button } from '../components/ui/Button';
import { StatusBadge } from '../components/ui/StatusBadge';

export function MyWork() {
  const { user } = useSession();
  const { filterByBranch, activeBranch } = useBranch();
  const { tasks, updateTaskStatus } = useTaskStore();
  const { cases } = useCaseStore();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState<'tasks' | 'cases' | 'review' | 'completed'>('tasks');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Filter tasks by role & active branch
  const userTasks = filterByBranch(
    tasks.filter((t) => (user?.role === 'Admin' ? true : t.assignedRole === user?.role))
  );

  // Filter cases awaiting review
  const pendingCases = filterByBranch(
    cases.filter((c) => c.reviewStatus === 'Pending Review' || c.reviewStatus === 'Under Review')
  );

  const completedTasks = userTasks.filter((t) => t.status === 'Completed');
  const urgentTasks = userTasks.filter((t) => t.priority === 'Urgent' && t.status !== 'Completed');

  return (
    <div className="space-y-6 pb-12">
      <PageHeader
        eyebrow="Personalized Role Workspace"
        title={`My Work Dashboard — ${user?.displayName ?? 'Staff User'}`}
        description={`Current active branch: ${activeBranch}. View assigned operational tasks, cases awaiting your clinical sign-off, recent progress, and urgent alerts.`}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="sm" onClick={() => navigate('/cases')}>
              View All Cases
            </Button>
          </div>
        }
      />

      {/* Metric Telemetry Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Panel className="p-4 bg-sky-50/70 border-sky-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase tracking-wider text-sky-800">
            <span>My Active Tasks</span>
            <CheckSquareIcon className="h-4 w-4 text-sky-600" />
          </div>
          <p className="mt-2 text-2xl font-extrabold text-sky-950">{userTasks.filter((t) => t.status !== 'Completed').length}</p>
          <p className="mt-0.5 text-2xs text-sky-800 font-semibold">{urgentTasks.length} Urgent priority</p>
        </Panel>

        <Panel className="p-4 bg-amber-50/70 border-amber-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase tracking-wider text-amber-800">
            <span>Awaiting Review</span>
            <ClockIcon className="h-4 w-4 text-amber-600" />
          </div>
          <p className="mt-2 text-2xl font-extrabold text-amber-950">{pendingCases.length}</p>
          <p className="mt-0.5 text-2xs text-amber-800 font-semibold">Requires clinical action</p>
        </Panel>

        <Panel className="p-4 bg-emerald-50/70 border-emerald-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase tracking-wider text-emerald-800">
            <span>Completed Today</span>
            <CheckCircle2Icon className="h-4 w-4 text-emerald-600" />
          </div>
          <p className="mt-2 text-2xl font-extrabold text-emerald-950">{completedTasks.length}</p>
          <p className="mt-0.5 text-2xs text-emerald-800 font-semibold">Tasks finalized</p>
        </Panel>

        <Panel className="p-4 bg-slate-50 border-slate-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase tracking-wider text-slate-500">
            <span>Current Branch</span>
            <BuildingIcon className="h-4 w-4 text-slate-400" />
          </div>
          <p className="mt-2 text-lg font-extrabold text-slate-900 truncate">{activeBranch}</p>
          <p className="mt-0.5 text-2xs text-slate-500 font-semibold">Enforced data scope</p>
        </Panel>
      </div>

      {/* Workspace Tabs Navigation */}
      <Panel p={0} className="overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50/80 px-6 py-3">
          <div className="flex items-center gap-2 overflow-x-auto">
            <button
              onClick={() => setActiveTab('tasks')}
              className={`px-4 py-2 text-xs font-extrabold rounded-2xl transition-all ${
                activeTab === 'tasks'
                  ? 'bg-white text-sky-900 shadow-2xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}>
              My Tasks ({userTasks.length})
            </button>
            <button
              onClick={() => setActiveTab('review')}
              className={`px-4 py-2 text-xs font-extrabold rounded-2xl transition-all ${
                activeTab === 'review'
                  ? 'bg-white text-sky-900 shadow-2xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}>
              Awaiting Review ({pendingCases.length})
            </button>
            <button
              onClick={() => setActiveTab('completed')}
              className={`px-4 py-2 text-xs font-extrabold rounded-2xl transition-all ${
                activeTab === 'completed'
                  ? 'bg-white text-sky-900 shadow-2xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}>
              Recently Completed ({completedTasks.length})
            </button>
          </div>

          <div className="flex items-center gap-2">
            <FilterIcon className="h-3.5 w-3.5 text-slate-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="bg-white border border-slate-200 rounded-xl px-2.5 py-1 text-xs font-bold text-slate-700 focus:outline-none">
              <option value="all">All Priorities</option>
              <option value="Urgent">Urgent Only</option>
              <option value="High">High Priority</option>
            </select>
          </div>
        </div>

        {/* Tab Content Panels */}
        <div className="p-6">
          {activeTab === 'tasks' && (
            <div className="space-y-3">
              {userTasks
                .filter((t) => (filterStatus === 'all' ? true : t.priority === filterStatus))
                .map((task) => (
                  <div
                    key={task.id}
                    className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl bg-white border border-slate-200 hover:border-sky-300 hover:shadow-2xs transition-all">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border ${
                            task.priority === 'Urgent'
                              ? 'bg-rose-100 text-rose-900 border-rose-200'
                              : task.priority === 'High'
                              ? 'bg-amber-100 text-amber-900 border-amber-200'
                              : 'bg-slate-100 text-slate-700 border-slate-200'
                          }`}>
                          {task.priority}
                        </span>
                        <span className="text-2xs font-extrabold text-sky-800 bg-sky-50 px-2 py-0.5 rounded-md border border-sky-100">
                          {task.category}
                        </span>
                        <span className="text-2xs font-bold text-slate-400">Branch: {task.branch}</span>
                      </div>
                      <h4 className="text-sm font-extrabold text-slate-900">{task.title}</h4>
                      {task.notes && <p className="text-xs text-slate-500 mt-1">{task.notes}</p>}
                      <div className="flex items-center gap-4 text-2xs font-bold text-slate-400 mt-2">
                        {task.caseId && (
                          <span>
                            Related Case: <strong className="text-slate-800">{task.caseId}</strong>
                          </span>
                        )}
                        <span>Due: {task.dueDate}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
                      {task.caseId && (
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => navigate(`/cases/${task.caseId}`)}>
                          View Case →
                        </Button>
                      )}

                      {task.status !== 'Completed' ? (
                        <Button
                          variant="primary"
                          size="sm"
                          onClick={() => updateTaskStatus(task.id, 'Completed')}>
                          Mark Complete ✓
                        </Button>
                      ) : (
                        <span className="px-3 py-1 rounded-xl bg-emerald-100 text-emerald-900 text-xs font-extrabold">
                          Completed ✓
                        </span>
                      )}
                    </div>
                  </div>
                ))}
            </div>
          )}

          {activeTab === 'review' && (
            <div className="space-y-3">
              {pendingCases.map((c) => (
                <div
                  key={c.caseId}
                  className="flex items-center justify-between p-4 rounded-2xl bg-white border border-slate-200 hover:border-sky-300 transition-all">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <StatusBadge status={c.reviewStatus} />
                      <span className="text-2xs font-bold text-slate-400">Branch: {c.branch}</span>
                    </div>
                    <h4 className="text-sm font-extrabold text-slate-900">Case #{c.caseId}</h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Donor Age: {c.donor.age} | Eye: {c.donor.eye} | Preservation: {c.clinical.storageMedium}
                    </p>
                  </div>
                  <Button variant="primary" size="sm" onClick={() => navigate(`/cases/${c.caseId}`)}>
                    Review Case →
                  </Button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'completed' && (
            <div className="space-y-3">
              {completedTasks.map((t) => (
                <div key={t.id} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <div className="flex items-center justify-between">
                    <h5 className="text-xs font-extrabold text-slate-800">{t.title}</h5>
                    <span className="text-2xs font-extrabold text-emerald-700">Completed</span>
                  </div>
                  <p className="text-2xs text-slate-400 mt-1">Branch: {t.branch} | Category: {t.category}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </Panel>
    </div>
  );
}
