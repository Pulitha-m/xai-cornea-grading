import React from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { CheckIcon, ImageOffIcon, XIcon } from 'lucide-react';
import { useCaseStore } from '../contexts/CaseStore';
import { MODULE_IDS } from '../data/moduleRegistry';
import { PageHeader } from '../components/ui/PageHeader';
import { Panel } from '../components/ui/Panel';
import { Field } from '../components/ui/Field';
import { EmptyState } from '../components/ui/EmptyState';
import { StatusBadge } from '../components/ui/StatusBadge';
import { Button } from '../components/ui/Button';
import { CaseSelector } from '../components/CaseSelector';
import { getResult } from '../utils/caseHelpers';
import { formatDate, formatDateTime } from '../utils/format';

export function CornealAssessment() {
  const { caseId } = useParams();
  const navigate = useNavigate();
  const { cases, getCase } = useCaseStore();
  const donorCase = getCase(caseId ?? cases[0]?.caseId);

  if (!donorCase) {
    return (
      <div className="p-8">
        <EmptyState title="No Case Available" description="Create a donor case to record a corneal assessment." />
      </div>
    );
  }

  const cellular = getResult(donorCase, MODULE_IDS.cellular);

  const readiness = [
    { label: 'Endothelial image uploaded', ok: donorCase.image.uploadStatus === 'Uploaded' },
    { label: 'Slit lamp findings recorded', ok: donorCase.clinical.slitLampFindings !== 'Not yet recorded' },
    { label: 'Reference ECD recorded', ok: donorCase.clinical.referenceEcd !== null },
    { label: 'Serology available', ok: donorCase.donor.serology !== 'Pending' },
    { label: 'Storage details recorded', ok: donorCase.clinical.storageTemperatureC !== null }
  ];

  return (
    <div className="space-y-6 pb-12">
      <PageHeader
        eyebrow={
          <Link to={`/cases/${donorCase.caseId}`} className="font-mono font-bold text-sky-700 hover:underline">
            #{donorCase.caseId}
          </Link>
        }
        title="Corneal Assessment &amp; Bench Analysis"
        description="Specular microscopy captures and human-entered observations recorded by eye bank technicians."
        actions={
          <>
            <CaseSelector value={donorCase.caseId} onChange={(id) => navigate(`/assessment/${id}`)} />
            <Link to={`/analysis/${donorCase.caseId}?module=${MODULE_IDS.cellular}`}>
              <Button variant="primary" size="md">
                Cellular Morphometry
              </Button>
            </Link>
          </>
        }
      />

      <div className="grid gap-6 xl:grid-cols-[minmax(0,26rem)_minmax(0,1fr)]">
        <Panel
          title="Endothelial Microscopy"
          description="Specular capture held for Case ID."
          meta={<StatusBadge status={cellular.status} label={`Cellular: ${cellular.status}`} />}>
          {donorCase.image.previewUrl ? (
            <figure>
              <img
                src={donorCase.image.previewUrl}
                alt={`Specular microscopy for case ${donorCase.caseId}`}
                className="w-full rounded-2xl border border-slate-200 bg-black object-cover"
              />
              <figcaption className="mt-3 grid grid-cols-2 gap-3">
                <Field label="Filename" value={donorCase.image.fileName} mono />
                <Field label="Uploaded" value={formatDateTime(donorCase.image.uploadedAt)} />
                <Field label="Capture Device" value={donorCase.image.captureDevice} />
                <Field label="Magnification" value={donorCase.image.magnification} />
              </figcaption>
            </figure>
          ) : (
            <EmptyState
              icon={<ImageOffIcon className="h-5 w-5" />}
              title="No image uploaded"
              description="Upload a specular capture from the case record before running image-based modules."
            />
          )}
        </Panel>

        <div className="min-w-0 space-y-6">
          <Panel title="Clinical Observations" description="Human-entered observations at the bench.">
            <dl className="grid gap-4 sm:grid-cols-2">
              <Field label="Slit Lamp Findings" value={donorCase.clinical.slitLampFindings} />
              <Field label="Epithelial Status" value={donorCase.clinical.epithelialStatus} />
              <Field label="Stromal Clarity" value={donorCase.clinical.stromalClarity} />
              <Field label="Endothelial Folds" value={donorCase.clinical.endothelialFolds} />
              <Field label="Arcus Senilis" value={donorCase.clinical.arcusSenilis} />
              <Field label="Observed By" value={donorCase.clinical.observedBy} />
            </dl>
          </Panel>

          <Panel title="Reference Measurements" description="Independent bench parameters.">
            <dl className="grid gap-4 sm:grid-cols-3">
              <Field label="Reference ECD" value={donorCase.clinical.referenceEcd?.toLocaleString() ?? null} unit="cells/mm²" mono />
              <Field label="Storage Medium" value={donorCase.clinical.storageMedium} />
              <Field label="Preservation Date" value={formatDate(donorCase.clinical.preservationDate)} />
            </dl>
          </Panel>

          <Panel title="Assessment Completeness" description="Data readiness for neural processing.">
            <ul className="grid gap-2 sm:grid-cols-2">
              {readiness.map((item) => (
                <li
                  key={item.label}
                  className="flex items-center gap-2.5 rounded-2xl border border-slate-200 bg-slate-50/60 px-3 py-2.5 text-xs font-semibold">
                  {item.ok ? (
                    <CheckIcon className="h-4 w-4 shrink-0 text-emerald-600" />
                  ) : (
                    <XIcon className="h-4 w-4 shrink-0 text-amber-600" />
                  )}
                  <span className={item.ok ? 'text-slate-900' : 'text-slate-500'}>{item.label}</span>
                  <span className="ml-auto text-2xs font-bold text-slate-400">{item.ok ? 'Recorded' : 'Missing'}</span>
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      </div>
    </div>
  );
}