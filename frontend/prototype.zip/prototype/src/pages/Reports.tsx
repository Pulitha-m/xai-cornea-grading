import React from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { PrinterIcon } from 'lucide-react';
import { useCaseStore } from '../contexts/CaseStore';
import { MODULE_IDS } from '../data/moduleRegistry';
import { PageHeader } from '../components/ui/PageHeader';
import { Field } from '../components/ui/Field';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { ProvenanceTag } from '../components/ui/ProvenanceTag';
import { CaseSelector } from '../components/CaseSelector';
import { tableClass, tdClass, thClass, theadClass } from '../components/ui/tableStyles';
import { getResult } from '../utils/caseHelpers';
import { formatDate, formatDateTime, formatTimestamp } from '../utils/format';

function ReportSection({ index, title, children }: { index: number; title: string; children: React.ReactNode }) {
  return (
    <section className="border-t border-slate-100 p-8">
      <h2 className="mb-4 text-xs font-bold uppercase tracking-wider text-slate-400">
        {index}. {title}
      </h2>
      {children}
    </section>
  );
}

export function Reports() {
  const { caseId } = useParams();
  const navigate = useNavigate();
  const { cases, getCase, auditLog } = useCaseStore();
  const donorCase = getCase(caseId ?? cases[0]?.caseId);

  if (!donorCase) {
    return (
      <div className="p-8">
        <EmptyState title="No Case Available" description="Create a donor case to generate a clinical report." />
      </div>
    );
  }

  const cellular = getResult(donorCase, MODULE_IDS.cellular);
  const grade = getResult(donorCase, MODULE_IDS.grade);
  const disease = getResult(donorCase, MODULE_IDS.disease);
  const decision = getResult(donorCase, MODULE_IDS.decision);
  const followUpResult = getResult(donorCase, MODULE_IDS.followUp);
  const caseAudit = auditLog.filter((entry) => entry.caseId === donorCase.caseId);

  return (
    <div className="space-y-6 pb-12">
      <PageHeader
        eyebrow={
          <Link to={`/cases/${donorCase.caseId}`} className="font-mono font-bold text-sky-700 hover:underline">
            #{donorCase.caseId}
          </Link>
        }
        title="Clinical Case Evaluation Report"
        description="Comprehensive report documenting donor telemetry, specular microscopy parameters, and neural predictions."
        actions={
          <>
            <CaseSelector value={donorCase.caseId} onChange={(id) => navigate(`/reports/${id}`)} />
            <Button variant="primary" size="md" onClick={() => window.print()}>
              <PrinterIcon className="h-4 w-4" />
              Print Clinical Report
            </Button>
          </>
        }
      />

      <div className="space-y-6">
        <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-slate-200 bg-surface px-5 py-3.5 shadow-bento">
          <span className="text-2xs font-bold uppercase tracking-wider text-slate-400">Provenance Legend</span>
          <ProvenanceTag provenance="AI Prediction" />
          <ProvenanceTag provenance="AI Analysis" />
          <ProvenanceTag provenance="Reference Measurement" />
          <ProvenanceTag provenance="Specialist Assessment" />
          <ProvenanceTag provenance="Staff Entered" />
          <span className="ml-auto text-2xs font-bold text-sky-700">
            NEBSL Verified Report Format
          </span>
        </div>

        <article className="mx-auto max-w-5xl rounded-3xl border border-slate-200 bg-surface shadow-bento overflow-hidden">
          <header className="border-b border-slate-100 p-8 bg-slate-50/40">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="flex items-center gap-4">
                <img src="/new-logo.png" alt="NEBSL Logo" className="h-12 w-auto object-contain rounded-xl border border-slate-200 p-1 bg-white" />
                <div>
                  <p className="text-2xs font-bold uppercase tracking-wider text-sky-700">National Eye Bank of Sri Lanka</p>
                  <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
                    Donor Cornea Case Report
                  </h1>
                  <p className="mt-0.5 font-mono text-xs font-bold text-slate-500">Case Identifier: {donorCase.caseId}</p>
                </div>
              </div>
              <dl className="grid grid-cols-2 gap-x-6 gap-y-2 text-right">
                <div>
                  <dt className="text-2xs font-bold uppercase tracking-wider text-slate-400">Generated</dt>
                  <dd className="text-xs font-semibold text-slate-800">{formatDateTime(new Date().toISOString())}</dd>
                </div>
                <div>
                  <dt className="text-2xs font-bold uppercase tracking-wider text-slate-400">Review Status</dt>
                  <dd className="text-xs font-semibold text-slate-800">{donorCase.reviewStatus}</dd>
                </div>
              </dl>
            </div>
          </header>

          <ReportSection index={1} title="Case Information">
            <dl className="grid gap-4 sm:grid-cols-3">
              <Field label="Case ID" value={donorCase.caseId} mono provenance="Staff Entered" />
              <Field label="Created" value={formatDateTime(donorCase.createdAt)} />
              <Field label="Created By" value={donorCase.createdBy} provenance="Staff Entered" />
              <Field label="Assigned Reviewer" value={donorCase.assignedReviewer} provenance="Staff Entered" />
              <Field label="Allocation Status" value={donorCase.transplant.intent} provenance="Staff Entered" />
              <Field label="Last Updated" value={formatDateTime(donorCase.lastUpdated)} />
            </dl>
          </ReportSection>

          <ReportSection index={2} title="Donor Information">
            <dl className="grid gap-4 sm:grid-cols-3">
              <Field label="Donor ID" value={donorCase.donor.donorId} mono provenance="Staff Entered" />
              <Field label="Age" value={donorCase.donor.age} unit="years" provenance="Staff Entered" />
              <Field label="Sex" value={donorCase.donor.sex} provenance="Staff Entered" />
              <Field label="Collection Date" value={formatDate(donorCase.donor.collectionDate)} provenance="Staff Entered" />
              <Field label="Eye / Cornea" value={donorCase.donor.eye} provenance="Staff Entered" />
              <Field label="Death to Preservation" value={donorCase.donor.deathToPreservationHours} unit="hours" provenance="Staff Entered" />
              <Field label="Cause of Death" value={donorCase.donor.causeOfDeath} provenance="Staff Entered" />
              <Field label="Serology" value={donorCase.donor.serology} provenance="Staff Entered" />
              <Field label="Relevant History" value={donorCase.donor.relevantHistory} provenance="Staff Entered" />
            </dl>
          </ReportSection>

          <ReportSection index={3} title="Endothelial Assessment">
            <div className="grid gap-6 sm:grid-cols-[minmax(0,14rem)_minmax(0,1fr)]">
              {donorCase.image.previewUrl ? (
                <img
                  src={donorCase.image.previewUrl}
                  alt={`Specular microscopy for ${donorCase.caseId}`}
                  className="w-full rounded-2xl border border-slate-200 bg-black object-cover"
                />
              ) : (
                <p className="rounded-2xl border border-dashed border-slate-200 bg-slate-50 p-6 text-center text-xs text-slate-400">
                  No image on record
                </p>
              )}
              <dl className="grid gap-4 sm:grid-cols-2">
                <Field label="Filename" value={donorCase.image.fileName} mono provenance="Staff Entered" />
                <Field label="Upload Status" value={donorCase.image.uploadStatus} provenance="Staff Entered" />
                <Field label="Image Quality" value={donorCase.image.qualityLabel} />
                <Field label="Capture" value={donorCase.image.captureDevice} provenance="Staff Entered" />
                <Field label="Reference ECD" value={donorCase.clinical.referenceEcd?.toLocaleString() ?? null} unit="cells/mm²" mono />
                <Field label="Slit Lamp Findings" value={donorCase.clinical.slitLampFindings} provenance="Staff Entered" />
              </dl>
            </div>
          </ReportSection>

          <ReportSection index={4} title="Cellular Analysis">
            {cellular.outputs.length === 0 ? (
              <p className="text-xs text-slate-400">No cellular analysis recorded for this case.</p>
            ) : (
              <dl className="grid gap-4 sm:grid-cols-3">
                {cellular.outputs.map((output) => (
                  <Field
                    key={output.label}
                    label={output.label}
                    value={output.value}
                    unit={output.unit}
                    provenance={output.provenance}
                    reference={output.reference}
                    mono
                  />
                ))}
              </dl>
            )}
          </ReportSection>

          <ReportSection index={5} title="Specialist Decision &amp; Audit">
            {donorCase.specialistDecision ? (
              <dl className="grid gap-4 sm:grid-cols-2">
                <Field label="Outcome" value={donorCase.specialistDecision.outcome} provenance="Specialist Assessment" />
                <Field label="Decided By" value={donorCase.specialistDecision.decidedBy} provenance="Specialist Assessment" />
                <Field label="Decided At" value={formatDateTime(donorCase.specialistDecision.decidedAt)} />
                <Field label="Rationale" value={donorCase.specialistDecision.rationale} provenance="Specialist Assessment" />
              </dl>
            ) : (
              <p className="text-xs text-slate-600">
                Final clinical status: <strong className="font-bold text-amber-900 bg-amber-50 px-2 py-0.5 rounded-lg">Pending Specialist Review</strong>
              </p>
            )}
          </ReportSection>
        </article>
      </div>
    </div>
  );
}