import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { toast } from "sonner";
import { AlertTriangleIcon, ArrowLeftIcon, FileTextIcon, ImageOffIcon, StethoscopeIcon } from "lucide-react";
import { useCaseStore } from "../contexts/CaseStore";
import { useSession } from "../contexts/SessionContext";
import { moduleRegistry } from "../data/moduleRegistry";
import { PageHeader } from "../components/ui/PageHeader";
import { Panel } from "../components/ui/Panel";
import { Field } from "../components/ui/Field";
import { EmptyState } from "../components/ui/EmptyState";
import { StatusBadge } from "../components/ui/StatusBadge";
import { ReviewBadge } from "../components/ui/ReviewBadge";
import { Button } from "../components/ui/Button";
import { WorkflowDiagram } from "../components/ui/WorkflowDiagram";
import { ModuleRow } from "../components/modules/ModuleRow";
import { analysisProgress, getResult, missingInformation } from "../utils/caseHelpers";
import { formatDate, formatDateTime } from "../utils/format";

export function CaseDetail() {
  const { caseId } = useParams();
  const { getCase, runModule, auditLog } = useCaseStore();
  const { can } = useSession();
  const [selectedJourneyStage, setSelectedJourneyStage] = useState(4);
  const donorCase = getCase(caseId);

  if (!donorCase) {
    return (
      <div className="p-8">
        <EmptyState
          title="Case Not Found"
          description={`No donor cornea record exists with identifier ${caseId}.`}
          action={
            <Link to="/cases">
              <Button variant="secondary">Back to Donor Database</Button>
            </Link>
          }
        />
      </div>
    );
  }

  const progress = analysisProgress(donorCase);
  const missing = missingInformation(donorCase);
  const lastAnalysed = moduleRegistry
    .map((m) => getResult(donorCase, m.id).lastRun)
    .filter((v): v is string => Boolean(v))
    .sort()
    .pop();
  const caseAudit = auditLog.filter((entry) => entry.caseId === donorCase.caseId);
  const journeyStages = [
    { label: "Donor", detail: "Donor identity and collection metadata", to: "#donor-information" },
    { label: "Cornea", detail: "Microscopy and clinical quality data", to: "#endothelial-image" },
    { label: "Cellular Intelligence", detail: "AI endothelial analysis modules", to: "#modules" },
    { label: "Disease Intelligence", detail: "Disease and suitability interpretation", to: "#modules" },
    { label: "Recipient Matching", detail: "Ranked candidates and clinical matching", to: "/recipients" },
    { label: "Transplant", detail: "Approved allocation and procedure", to: "/post-transplant" },
    { label: "Post-Transplant", detail: "Longitudinal graft follow-up", to: "/post-transplant" },
    { label: "Graft Outcome", detail: "Clinical outcome and sign-off", to: "/post-transplant" },
  ];

  const handleRun = (moduleId: string, moduleName: string) => {
    runModule(donorCase.caseId, moduleId);
    toast.info(`${moduleName} run requested`, {
      description: "Module execution simulated for demonstration.",
    });
  };

  return (
    <div className="space-y-8 pb-12">
      <PageHeader
        eyebrow={
          <span className="flex items-center gap-1.5">
            <ArrowLeftIcon className="h-3.5 w-3.5" />
            <Link to="/cases" className="hover:underline">
              Donor Cases
            </Link>
          </span>
        }
        title={`Cornea Case #${donorCase.caseId}`}
        description="Comprehensive donor metadata, endothelial microscopy, and AI module neural evaluations."
        actions={
          <>
            <Link to={`/reports/${donorCase.caseId}`}>
              <Button variant="secondary" size="md">
                <FileTextIcon className="h-4 w-4" />
                Generate Report
              </Button>
            </Link>
            {can("Transplant", "approve") && (
              <Link to={`/review/${donorCase.caseId}`}>
                <Button variant="yellow" size="md">
                  <StethoscopeIcon className="h-4 w-4" />
                  Specialist Review
                </Button>
              </Link>
            )}
          </>
        }
      >
        <dl className="mt-4 flex flex-wrap items-center gap-x-8 gap-y-3 border-t border-slate-100 pt-4">
          <div>
            <dt className="text-2xs font-bold uppercase tracking-wider text-slate-400">Review Status</dt>
            <dd className="mt-1 flex items-center gap-2">
              <ReviewBadge status={donorCase.reviewStatus} />
              <StatusBadge status={progress.status} label={`AI ${progress.label}`} />
            </dd>
          </div>
          <div>
            <dt className="text-2xs font-bold uppercase tracking-wider text-slate-400">Last Analysed</dt>
            <dd className="mt-1 text-xs font-semibold text-slate-800">{lastAnalysed ? formatDateTime(lastAnalysed) : "No analysis run"}</dd>
          </div>
          <div>
            <dt className="text-2xs font-bold uppercase tracking-wider text-slate-400">Assigned Reviewer</dt>
            <dd className="mt-1 text-xs font-semibold text-slate-800">{donorCase.assignedReviewer ?? "Unassigned"}</dd>
          </div>
          <div>
            <dt className="text-2xs font-bold uppercase tracking-wider text-slate-400">Donor Specification</dt>
            <dd className="mt-1 text-xs font-semibold text-slate-800">
              {donorCase.donor.donorId} · {donorCase.donor.age}y · {donorCase.donor.sex} · {donorCase.donor.eye}
            </dd>
          </div>
        </dl>
      </PageHeader>

      <Panel title="Case workflow" description="Ownership and the next required action remain visible above case detail.">
        <div className="grid gap-4 lg:grid-cols-[1.4fr_repeat(4,minmax(0,1fr))]">
          <div className="rounded-2xl border border-sky-200 bg-sky-50 p-4">
            <p className="text-2xs font-bold uppercase tracking-wider text-sky-700">Current stage</p>
            <p className="mt-1 text-lg font-black text-slate-900">{donorCase.ownership?.nextAction ?? "Case review pending"}</p>
            <p className="mt-1 text-xs font-semibold text-slate-600">Next action: Review the current case evidence</p>
          </div>
          <Field label="Assigned to" value={donorCase.ownership?.currentUser ?? "Unassigned"} />
          <Field label="Responsible role" value={donorCase.ownership?.currentRole ?? "Not assigned"} />
          <Field label="Assigned branch" value={donorCase.ownership?.assignedBranch ?? donorCase.branch} />
          <Field label="Priority" value={donorCase.reviewStatus === "Pending Review" ? "High" : "Standard"} />
        </div>
        <div className="mt-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {journeyStages.map((stage, index) => (
            <a
              key={stage.label}
              href={stage.to}
              onClick={(event) => {
                setSelectedJourneyStage(index);
                if (stage.to.startsWith("#")) event.preventDefault();
              }}
              className={`rounded-xl border px-3 py-2 text-left transition-colors ${index < selectedJourneyStage ? "border-emerald-200 bg-emerald-50" : index === selectedJourneyStage ? "border-amber-300 bg-amber-50 ring-1 ring-amber-200" : "border-slate-200 bg-slate-50 hover:border-sky-200"}`}
            >
              <span className="flex items-center justify-between text-2xs font-black uppercase tracking-wider text-slate-600">
                {stage.label}
                <span>{index < selectedJourneyStage ? "✓" : index === selectedJourneyStage ? "●" : "○"}</span>
              </span>
              <span className="mt-1 block text-2xs font-semibold normal-case tracking-normal text-slate-500">{stage.detail}</span>
            </a>
          ))}
        </div>
      </Panel>

      <WorkflowDiagram
        title="Research intelligence architecture"
        steps={[
          { label: "Input data", detail: "Donor data, specular images, cellular biomarkers, recipient and follow-up data.", role: "Clinical and operational staff", action: "Collect complete evidence", tone: "blue" },
          { label: "Donor intelligence", detail: "Cornea grading, microscopy quality and cellular biomarkers.", role: "AI decision support", action: "Assess donor tissue", tone: "slate" },
          { label: "Disease intelligence", detail: "Disease patterns, severity and recipient-specific risk factors.", role: "AI decision support", action: "Explain disease factors", tone: "green" },
          { label: "Transplant intelligence", detail: "Suitability, ranked matching and compatibility evidence.", role: "AI plus Doctor", action: "Support clinical decision", tone: "amber" },
          { label: "Post-transplant intelligence", detail: "ECD, CV and HEX trajectories with anomaly detection.", role: "AI plus Nurse / Technician", action: "Monitor graft recovery", tone: "slate" },
          { label: "Explainability", detail: "Evidence and confidence remain visible for every recommendation.", role: "Doctor", action: "Interpret and sign off", tone: "amber" },
        ]}
      />

      <div className="grid gap-8 xl:grid-cols-[minmax(0,1fr)_minmax(0,20rem)]">
        <div className="min-w-0 space-y-8">
          <Panel id="donor-information" title="1. Donor Information" description="Intake metadata.">
            <dl className="grid gap-4 sm:grid-cols-3">
              <Field label="Donor ID" value={donorCase.donor.donorId} mono />
              <Field label="Age" value={donorCase.donor.age} unit="years" />
              <Field label="Sex" value={donorCase.donor.sex} />
              <Field label="Collection Date" value={formatDate(donorCase.donor.collectionDate)} />
              <Field label="Eye / Cornea" value={donorCase.donor.eye} />
              <Field label="Death to Preservation" value={donorCase.donor.deathToPreservationHours} unit="hours" />
              <Field label="Cause of Death" value={donorCase.donor.causeOfDeath} />
              <Field label="Serology" value={donorCase.donor.serology} />
              <Field label="Relevant History" value={donorCase.donor.relevantHistory} />
            </dl>
          </Panel>

          <div className="grid gap-8 lg:grid-cols-[minmax(0,20rem)_minmax(0,1fr)]">
            <Panel id="endothelial-image" title="2. Endothelial Microscopy">
              {donorCase.image.previewUrl ? (
                <figure>
                  <img src={donorCase.image.previewUrl} alt={`Specular microscopy for ${donorCase.caseId}`} className="w-full rounded-2xl border border-slate-200 bg-black object-cover" />
                  <figcaption className="mt-3">
                    <dl className="grid grid-cols-2 gap-3">
                      <Field label="Filename" value={donorCase.image.fileName} mono />
                      <Field label="Upload Status" value={donorCase.image.uploadStatus} />
                      <Field label="Image Quality" value={donorCase.image.qualityLabel} />
                      <Field label="Capture" value={donorCase.image.magnification} />
                    </dl>
                  </figcaption>
                </figure>
              ) : (
                <EmptyState icon={<ImageOffIcon className="h-5 w-5" />} title="No image uploaded" description="Image-dependent modules will report missing information." compact />
              )}
            </Panel>

            <Panel id="clinical-information" title="3. Clinical Information" description="Bench observations.">
              <dl className="grid gap-4 sm:grid-cols-2">
                <Field label="Slit Lamp Findings" value={donorCase.clinical.slitLampFindings} />
                <Field label="Epithelial Status" value={donorCase.clinical.epithelialStatus} />
                <Field label="Stromal Clarity" value={donorCase.clinical.stromalClarity} />
                <Field label="Endothelial Folds" value={donorCase.clinical.endothelialFolds} />
                <Field label="Arcus Senilis" value={donorCase.clinical.arcusSenilis} />
                <Field label="Storage Medium" value={`${donorCase.clinical.storageMedium} · ${donorCase.clinical.storageTemperatureC ?? "—"} °C`} />
                <Field label="Reference ECD" value={donorCase.clinical.referenceEcd?.toLocaleString() ?? null} unit="cells/mm²" mono />
                <Field label="Observed By" value={donorCase.clinical.observedBy} />
              </dl>
            </Panel>
          </div>

          <Panel
            id="modules"
            title="4–8. AI Analysis Modules"
            description="Autonomous module evaluation results."
            flush
            actions={
              <Link to={`/analysis/${donorCase.caseId}`} className="text-xs font-bold text-sky-700 hover:underline">
                Open Analysis Workspace
              </Link>
            }
          >
            <div>
              {moduleRegistry.map((definition) => (
                <ModuleRow key={definition.id} donorCase={donorCase} definition={definition} result={getResult(donorCase, definition.id)} onRun={() => handleRun(definition.id, definition.name)} canRun={can("AI", "run")} />
              ))}
            </div>
          </Panel>
        </div>

        <aside className="space-y-8 xl:sticky xl:top-6 xl:self-start">
          <Panel title="Missing Information">
            {missing.length === 0 ? (
              <p className="text-xs text-slate-500">No missing data recorded for this case.</p>
            ) : (
              <ul className="space-y-2">
                {missing.map((item) => (
                  <li key={item} className="flex items-start gap-2 text-xs font-semibold text-amber-900 bg-amber-50 p-2 rounded-xl">
                    <AlertTriangleIcon className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            )}
          </Panel>

          <Panel title="Specialist Review">
            {donorCase.specialistDecision ? (
              <dl className="space-y-3">
                <Field label="Outcome" value={donorCase.specialistDecision.outcome} />
                <Field label="Decided By" value={donorCase.specialistDecision.decidedBy} />
                <Field label="Decided At" value={formatDateTime(donorCase.specialistDecision.decidedAt)} />
                <Field label="Rationale" value={donorCase.specialistDecision.rationale} />
              </dl>
            ) : (
              <div>
                <p className="text-xs font-bold text-slate-900">Pending Specialist Review</p>
                <p className="mt-1 text-xs text-slate-500">No specialist decision recorded. AI module outputs are decision support tools only.</p>
                {can("Transplant", "approve") && (
                  <Link to={`/review/${donorCase.caseId}`} className="inline-block mt-3">
                    <Button variant="yellow" size="sm">
                      Review Case
                    </Button>
                  </Link>
                )}
              </div>
            )}
          </Panel>

          <Panel title="Case activity" description="Timestamped actions for this case.">
            {caseAudit.length === 0 ? (
              <p className="text-xs text-slate-500">No activity recorded yet.</p>
            ) : (
              <ol className="space-y-3">
                {caseAudit.slice(0, 6).map((entry) => (
                  <li key={entry.id} className="border-l-2 border-sky-200 pl-3">
                    <p className="text-xs font-bold text-slate-800">{entry.action}</p>
                    <p className="mt-0.5 text-2xs font-semibold text-slate-500">
                      {formatDateTime(entry.timestamp)} · {entry.user}
                    </p>
                  </li>
                ))}
              </ol>
            )}
          </Panel>
        </aside>
      </div>
    </div>
  );
}
