import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useCaseStore } from '../contexts/CaseStore';
import { moduleRegistry } from '../data/moduleRegistry';
import { PageHeader } from '../components/ui/PageHeader';
import { Panel } from '../components/ui/Panel';
import { EmptyState } from '../components/ui/EmptyState';
import { tableClass, tdClass, thClass, theadClass, trClass } from '../components/ui/tableStyles';
import { formatTimestamp } from '../utils/format';

const selectClass =
  'h-10 rounded-2xl border border-slate-200 bg-slate-50 px-3.5 text-xs font-semibold text-slate-800 focus:border-sky-500 focus:bg-surface focus:outline-none transition-all';

export function AuditHistory() {
  const { auditLog, cases } = useCaseStore();
  const [caseFilter, setCaseFilter] = useState('all');
  const [moduleFilter, setModuleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  const modules = useMemo(() => {
    const names = new Set<string>(moduleRegistry.map((m) => m.name));
    auditLog.forEach((entry) => names.add(entry.module));
    return Array.from(names).sort();
  }, [auditLog]);

  const filtered = auditLog.filter((entry) => {
    if (caseFilter !== 'all' && entry.caseId !== caseFilter) return false;
    if (moduleFilter !== 'all' && entry.module !== moduleFilter) return false;
    if (statusFilter !== 'all' && entry.status !== statusFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6 pb-12">
      <PageHeader
        eyebrow="Compliance &amp; Audit Trail"
        title="System Audit &amp; Activity Log"
        description="Immutable record of module execution triggers, clinical review sign-offs, and tissue state updates."
      />

      <Panel flush>
        <div className="flex flex-wrap items-end gap-3 border-b border-slate-100 p-6 bg-slate-50/40">
          <div>
            <label htmlFor="audit-case" className="mb-1.5 block text-2xs font-bold uppercase tracking-wider text-slate-400">
              Filter Case ID
            </label>
            <select id="audit-case" value={caseFilter} onChange={(e) => setCaseFilter(e.target.value)} className={`${selectClass} font-mono`}>
              <option value="all">All Cases</option>
              {cases.map((c) => (
                <option key={c.caseId} value={c.caseId}>
                  {c.caseId}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="audit-module" className="mb-1.5 block text-2xs font-bold uppercase tracking-wider text-slate-400">
              Module
            </label>
            <select id="audit-module" value={moduleFilter} onChange={(e) => setModuleFilter(e.target.value)} className={selectClass}>
              <option value="all">All Modules</option>
              {modules.map((name) => (
                <option key={name} value={name}>
                  {name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="audit-status" className="mb-1.5 block text-2xs font-bold uppercase tracking-wider text-slate-400">
              Status
            </label>
            <select id="audit-status" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className={selectClass}>
              <option value="all">All Statuses</option>
              <option value="Completed">Completed</option>
              <option value="Running">Running</option>
              <option value="Needs Review">Needs Review</option>
              <option value="Unavailable">Unavailable</option>
            </select>
          </div>
          <p className="ml-auto text-2xs font-semibold text-slate-400">
            Showing {filtered.length} of {auditLog.length} audit entries
          </p>
        </div>

        {filtered.length === 0 ? (
          <div className="p-6">
            <EmptyState title="No audit entries match these filters" compact />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead className={theadClass}>
                <tr>
                  <th scope="col" className={thClass}>Timestamp</th>
                  <th scope="col" className={thClass}>Case ID</th>
                  <th scope="col" className={thClass}>Module</th>
                  <th scope="col" className={thClass}>Action</th>
                  <th scope="col" className={thClass}>Status</th>
                  <th scope="col" className={thClass}>User</th>
                  <th scope="col" className={thClass}>Result Version</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((entry) => (
                  <tr key={entry.id} className={trClass}>
                    <td className={`${tdClass} whitespace-nowrap font-mono text-xs text-slate-500`}>
                      {formatTimestamp(entry.timestamp)}
                    </td>
                    <td className={tdClass}>
                      <Link to={`/cases/${entry.caseId}`} className="font-mono text-xs font-bold text-sky-700 hover:underline">
                        {entry.caseId}
                      </Link>
                    </td>
                    <td className={`${tdClass} text-xs font-semibold text-slate-900`}>{entry.module}</td>
                    <td className={`${tdClass} text-xs text-slate-700`}>{entry.action}</td>
                    <td className={`${tdClass} text-xs`}>
                      <span className="font-semibold text-slate-800 bg-slate-100 px-2.5 py-0.5 rounded-full text-2xs">
                        {entry.status}
                      </span>
                    </td>
                    <td className={`${tdClass} text-xs text-slate-600`}>{entry.user}</td>
                    <td className={`${tdClass} font-mono text-2xs text-slate-400`}>
                      {entry.resultVersion ?? '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </div>
  );
}