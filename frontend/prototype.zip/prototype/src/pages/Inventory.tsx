import React, { useState } from 'react';
import {
  PackageIcon,
  ArrowLeftRightIcon,
  AlertTriangleIcon,
  CheckCircle2Icon,
  BuildingIcon,
  ThermometerIcon,
  CalendarIcon,
  PlusIcon,
} from 'lucide-react';
import { useBranch } from '../contexts/BranchContext';
import { PageHeader } from '../components/ui/PageHeader';
import { Panel } from '../components/ui/Panel';
import { Button } from '../components/ui/Button';
import { tableClass, tdClass, thClass, theadClass, trClass } from '../components/ui/tableStyles';
import type { Branch } from '../types/user';

interface InventoryItem {
  corneaId: string;
  caseId: string;
  branch: Branch;
  eye: string;
  storageMedium: string;
  temperatureC: number;
  preservationDate: string;
  expiryDate: string;
  status: 'Available' | 'Reserved' | 'Allocated' | 'Transferred' | 'In Transit';
  grade: string;
}

interface TransferLog {
  transferId: string;
  caseId: string;
  fromBranch: Branch;
  toBranch: Branch;
  requestedBy: string;
  approvedBy: string;
  status: 'Requested' | 'In Transit' | 'Received' | 'Completed';
  timestamp: string;
}

const INITIAL_INVENTORY: InventoryItem[] = [
  {
    corneaId: 'CRN-2026-091',
    caseId: 'NEB-2026-00125',
    branch: 'Colombo',
    eye: 'Right (OD)',
    storageMedium: 'Optisol-GS',
    temperatureC: 4.2,
    preservationDate: '2026-08-19',
    expiryDate: '2026-09-02',
    status: 'Available',
    grade: 'A+',
  },
  {
    corneaId: 'CRN-2026-092',
    caseId: 'NEB-2026-00124',
    branch: 'Colombo',
    eye: 'Left (OS)',
    storageMedium: 'Optisol-GS',
    temperatureC: 4.0,
    preservationDate: '2026-08-18',
    expiryDate: '2026-09-01',
    status: 'In Transit',
    grade: 'A',
  },
  {
    corneaId: 'CRN-2026-088',
    caseId: 'NEB-2026-00122',
    branch: 'Kandy',
    eye: 'Right (OD)',
    storageMedium: 'Eusol-C',
    temperatureC: 3.8,
    preservationDate: '2026-08-15',
    expiryDate: '2026-08-29',
    status: 'Reserved',
    grade: 'A+',
  },
  {
    corneaId: 'CRN-2026-085',
    caseId: 'NEB-2026-00120',
    branch: 'Kurunegala',
    eye: 'Left (OS)',
    storageMedium: 'Optisol-GS',
    temperatureC: 4.1,
    preservationDate: '2026-08-14',
    expiryDate: '2026-08-28',
    status: 'Allocated',
    grade: 'B',
  },
];

const INITIAL_TRANSFERS: TransferLog[] = [
  {
    transferId: 'TR-401',
    caseId: 'NEB-2026-00124',
    fromBranch: 'Colombo',
    toBranch: 'Kandy',
    requestedBy: 'Dr. A. Perera',
    approvedBy: 'H. Jayawardena (Manager)',
    status: 'In Transit',
    timestamp: '2026-08-20 10:30 AM',
  },
  {
    transferId: 'TR-398',
    caseId: 'NEB-2026-00118',
    fromBranch: 'Kurunegala',
    toBranch: 'Colombo',
    requestedBy: 'R. Gunasekara',
    approvedBy: 'System Auto-Allocated',
    status: 'Completed',
    timestamp: '2026-08-18 04:15 PM',
  },
];

export function Inventory() {
  const { filterByBranch, activeBranch } = useBranch();
  const [items, setItems] = useState<InventoryItem[]>(INITIAL_INVENTORY);
  const [transfers, setTransfers] = useState<TransferLog[]>(INITIAL_TRANSFERS);
  const [activeTab, setActiveTab] = useState<'storage' | 'transfers'>('storage');
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [selectedCase, setSelectedCase] = useState('');
  const [targetBranch, setTargetBranch] = useState<Branch>('Kandy');

  const filteredItems = filterByBranch(items);
  const filteredTransfers = transfers.filter(
    (t) =>
      activeBranch === 'All Branches' || t.fromBranch === activeBranch || t.toBranch === activeBranch
  );

  const availableCount = filteredItems.filter((i) => i.status === 'Available').length;
  const reservedCount = filteredItems.filter((i) => i.status === 'Reserved').length;
  const transitCount = filteredItems.filter((i) => i.status === 'In Transit').length;

  const handleCreateTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCase) return;
    const newLog: TransferLog = {
      transferId: `TR-${Math.floor(400 + Math.random() * 90)}`,
      caseId: selectedCase,
      fromBranch: activeBranch === 'All Branches' ? 'Colombo' : activeBranch,
      toBranch: targetBranch,
      requestedBy: 'Current User',
      approvedBy: 'Branch Manager Approved',
      status: 'Requested',
      timestamp: new Date().toLocaleString(),
    };
    setTransfers([newLog, ...transfers]);
    setShowTransferModal(false);
  };

  return (
    <div className="space-y-6 pb-12">
      <PageHeader
        eyebrow="Tissue & Inventory Management"
        title={`Cornea Storage & Inter-Branch Transfers — ${activeBranch}`}
        description="Monitor cold-chain tissue storage, preservation expiry dates, cold storage temperatures, and execute branch-to-branch tissue transfers."
        actions={
          <Button variant="primary" size="sm" onClick={() => setShowTransferModal(true)}>
            <ArrowLeftRightIcon className="h-4 w-4" />
            New Inter-Branch Transfer
          </Button>
        }
      />

      {/* Telemetry Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Panel className="p-4 bg-emerald-50/70 border-emerald-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase text-emerald-800">
            <span>Available Tissues</span>
            <CheckCircle2Icon className="h-4 w-4 text-emerald-600" />
          </div>
          <p className="mt-2 text-2xl font-extrabold text-emerald-950">{availableCount}</p>
          <p className="mt-0.5 text-2xs text-emerald-800 font-semibold">Ready for allocation</p>
        </Panel>

        <Panel className="p-4 bg-sky-50/70 border-sky-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase text-sky-800">
            <span>Reserved / Allocated</span>
            <PackageIcon className="h-4 w-4 text-sky-600" />
          </div>
          <p className="mt-2 text-2xl font-extrabold text-sky-950">{reservedCount}</p>
          <p className="mt-0.5 text-2xs text-sky-800 font-semibold">Matched to recipient</p>
        </Panel>

        <Panel className="p-4 bg-amber-50/70 border-amber-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase text-amber-800">
            <span>In Inter-Branch Transit</span>
            <ArrowLeftRightIcon className="h-4 w-4 text-amber-600" />
          </div>
          <p className="mt-2 text-2xl font-extrabold text-amber-950">{transitCount}</p>
          <p className="mt-0.5 text-2xs text-amber-800 font-semibold">Active transport</p>
        </Panel>

        <Panel className="p-4 bg-slate-50 border-slate-200">
          <div className="flex items-center justify-between text-2xs font-extrabold uppercase text-slate-500">
            <span>Cold-Chain Temp</span>
            <ThermometerIcon className="h-4 w-4 text-slate-400" />
          </div>
          <p className="mt-2 text-2xl font-extrabold text-slate-900">4.1 °C</p>
          <p className="mt-0.5 text-2xs text-emerald-700 font-extrabold">Optimal range (2°–8°C)</p>
        </Panel>
      </div>

      {/* Tabs */}
      <Panel p={0} className="overflow-hidden">
        <div className="flex items-center gap-2 border-b border-slate-200 bg-slate-50/80 px-6 py-3">
          <button
            onClick={() => setActiveTab('storage')}
            className={`px-4 py-2 text-xs font-extrabold rounded-2xl transition-all ${
              activeTab === 'storage'
                ? 'bg-white text-sky-900 shadow-2xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}>
            Storage Inventory ({filteredItems.length})
          </button>
          <button
            onClick={() => setActiveTab('transfers')}
            className={`px-4 py-2 text-xs font-extrabold rounded-2xl transition-all ${
              activeTab === 'transfers'
                ? 'bg-white text-sky-900 shadow-2xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}>
            Inter-Branch Transfer Log ({filteredTransfers.length})
          </button>
        </div>

        {activeTab === 'storage' ? (
          <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead className={theadClass}>
                <tr>
                  <th className={thClass}>Cornea ID</th>
                  <th className={thClass}>Case ID</th>
                  <th className={thClass}>Branch</th>
                  <th className={thClass}>Eye</th>
                  <th className={thClass}>Medium / Temp</th>
                  <th className={thClass}>Expiry Date</th>
                  <th className={thClass}>Grade</th>
                  <th className={thClass}>Status</th>
                </tr>
              </thead>
              <tbody>
                {filteredItems.map((item) => (
                  <tr key={item.corneaId} className={trClass}>
                    <td className={`${tdClass} font-extrabold text-slate-900`}>{item.corneaId}</td>
                    <td className={`${tdClass} font-bold text-sky-800`}>{item.caseId}</td>
                    <td className={tdClass}>
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-2xs font-extrabold">
                        {item.branch}
                      </span>
                    </td>
                    <td className={tdClass}>{item.eye}</td>
                    <td className={tdClass}>
                      {item.storageMedium} ({item.temperatureC}°C)
                    </td>
                    <td className={`${tdClass} font-semibold text-slate-600`}>{item.expiryDate}</td>
                    <td className={tdClass}>
                      <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-900 text-2xs font-extrabold">
                        {item.grade}
                      </span>
                    </td>
                    <td className={tdClass}>
                      <span
                        className={`px-2.5 py-1 rounded-full text-2xs font-extrabold ${
                          item.status === 'Available'
                            ? 'bg-emerald-100 text-emerald-900'
                            : item.status === 'Reserved'
                            ? 'bg-amber-100 text-amber-900'
                            : 'bg-sky-100 text-sky-900'
                        }`}>
                        {item.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead className={theadClass}>
                <tr>
                  <th className={thClass}>Transfer ID</th>
                  <th className={thClass}>Case ID</th>
                  <th className={thClass}>From Branch</th>
                  <th className={thClass}>To Branch</th>
                  <th className={thClass}>Requested By</th>
                  <th className={thClass}>Approved By</th>
                  <th className={thClass}>Status</th>
                  <th className={thClass}>Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {filteredTransfers.map((t) => (
                  <tr key={t.transferId} className={trClass}>
                    <td className={`${tdClass} font-extrabold text-slate-900`}>{t.transferId}</td>
                    <td className={`${tdClass} font-bold text-sky-800`}>{t.caseId}</td>
                    <td className={tdClass}>{t.fromBranch}</td>
                    <td className={`${tdClass} font-extrabold text-sky-900`}>{t.toBranch}</td>
                    <td className={tdClass}>{t.requestedBy}</td>
                    <td className={tdClass}>{t.approvedBy}</td>
                    <td className={tdClass}>
                      <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-900 text-2xs font-extrabold">
                        {t.status}
                      </span>
                    </td>
                    <td className={`${tdClass} text-slate-400 text-2xs`}>{t.timestamp}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>

      {/* Transfer Modal Dialog */}
      {showTransferModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-3xl bg-surface p-6 shadow-bento border border-slate-200">
            <h3 className="text-base font-extrabold text-slate-900">Initiate Inter-Branch Transfer</h3>
            <p className="text-xs text-slate-500 mt-1">
              Select tissue case and target branch (Colombo ↔ Kandy ↔ Kurunegala).
            </p>

            <form onSubmit={handleCreateTransfer} className="mt-4 space-y-4">
              <div>
                <label className="block text-2xs font-extrabold text-slate-700 uppercase tracking-wider mb-1">
                  Select Cornea Case
                </label>
                <select
                  required
                  value={selectedCase}
                  onChange={(e) => setSelectedCase(e.target.value)}
                  className="w-full h-10 rounded-2xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-800">
                  <option value="">-- Choose Case --</option>
                  <option value="NEB-2026-00125">NEB-2026-00125 (Grade A+, Colombo)</option>
                  <option value="NEB-2026-00122">NEB-2026-00122 (Grade A+, Kandy)</option>
                </select>
              </div>

              <div>
                <label className="block text-2xs font-extrabold text-slate-700 uppercase tracking-wider mb-1">
                  Target Destination Branch
                </label>
                <select
                  value={targetBranch}
                  onChange={(e) => setTargetBranch(e.target.value as Branch)}
                  className="w-full h-10 rounded-2xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-800">
                  <option value="Colombo">Colombo Branch</option>
                  <option value="Kandy">Kandy Branch</option>
                  <option value="Kurunegala">Kurunegala Branch</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <Button variant="ghost" size="sm" type="button" onClick={() => setShowTransferModal(false)}>
                  Cancel
                </Button>
                <Button variant="primary" size="sm" type="submit">
                  Confirm Transfer →
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
