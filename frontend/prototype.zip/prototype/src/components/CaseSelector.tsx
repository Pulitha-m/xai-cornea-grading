import React from 'react';
import { ChevronDownIcon } from 'lucide-react';
import { useCaseStore } from '../contexts/CaseStore';

interface CaseSelectorProps {
  value: string | undefined;
  onChange: (caseId: string) => void;
  label?: string;
  /** Restrict the list, e.g. to transplanted cases only. */
  filter?: (caseId: string) => boolean;
}

/**
 * Shared case picker. Every module page is anchored to a Case ID through this
 * control, so the user always knows which donor cornea case is in view.
 */
export function CaseSelector({ value, onChange, label = 'Case', filter }: CaseSelectorProps) {
  const { cases } = useCaseStore();
  const options = filter ? cases.filter((c) => filter(c.caseId)) : cases;

  return (
    <div className="flex items-center gap-2">
      <label htmlFor="case-selector" className="text-xs font-medium text-ink-500">
        {label}
      </label>
      <div className="relative">
        <select
          id="case-selector"
          value={value ?? ''}
          onChange={(e) => onChange(e.target.value)}
          className="h-9 appearance-none rounded border border-line-strong bg-surface pl-3 pr-8 font-mono text-sm text-ink-900 focus:border-accent-500 focus:outline-none">
          
          {options.length === 0 && <option value="">No cases available</option>}
          {options.map((c) =>
          <option key={c.caseId} value={c.caseId}>
              {c.caseId} · {c.donor.eye === 'Right (OD)' ? 'OD' : 'OS'}
            </option>
          )}
        </select>
        <ChevronDownIcon
          className="pointer-events-none absolute right-2 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400"
          aria-hidden="true" />
        
      </div>
    </div>);

}