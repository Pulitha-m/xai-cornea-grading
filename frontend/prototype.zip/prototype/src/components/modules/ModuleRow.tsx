import React, { useId, useState } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { AlertTriangleIcon, ArrowRightIcon, ChevronDownIcon, PlayIcon } from 'lucide-react';
import { MODULE_IDS } from '../../data/moduleRegistry';
import type { ModuleDefinition } from '../../data/moduleRegistry';
import type { DonorCase, ModuleResult } from '../../types/case';
import { useSession } from '../../contexts/SessionContext';
import { Button, buttonClass } from '../ui/Button';
import { StatusBadge } from '../ui/StatusBadge';
import { formatDateTime } from '../../utils/format';
import { moduleViewHref } from './moduleLinks';
import { getModuleDetailPanel } from './registry';

interface ModuleRowProps {
  donorCase: DonorCase;
  definition: ModuleDefinition;
  result: ModuleResult;
  onRun: () => void;
  canRun: boolean;
}

/**
 * Collapsed module row. Every registered module renders through this one
 * structure — status, one-line result summary, last run — and expands its own
 * detail panel in place so a case never opens as a wall of full-height cards.
 */
export function ModuleRow({ donorCase, definition, result, onRun, canRun }: ModuleRowProps) {
  const [open, setOpen] = useState(false);
  const panelId = useId();
  const { can } = useSession();
  const running = result.status === 'Running';
  const DetailPanel = getModuleDetailPanel(definition.id);
  const reviewGated = definition.id === MODULE_IDS.decision && !can('view-review');

  return (
    <div className="border-b border-line last:border-b-0">
      <h3>
        <button
          type="button"
          aria-expanded={open}
          aria-controls={panelId}
          onClick={() => setOpen((v) => !v)}
          className="flex w-full items-center gap-4 px-4 py-3 text-left transition-colors duration-150 ease-out hover:bg-sunken">
          
          <ChevronDownIcon
            className={`h-4 w-4 shrink-0 text-ink-400 transition-transform duration-150 ease-out ${
            open ? 'rotate-0' : '-rotate-90'}`
            }
            aria-hidden="true" />
          
          <span className="w-56 shrink-0 text-[13px] font-semibold leading-tight text-ink-900">
            {definition.name}
          </span>
          <span className="w-32 shrink-0">
            <StatusBadge status={result.status} />
          </span>
          <span className="min-w-0 flex-1 truncate text-xs text-ink-700">
            {result.resultSummary ??
            <span className="text-ink-400">No result written to this case yet</span>
            }
          </span>
          <span className="w-36 shrink-0 text-right text-2xs text-ink-400">
            {result.lastRun ? formatDateTime(result.lastRun) : 'Never run'}
          </span>
        </button>
      </h3>

      <AnimatePresence initial={false}>
        {open &&
        <motion.div
          id={panelId}
          key="panel"
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
          className="overflow-hidden">
          
            <div className="border-t border-line bg-sunken px-4 py-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="max-w-2xl text-xs leading-relaxed text-ink-500">
                    {definition.purpose}
                  </p>
                  <p className="mt-1 text-2xs text-ink-400">
                    Result version {result.version ?? '—'} ·{' '}
                    {result.confidence !== null ?
                  `Confidence ${result.confidence.toFixed(2)}` :
                  `Quality ${result.quality ?? 'not applicable'}`}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  {reviewGated ?
                <span className="rounded border border-line bg-surface px-2.5 py-1.5 text-2xs text-ink-500">
                      Specialist review access required
                    </span> :

                <Link
                  to={moduleViewHref(definition.id, donorCase.caseId)}
                  className={buttonClass('secondary', 'sm')}>
                  
                      View analysis
                      <ArrowRightIcon className="h-3.5 w-3.5" aria-hidden="true" />
                    </Link>
                }
                  {canRun &&
                <Button variant="primary" onClick={onRun} disabled={running}>
                      <PlayIcon className="h-3.5 w-3.5" aria-hidden="true" />
                      {running ? 'Running…' : 'Run analysis'}
                    </Button>
                }
                </div>
              </div>

              {result.statusNote &&
            <p className="mt-3 rounded border border-line bg-surface px-2.5 py-2 text-2xs leading-relaxed text-ink-500">
                  {result.statusNote}
                </p>
            }

              {result.missingInputs.length > 0 &&
            <p className="mt-3 flex items-start gap-1.5 rounded border border-warn-200 bg-warn-50 px-2.5 py-2 text-2xs leading-relaxed text-warn-700">
                  <AlertTriangleIcon className="mt-px h-3 w-3 shrink-0" aria-hidden="true" />
                  <span>Missing information: {result.missingInputs.join(', ')}</span>
                </p>
            }

              <div className="mt-4 space-y-4">
                <DetailPanel donorCase={donorCase} definition={definition} result={result} />
              </div>
            </div>
          </motion.div>
        }
      </AnimatePresence>
    </div>);

}