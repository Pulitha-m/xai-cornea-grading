import React from 'react';
import type { ModuleOutput } from '../../types/case';
import { Field } from '../ui/Field';
import { EmptyState } from '../ui/EmptyState';

interface ModuleOutputsProps {
  outputs: ModuleOutput[];
  columns?: 2 | 3;
  emptyTitle?: string;
  emptyDescription?: string;
}

export function ModuleOutputs({
  outputs,
  columns = 3,
  emptyTitle = 'Analysis not yet connected',
  emptyDescription = 'No outputs have been written to this case. Values will appear here once the research module is connected and a run completes.'
}: ModuleOutputsProps) {
  if (outputs.length === 0) {
    return <EmptyState title={emptyTitle} description={emptyDescription} compact />;
  }

  return (
    <dl className={`grid gap-x-6 gap-y-4 ${columns === 3 ? 'md:grid-cols-3' : 'md:grid-cols-2'}`}>
      {outputs.map((output) =>
      <Field
        key={output.label}
        label={output.label}
        value={output.value}
        unit={output.unit}
        provenance={output.provenance}
        reference={output.reference}
        note={output.note}
        mono />

      )}
    </dl>);

}