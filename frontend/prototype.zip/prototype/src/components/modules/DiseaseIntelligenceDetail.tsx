import React from 'react';
import type { ModuleDefinition } from '../../data/moduleRegistry';
import type { DonorCase, ModuleResult } from '../../types/case';
import { DISEASE_CATEGORY_SET } from '../../data/moduleRegistry';
import { Panel } from '../ui/Panel';
import { ModuleOutputs } from './ModuleOutputs';
import { ExplanationSection } from './ExplanationSection';

interface DetailProps {
  donorCase: DonorCase;
  definition: ModuleDefinition;
  result: ModuleResult;
}

export function DiseaseIntelligenceDetail({ result }: DetailProps) {
  const assessment = result.outputs.find((o) => o.label === 'Disease Assessment')?.value ?? null;
  const severity = result.outputs.find((o) => o.label === 'Severity')?.value ?? null;
  const chiRaw = result.outputs.find((o) => o.label.startsWith('Corneal Health Index'))?.value;
  const chi = chiRaw ? Number(chiRaw.split('/')[0].trim()) : null;

  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,20rem)]">
        <Panel
          title="Disease assessment"
          description="AI-supported assessment of disease indicators. Not a diagnosis and not a confirmation of disease.">
          
          <div className="grid gap-6 sm:grid-cols-2">
            <div>
              <p className="text-2xs font-medium uppercase tracking-wide text-ink-400">
                Assessment
              </p>
              <p className="mt-1 text-base font-semibold leading-snug text-ink-900">
                {assessment ?? 'Not analysed'}
              </p>
              <p className="mt-1.5 text-xs text-ink-500">Severity: {severity ?? 'Not available'}</p>
            </div>
            <div>
              <p className="text-2xs font-medium uppercase tracking-wide text-ink-400">
                Corneal Health Index (CHI)
              </p>
              <p className="mt-1 font-mono text-2xl font-semibold leading-none text-ink-900">
                {chi !== null ? `${chi}` : '—'}
                <span className="ml-1 text-sm font-normal text-ink-500">/ 100</span>
              </p>
              <div className="mt-2 h-1.5 w-full rounded-full bg-line" role="presentation">
                <div
                  className={`h-1.5 rounded-full ${
                  chi === null ? 'bg-line' : chi >= 75 ? 'bg-ok-600' : chi >= 50 ? 'bg-warn-600' : 'bg-alert-600'}`
                  }
                  style={{ width: `${chi ?? 0}%` }} />
                
              </div>
              <p className="mt-1.5 text-2xs text-ink-500">
                Composite index reported by the module. Interpret alongside clinical observations.
              </p>
            </div>
          </div>

          <div className="mt-5 border-t border-line pt-4">
            <ModuleOutputs outputs={result.outputs} columns={2} />
          </div>
        </Panel>

        <Panel
          title="Research category set"
          description="Categories are fixed by the research specification. The module does not introduce new categories.">
          
          <ul className="space-y-1.5">
            {DISEASE_CATEGORY_SET.map((category) =>
            <li
              key={category}
              className={`rounded border px-2.5 py-1.5 text-xs ${
              assessment && category.toLowerCase().startsWith(assessment.toLowerCase().slice(0, 10)) ?
              'border-accent-200 bg-accent-50 font-medium text-accent-700' :
              'border-line bg-sunken text-ink-500'}`
              }>
              
                {category}
              </li>
            )}
          </ul>
        </Panel>
      </div>

      <Panel title="Explanation">
        <ExplanationSection
          title="Why was this assessment produced?"
          explanation={result.explanation} />
        
      </Panel>
    </div>);

}