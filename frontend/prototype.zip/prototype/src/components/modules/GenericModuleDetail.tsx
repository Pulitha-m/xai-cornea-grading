import React from 'react';
import type { ModuleDefinition } from '../../data/moduleRegistry';
import type { DonorCase, ModuleResult } from '../../types/case';
import { Panel } from '../ui/Panel';
import { ModuleOutputs } from './ModuleOutputs';
import { ExplanationSection } from './ExplanationSection';

interface DetailProps {
  donorCase: DonorCase;
  definition: ModuleDefinition;
  result: ModuleResult;
}

/**
 * Fallback detail view. Any newly registered research module renders through
 * this generic interface until it supplies its own panel.
 */
export function GenericModuleDetail({ definition, result }: DetailProps) {
  return (
    <div className="space-y-4">
      <Panel title="Module outputs" description={definition.purpose}>
        <ModuleOutputs outputs={result.outputs} columns={3} />
      </Panel>
      <Panel title="Explanation">
        <ExplanationSection explanation={result.explanation} />
      </Panel>
    </div>);

}