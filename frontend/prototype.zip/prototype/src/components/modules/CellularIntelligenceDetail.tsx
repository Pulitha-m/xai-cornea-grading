import React from 'react';
import { ChevronRightIcon, ImageOffIcon } from 'lucide-react';
import type { ModuleDefinition } from '../../data/moduleRegistry';
import type { DonorCase, ModuleResult } from '../../types/case';
import { Panel } from '../ui/Panel';
import { EmptyState } from '../ui/EmptyState';
import { ModuleOutputs } from './ModuleOutputs';
import { ExplanationSection } from './ExplanationSection';

const PIPELINE = [
'Image',
'Optimal ROI',
'Cell Detection',
'Cell Measurements',
'Clinical Biomarkers'];


interface DetailProps {
  donorCase: DonorCase;
  definition: ModuleDefinition;
  result: ModuleResult;
}

export function CellularIntelligenceDetail({ donorCase, definition, result }: DetailProps) {
  const stageState = (index: number): string => {
    if (result.status === 'Completed') return 'Completed';
    if (result.status === 'Running') return index === 0 ? 'Completed' : 'Queued';
    if (result.status === 'Needs Review') return index <= 1 ? 'Completed' : 'Withheld';
    return 'Not connected';
  };

  return (
    <div className="space-y-4">
      <Panel
        title="Processing pipeline"
        description="Stage view of the automated endothelial analysis. Stage states reflect the module's own reporting — this is a user-interface placeholder and no stage is computed here.">
        
        <ol className="flex flex-wrap items-stretch gap-1.5">
          {PIPELINE.map((stage, index) =>
          <li key={stage} className="flex items-stretch gap-1.5">
              <div className="min-w-[8.5rem] rounded border border-line bg-sunken px-3 py-2">
                <p className="text-xs font-medium text-ink-900">{stage}</p>
                <p className="mt-0.5 text-2xs text-ink-500">{stageState(index)}</p>
              </div>
              {index < PIPELINE.length - 1 &&
            <ChevronRightIcon
              className="my-auto h-4 w-4 shrink-0 text-ink-400"
              aria-hidden="true" />

            }
            </li>
          )}
        </ol>
      </Panel>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,18rem)_minmax(0,1fr)]">
        <Panel title="Source image">
          {donorCase.image.previewUrl ?
          <figure>
              <img
              src={donorCase.image.previewUrl}
              alt={`Endothelial specular microscopy image for case ${donorCase.caseId}`}
              className="w-full rounded border border-line bg-black object-cover" />
            
              <figcaption className="mt-2 space-y-0.5 text-2xs text-ink-500">
                <p className="font-mono text-ink-700">{donorCase.image.fileName}</p>
                <p>{donorCase.image.magnification ?? 'Magnification not recorded'}</p>
                <p>Image quality: {donorCase.image.qualityLabel ?? 'Not assessed'}</p>
              </figcaption>
            </figure> :

          <EmptyState
            compact
            icon={<ImageOffIcon className="h-5 w-5" />}
            title="No endothelial image"
            description="Cellular analysis requires an uploaded endothelial image for this case." />

          }
        </Panel>

        <div className="space-y-4">
          <Panel
            title="Cellular biomarkers"
            description="Reported by the Cellular Intelligence module. Values are withheld rather than estimated when analysis quality is insufficient.">
            
            <ModuleOutputs outputs={result.outputs} columns={3} />
          </Panel>
          <Panel title="Module explanation">
            <ExplanationSection
              title="How were these measurements produced?"
              explanation={result.explanation} />
            
          </Panel>
        </div>
      </div>
    </div>);

}