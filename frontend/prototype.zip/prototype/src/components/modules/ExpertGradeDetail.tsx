import React from 'react';
import { CheckIcon, MinusIcon } from 'lucide-react';
import type { ModuleDefinition } from '../../data/moduleRegistry';
import type { DonorCase, ModuleResult } from '../../types/case';
import { Panel } from '../ui/Panel';
import { GradeBadge } from '../ui/GradeBadge';
import { ModuleOutputs } from './ModuleOutputs';
import { ExplanationSection } from './ExplanationSection';

const GRADE_SCALE = ['A+', 'A', 'B'];

interface DetailProps {
  donorCase: DonorCase;
  definition: ModuleDefinition;
  result: ModuleResult;
}

export function ExpertGradeDetail({ donorCase, definition, result }: DetailProps) {
  const predicted = result.outputs.find((o) => o.label === 'Predicted Grade')?.value ?? null;
  const modalities = [
  { label: 'Donor information', present: true },
  { label: 'Clinical observations', present: donorCase.clinical.slitLampFindings !== 'Not yet recorded' },
  { label: 'Endothelial image', present: donorCase.image.uploadStatus === 'Uploaded' },
  {
    label: 'Cellular biomarkers',
    present: result.inputsUsed.some((i) => i.toLowerCase().includes('biomarker'))
  }];


  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,20rem)]">
        <Panel
          title="Predicted grade"
          description="Model output for specialist review. This is a predicted grade, not an eye-bank grading decision.">
          
          <div className="flex flex-wrap items-end gap-8">
            <div>
              <p className="text-2xs font-medium uppercase tracking-wide text-ink-400">
                Predicted grade
              </p>
              <p className="mt-1 font-mono text-4xl font-semibold leading-none text-ink-900">
                {predicted ?? '—'}
              </p>
              <p className="mt-1.5 text-2xs text-ink-500">Scale: A+ / A / B</p>
            </div>
            <div className="min-w-[12rem] flex-1">
              <div className="flex items-center justify-between text-2xs text-ink-500">
                <span className="font-medium uppercase tracking-wide">Model confidence</span>
                <span className="font-mono text-ink-900">
                  {result.confidence !== null ? result.confidence.toFixed(2) : 'Not available'}
                </span>
              </div>
              <div className="mt-1.5 h-1.5 w-full rounded-full bg-line" role="presentation">
                <div
                  className={`h-1.5 rounded-full ${
                  (result.confidence ?? 0) >= 0.75 ? 'bg-accent-500' : 'bg-warn-600'}`
                  }
                  style={{ width: `${Math.round((result.confidence ?? 0) * 100)}%` }} />
                
              </div>
              <p className="mt-1.5 text-2xs leading-relaxed text-ink-500">
                Predictions below 0.75 confidence are marked as requiring specialist review.
              </p>
            </div>
            <div className="flex gap-2">
              {GRADE_SCALE.map((grade) =>
              <div key={grade} className="text-center">
                  <GradeBadge grade={grade} />
                  <p className="mt-1 text-2xs text-ink-400">
                    {predicted === grade ? 'Predicted' : '—'}
                  </p>
                </div>
              )}
            </div>
          </div>

          <div className="mt-5 border-t border-line pt-4">
            <ModuleOutputs outputs={result.outputs} columns={2} />
          </div>
        </Panel>

        <Panel title="Input modalities">
          <ul className="space-y-2">
            {modalities.map((modality) =>
            <li key={modality.label} className="flex items-center gap-2 text-xs">
                {modality.present ?
              <CheckIcon className="h-3.5 w-3.5 shrink-0 text-ok-600" aria-hidden="true" /> :

              <MinusIcon className="h-3.5 w-3.5 shrink-0 text-ink-400" aria-hidden="true" />
              }
                <span className={modality.present ? 'text-ink-900' : 'text-ink-400'}>
                  {modality.label}
                </span>
                <span className="ml-auto text-2xs text-ink-500">
                  {modality.present ? 'Available' : 'Not available'}
                </span>
              </li>
            )}
          </ul>
          <p className="mt-3 border-t border-line pt-3 text-2xs leading-relaxed text-ink-500">
            This module runs on whichever modalities are present. It does not require another
            module to complete first.
          </p>
        </Panel>
      </div>

      <Panel title="Why did the model make this prediction?">
        <ExplanationSection
          title="Explanation artefacts"
          explanation={result.explanation} />
        
        <p className="mt-3 text-2xs leading-relaxed text-ink-500">
          SHAP values, Grad-CAM overlays, feature importance and image explanations will be
          rendered here by the grading research module. Nothing is inferred or written by the
          interface itself.
        </p>
      </Panel>
    </div>);

}