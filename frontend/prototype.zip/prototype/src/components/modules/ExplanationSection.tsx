import React from 'react';
import { CircleSlashIcon } from 'lucide-react';
import type { ModuleExplanation } from '../../types/case';

interface ExplanationSectionProps {
  title?: string;
  explanation: ModuleExplanation;
}

/**
 * Renders explanation availability only. No explanation is ever synthesised
 * here — when the research module has not produced an artefact, the UI says so.
 */
export function ExplanationSection({
  title = 'Explanation',
  explanation
}: ExplanationSectionProps) {
  return (
    <div>
      <h4 className="text-xs font-semibold text-ink-900">{title}</h4>
      <div className="mt-2 rounded border border-line bg-sunken px-3 py-3">
        <div className="flex items-start gap-2">
          <CircleSlashIcon className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ink-400" aria-hidden="true" />
          <p className="text-xs leading-relaxed text-ink-500">
            {explanation.available ? 'Explanation artefact available.' : explanation.note}
          </p>
        </div>
        {explanation.methods.length > 0 &&
        <div className="mt-3">
            <p className="text-2xs font-medium uppercase tracking-wide text-ink-400">
              Planned explanation methods
            </p>
            <ul className="mt-1.5 flex flex-wrap gap-1.5">
              {explanation.methods.map((method) =>
            <li
              key={method}
              className="rounded border border-line-strong bg-surface px-2 py-0.5 text-2xs text-ink-500">
              
                  {method}
                  <span className="ml-1.5 text-ink-400">Not generated</span>
                </li>
            )}
            </ul>
          </div>
        }
      </div>
    </div>);

}