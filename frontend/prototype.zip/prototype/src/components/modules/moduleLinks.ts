import { MODULE_IDS } from '../../data/moduleRegistry';

/**
 * Where the full analysis for a module lives. Modules that have a dedicated
 * workspace route point at it; everything else opens in the AI Analysis
 * workspace, anchored to that module.
 */
export function moduleViewHref(moduleId: string, caseId: string): string {
  if (moduleId === MODULE_IDS.decision) return `/review/${caseId}`;
  if (moduleId === MODULE_IDS.followUp) return `/follow-up/${caseId}`;
  return `/analysis/${caseId}?module=${moduleId}`;
}