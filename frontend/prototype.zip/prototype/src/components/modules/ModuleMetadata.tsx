import React from 'react';
import type { ModuleDefinition } from '../../data/moduleRegistry';
import type { ModuleResult } from '../../types/case';
import { formatDateTime } from '../../utils/format';

/**
 * Renders the generic module interface — metadata, inputs, outputs, quality,
 * timestamp — identically for every registered research module.
 */
export function ModuleMetadata({
  definition,
  result



}: {definition: ModuleDefinition;result: ModuleResult;}) {
  const rows: {label: string;value: React.ReactNode;}[] = [
  { label: 'Module ID', value: <span className="font-mono">{definition.id}</span> },
  { label: 'Owner', value: definition.owner },
  {
    label: 'Model endpoint',
    value: definition.modelConnected ? 'Connected' : 'Not connected in prototype'
  },
  { label: 'Result version', value: result.version ?? 'None' },
  { label: 'Last run', value: result.lastRun ? formatDateTime(result.lastRun) : 'Never' },
  {
    label: 'Inputs used',
    value: result.inputsUsed.length ? result.inputsUsed.join(', ') : 'None recorded'
  },
  {
    label: 'Expected outputs',
    value: definition.expectedOutputs.join(', ')
  }];


  return (
    <dl className="divide-y divide-line text-xs">
      {rows.map((row) =>
      <div key={row.label} className="flex gap-4 py-2 first:pt-0 last:pb-0">
          <dt className="w-36 shrink-0 text-ink-500">{row.label}</dt>
          <dd className="min-w-0 text-ink-900">{row.value}</dd>
        </div>
      )}
    </dl>);

}