import React from 'react';
import { MODULE_IDS } from '../../data/moduleRegistry';
import type { ModuleDefinition } from '../../data/moduleRegistry';
import type { DonorCase, ModuleResult } from '../../types/case';
import { CellularIntelligenceDetail } from './CellularIntelligenceDetail';
import { ExpertGradeDetail } from './ExpertGradeDetail';
import { DiseaseIntelligenceDetail } from './DiseaseIntelligenceDetail';
import { GenericModuleDetail } from './GenericModuleDetail';

export interface ModuleDetailProps {
  donorCase: DonorCase;
  definition: ModuleDefinition;
  result: ModuleResult;
}

type DetailComponent = (props: ModuleDetailProps) => JSX.Element;

/**
 * Detail-panel registry. A research module can supply its own panel by adding
 * one entry here; anything not registered falls back to the generic interface.
 */
const DETAIL_PANELS: Record<string, DetailComponent> = {
  [MODULE_IDS.cellular]: CellularIntelligenceDetail,
  [MODULE_IDS.grade]: ExpertGradeDetail,
  [MODULE_IDS.disease]: DiseaseIntelligenceDetail
};

export function getModuleDetailPanel(moduleId: string): DetailComponent {
  return DETAIL_PANELS[moduleId] ?? GenericModuleDetail;
}