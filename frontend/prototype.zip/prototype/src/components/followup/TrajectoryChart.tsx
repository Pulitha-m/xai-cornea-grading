import React from "react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { FollowUpPoint } from "../../types/case";

interface TrajectoryChartProps {
  title: string;
  metric: "ecd" | "cv" | "hex";
  unit: string;
  points: FollowUpPoint[];
}

export function TrajectoryChart({ title, metric, unit, points }: TrajectoryChartProps) {
  const data = points.map((point) => ({
    label: point.label,
    value: point[metric],
    recorded: point.recorded,
  }));
  const recorded = data.filter((d) => d.value !== null);

  return (
    <div className="min-w-0 rounded-md border border-line bg-surface p-4 shadow-card">
      <div className="flex items-baseline justify-between gap-2">
        <h3 className="text-xs font-semibold text-ink-900">{title}</h3>
        <span className="text-2xs text-ink-500">{unit}</span>
      </div>

      {recorded.length === 0 ? (
        <p className="mt-8 text-center text-xs text-ink-400">No measurements recorded</p>
      ) : (
        <>
          <div className="mt-4 h-40 min-w-0">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data} margin={{ top: 4, right: 8, bottom: 0, left: -12 }}>
                <CartesianGrid stroke="#e4e9ee" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 10, fill: "#5f7787" }} stroke="#ccd6de" tickLine={false} />

                <YAxis tick={{ fontSize: 10, fill: "#5f7787" }} stroke="#ccd6de" tickLine={false} domain={["auto", "auto"]} />

                <Tooltip
                  contentStyle={{
                    borderRadius: 4,
                    border: "1px solid #e4e9ee",
                    fontSize: 12,
                    boxShadow: "0 8px 24px -8px rgba(16,33,43,0.18)",
                  }}
                  formatter={(value: number) => [`${value} ${unit}`, title]}
                />

                <Line type="monotone" dataKey="value" stroke="#14708a" strokeWidth={2} dot={{ r: 3, fill: "#14708a", strokeWidth: 0 }} connectNulls isAnimationActive={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-1 text-2xs text-ink-400">
            {recorded.length} of {data.length} timepoints recorded · reference measurements
          </p>
        </>
      )}
    </div>
  );
}
