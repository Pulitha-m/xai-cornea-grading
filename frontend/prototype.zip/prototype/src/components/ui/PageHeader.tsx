import React from 'react';

interface PageHeaderProps {
  eyebrow?: React.ReactNode;
  title: string;
  description?: string;
  actions?: React.ReactNode;
  children?: React.ReactNode;
}

export function PageHeader({ eyebrow, title, description, actions, children }: PageHeaderProps) {
  return (
    <div className="mb-6 rounded-3xl border border-slate-200 bg-surface p-6 shadow-bento">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="min-w-0">
          {eyebrow && (
            <div className="text-2xs font-bold uppercase tracking-wider text-sky-700">{eyebrow}</div>
          )}
          <h1 className="mt-1 text-xl font-extrabold tracking-tight text-slate-900">{title}</h1>
          {description && (
            <p className="mt-1 text-xs leading-relaxed text-slate-500 max-w-3xl">{description}</p>
          )}
        </div>
        {actions && <div className="flex shrink-0 flex-wrap items-center gap-2.5">{actions}</div>}
      </div>
      {children}
    </div>
  );
}