/** Shared table styling for cohesive Bento-Grid data tables. */
export const tableClass = 'w-full border-collapse text-xs';

export const theadClass = 'border-b border-slate-100 bg-slate-50/60';

export const thClass =
  'px-4 py-3 text-left text-2xs font-semibold uppercase tracking-wider text-slate-400 whitespace-nowrap';

export const tdClass = 'border-b border-slate-100 px-4 py-3.5 align-middle text-slate-700 font-medium';

export const trClass = 'transition-colors duration-150 ease-out hover:bg-slate-50/80';