import React from 'react';

interface PanelProps {
  title?: string;
  description?: string;
  actions?: React.ReactNode;
  meta?: React.ReactNode;
  id?: string;
  flush?: boolean;
  className?: string;
  p?: number | string;
  onClick?: () => void;
  children: React.ReactNode;
}

export function Panel({
  title,
  description,
  actions,
  meta,
  id,
  flush = false,
  className,
  p,
  onClick,
  children
}: PanelProps) {
  return (
    <section
      id={id}
      onClick={onClick}
      className={`rounded-3xl border border-slate-200 bg-surface shadow-bento scroll-mt-24 overflow-hidden ${className || ''}`}
      aria-labelledby={title && id ? `${id}-title` : undefined}>
      {(title || actions) && (
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-6 py-4">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2.5">
              {title && (
                <h2
                  id={title && id ? `${id}-title` : undefined}
                  className="text-sm font-bold text-slate-900">
                  {title}
                </h2>
              )}
              {meta}
            </div>
            {description && <p className="mt-0.5 text-2xs leading-relaxed text-slate-500">{description}</p>}
          </div>
          {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
        </header>
      )}
      <div className={flush ? '' : 'p-6'}>{children}</div>
    </section>
  );
}