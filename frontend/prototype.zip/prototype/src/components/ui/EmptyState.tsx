import React from 'react';

interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
  compact?: boolean;
}

export function EmptyState({ icon, title, description, action, compact }: EmptyStateProps) {
  return (
    <div
      className={`flex flex-col items-center justify-center rounded border border-dashed border-line-strong bg-sunken text-center ${
      compact ? 'px-4 py-6' : 'px-6 py-10'}`
      }>
      
      {icon && <div className="mb-2 text-ink-400">{icon}</div>}
      <p className="text-sm font-medium text-ink-700">{title}</p>
      {description && <p className="mt-1 max-w-md text-xs leading-relaxed text-ink-500">{description}</p>}
      {action && <div className="mt-3">{action}</div>}
    </div>);

}