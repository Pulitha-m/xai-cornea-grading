import React from 'react';
import type { Provenance } from '../../types/case';

const STYLES: Record<Provenance, string> = {
  'AI Prediction': 'border-accent-200 bg-accent-50 text-accent-700',
  'AI Analysis': 'border-accent-200 bg-accent-50 text-accent-700',
  'Reference Measurement': 'border-line-strong bg-sunken text-ink-700',
  'Specialist Assessment': 'border-ok-200 bg-ok-50 text-ok-700',
  'Staff Entered': 'border-line-strong bg-sunken text-ink-500'
};

/** Makes the origin of every displayed value explicit. */
export function ProvenanceTag({ provenance }: {provenance: Provenance;}) {
  return (
    <span
      className={`inline-flex items-center whitespace-nowrap rounded border px-1.5 py-px text-2xs font-medium uppercase tracking-wide ${STYLES[provenance]}`}>
      
      {provenance}
    </span>);

}