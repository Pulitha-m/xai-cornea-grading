import React from 'react';
import type { ModuleStatus } from '../../types/case';

const STYLES: Record<ModuleStatus | 'Partial' | 'In Treatment' | 'Waiting', { cls: string; dot: string }> = {
  'Not Run': { cls: 'bg-slate-100 text-slate-600 border-slate-200', dot: 'bg-slate-400' },
  Running: { cls: 'bg-sky-100 text-sky-800 border-sky-200 font-semibold', dot: 'bg-sky-500 animate-pulse' },
  Completed: { cls: 'bg-emerald-100 text-emerald-800 border-emerald-200 font-medium', dot: 'bg-emerald-500' },
  'Needs Review': { cls: 'bg-amber-100 text-amber-900 border-amber-300 font-semibold', dot: 'bg-amber-500' },
  Unavailable: { cls: 'bg-rose-100 text-rose-800 border-rose-200 font-medium', dot: 'bg-rose-500' },
  Partial: { cls: 'bg-sky-100 text-sky-800 border-sky-200 font-medium', dot: 'bg-sky-500' },
  'In Treatment': { cls: 'bg-sky-100 text-sky-800 border-sky-200 font-semibold', dot: 'bg-sky-500' },
  Waiting: { cls: 'bg-amber-100 text-amber-900 border-amber-300 font-semibold', dot: 'bg-amber-500' },
};

interface StatusBadgeProps {
  status: ModuleStatus | 'Partial' | 'In Treatment' | 'Waiting' | string;
  label?: string;
  size?: 'sm' | 'md';
}

export function StatusBadge({ status, label, size = 'sm' }: StatusBadgeProps) {
  const style = STYLES[status as keyof typeof STYLES] ?? STYLES['Not Run'];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border font-medium ${style.cls} ${
        size === 'sm' ? 'px-2.5 py-0.5 text-2xs' : 'px-3 py-1 text-xs'
      }`}>
      <span className={`h-1.5 w-1.5 rounded-full ${style.dot}`} aria-hidden="true" />
      {label ?? status}
    </span>
  );
}