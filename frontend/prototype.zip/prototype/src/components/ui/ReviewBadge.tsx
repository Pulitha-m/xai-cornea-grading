import React from 'react';
import type { ReviewStatus } from '../../types/case';

const STYLES: Record<ReviewStatus, string> = {
  'Pending Review': 'bg-warn-50 text-warn-700 border-warn-200',
  'Under Review': 'bg-accent-50 text-accent-700 border-accent-200',
  'Specialist Reviewed': 'bg-ok-50 text-ok-700 border-ok-200',
  'Awaiting Information': 'bg-sunken text-ink-500 border-line-strong'
};

export function ReviewBadge({ status }: {status: ReviewStatus;}) {
  return (
    <span
      className={`inline-flex items-center rounded border px-2 py-0.5 text-2xs font-medium ${STYLES[status]}`}>
      
      {status}
    </span>);

}