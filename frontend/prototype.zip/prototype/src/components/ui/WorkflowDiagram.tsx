import React, { useState } from "react";
import { CheckCircle2Icon, ChevronRightIcon } from "lucide-react";

export interface WorkflowStep {
  label: string;
  detail: string;
  role: string;
  action: string;
  tone?: "blue" | "green" | "amber" | "slate";
}

const toneClasses = {
  blue: "border-sky-200 bg-sky-50 text-sky-900",
  green: "border-emerald-200 bg-emerald-50 text-emerald-900",
  amber: "border-amber-200 bg-amber-50 text-amber-900",
  slate: "border-slate-200 bg-slate-50 text-slate-800",
};

export function WorkflowDiagram({ title, steps }: { title: string; steps: WorkflowStep[] }) {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const selected = steps[selectedIndex];

  return (
    <section className="rounded-2xl border border-slate-200 bg-slate-50/70 p-5" aria-label={title}>
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-2xs font-extrabold uppercase tracking-wider text-sky-700">Interactive workflow</p>
          <h2 className="mt-1 text-sm font-extrabold text-slate-900">{title}</h2>
        </div>
        <span className="text-2xs font-bold text-slate-400">Select a stage for its handoff</span>
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-2">
        {steps.map((step, index) => (
          <React.Fragment key={step.label}>
            <button
              type="button"
              onClick={() => setSelectedIndex(index)}
              aria-pressed={selectedIndex === index}
              className={`flex items-center gap-2 rounded-xl border px-3 py-2 text-left text-xs font-bold transition-colors ${toneClasses[step.tone ?? "slate"]} ${selectedIndex === index ? "ring-2 ring-sky-400 ring-offset-1" : "opacity-75 hover:opacity-100"}`}
            >
              {index < selectedIndex ? <CheckCircle2Icon className="h-3.5 w-3.5" /> : <span className="flex h-4 w-4 items-center justify-center rounded-full bg-white/70 text-2xs">{index + 1}</span>}
              {step.label}
            </button>
            {index < steps.length - 1 && <ChevronRightIcon className="h-4 w-4 shrink-0 text-slate-300" />}
          </React.Fragment>
        ))}
      </div>
      <div className="mt-4 grid gap-3 border-t border-slate-200 pt-4 sm:grid-cols-3">
        <div>
          <p className="text-2xs font-extrabold uppercase tracking-wider text-slate-400">Inputs / evidence</p>
          <p className="mt-1 text-xs font-semibold text-slate-700">{selected.detail}</p>
        </div>
        <div>
          <p className="text-2xs font-extrabold uppercase tracking-wider text-slate-400">Responsible role</p>
          <p className="mt-1 text-xs font-semibold text-slate-700">{selected.role}</p>
        </div>
        <div>
          <p className="text-2xs font-extrabold uppercase tracking-wider text-slate-400">Next action</p>
          <p className="mt-1 text-xs font-semibold text-slate-700">{selected.action}</p>
        </div>
      </div>
    </section>
  );
}
