import React from 'react';
import type { Provenance } from '../../types/case';
import { ProvenanceTag } from './ProvenanceTag';

interface FieldProps {
  label: string;
  value: React.ReactNode;
  unit?: string;
  provenance?: Provenance;
  reference?: string;
  note?: string;
  /** Renders the value in monospace — used for measurements and identifiers. */
  mono?: boolean;
}

export function Field({ label, value, unit, provenance, reference, note, mono }: FieldProps) {
  const isEmpty = value === null || value === undefined || value === '';
  return (
    <div className="min-w-0">
      <dt className="flex items-center gap-2 text-2xs font-medium uppercase tracking-wide text-ink-400">
        <span className="truncate">{label}</span>
        {provenance && <ProvenanceTag provenance={provenance} />}
      </dt>
      <dd
        className={`mt-1 text-sm ${
        isEmpty ? 'text-ink-400' : 'text-ink-900'} ${
        mono ? 'font-mono' : ''}`}>
        
        {isEmpty ? 'Not available' : value}
        {!isEmpty && unit && <span className="ml-1 text-xs text-ink-500">{unit}</span>}
      </dd>
      {reference && <p className="mt-0.5 text-2xs text-ink-500">{reference}</p>}
      {note && <p className="mt-0.5 text-2xs italic text-ink-400">{note}</p>}
    </div>);

}