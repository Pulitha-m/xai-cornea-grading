import React from 'react';

type Variant = 'primary' | 'secondary' | 'yellow' | 'ghost' | 'danger';
type Size = 'xs' | 'sm' | 'md' | 'lg';

const VARIANTS: Record<Variant, string> = {
  primary:
    'bg-accent-600 text-white border border-accent-600 hover:bg-accent-700 hover:border-accent-700 shadow-sm active:scale-95',
  secondary:
    'bg-surface text-ink-700 border border-slate-200 hover:bg-slate-50 hover:text-ink-900 shadow-sm active:scale-95',
  yellow:
    'bg-amber-400 text-ink-900 border border-amber-300 hover:bg-amber-300 font-semibold shadow-sm active:scale-95',
  ghost: 'bg-transparent text-slate-700 border border-transparent hover:bg-slate-100 active:scale-95',
  danger: 'bg-alert-50 text-alert-700 border border-alert-200 hover:bg-alert-100 active:scale-95'
};

const SIZES: Record<Size, string> = {
  xs: 'h-6 px-2.5 text-2xs gap-1 rounded-full',
  sm: 'h-8 px-3 text-xs gap-1.5 rounded-full',
  md: 'h-9 px-4 text-sm gap-2 rounded-full',
  lg: 'h-11 px-5 text-base gap-2.5 rounded-full'
};

export function buttonClass(variant: Variant = 'secondary', size: Size = 'sm'): string {
  return [
    'inline-flex items-center justify-center whitespace-nowrap font-medium',
    'transition-all duration-150 ease-out',
    'disabled:cursor-not-allowed disabled:opacity-50',
    VARIANTS[variant],
    SIZES[size]
  ].join(' ');
}

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

export function Button({ variant = 'secondary', size = 'sm', className = '', ...rest }: ButtonProps) {
  return <button type="button" className={`${buttonClass(variant, size)} ${className}`} {...rest} />;
}