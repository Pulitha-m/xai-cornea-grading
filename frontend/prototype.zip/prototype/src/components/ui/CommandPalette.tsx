import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { SearchIcon, EyeIcon, UserCheckIcon, SparklesIcon, ArrowRightIcon, XIcon } from 'lucide-react';
import { useCaseStore } from '../../contexts/CaseStore';
import { useSession } from '../../contexts/SessionContext';
import type { Role } from '../../types/user';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CommandPalette({ isOpen, onClose }: CommandPaletteProps) {
  const [query, setQuery] = useState('');
  const { cases } = useCaseStore();
  const { role, signIn } = useSession();
  const navigate = useNavigate();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else setQuery('');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filteredCases = cases.filter(
    (c) =>
      c.id.toLowerCase().includes(query.toLowerCase()) ||
      c.donorCode.toLowerCase().includes(query.toLowerCase()) ||
      c.diagnosis.toLowerCase().includes(query.toLowerCase()) ||
      c.eyeBankTechnician.toLowerCase().includes(query.toLowerCase())
  );

  const handleSelectCase = (caseId: string) => {
    navigate(`/cases/${caseId}`);
    onClose();
  };

  const handleSwitchRole = (newRole: Role) => {
    signIn(newRole === 'Admin' ? 'NEB-A-3011' : newRole === 'Specialist' ? 'NEB-S-2087' : 'NEB-T-1042', newRole);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 bg-slate-900/40 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl overflow-hidden rounded-3xl bg-surface shadow-pop border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Search Input Header */}
        <div className="flex items-center gap-3 border-b border-slate-100 px-5 py-4 bg-slate-50/50">
          <SearchIcon className="h-5 w-5 text-sky-600 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search donor cases, tissue IDs, diagnosis, or switch roles..."
            className="w-full bg-transparent text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none"
            autoFocus
          />
          <button
            onClick={onClose}
            className="rounded-full p-1 text-slate-400 hover:bg-slate-200 hover:text-slate-700 transition-colors">
            <XIcon className="h-4 w-4" />
          </button>
        </div>

        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-4">
          {/* Quick Role Switcher */}
          <div>
            <div className="flex items-center gap-2 px-3 py-1.5 text-2xs font-semibold uppercase tracking-wider text-slate-400">
              <UserCheckIcon className="h-3.5 w-3.5 text-amber-500" />
              Quick Role Switch (Demo)
            </div>
            <div className="grid grid-cols-3 gap-2 mt-1">
              {[
                { r: 'Technician', label: 'Technician', desc: 'Case Intake & Images', color: 'bg-sky-50 text-sky-800 border-sky-200' },
                { r: 'Specialist', label: 'Specialist', desc: 'Clinical Review & Signoff', color: 'bg-amber-50 text-amber-900 border-amber-200' },
                { r: 'Admin', label: 'Administrator', desc: 'Telemetry & Modules', color: 'bg-slate-100 text-slate-900 border-slate-300' },
              ].map((item) => (
                <button
                  key={item.r}
                  onClick={() => handleSwitchRole(item.r as Role)}
                  className={`flex flex-col p-3 text-left rounded-2xl border transition-all ${item.color} hover:scale-[1.02] ${
                    role === item.r ? 'ring-2 ring-sky-500 font-bold' : ''
                  }`}>
                  <span className="text-xs font-semibold flex items-center justify-between">
                    {item.label}
                    {role === item.r && <span className="h-2 w-2 rounded-full bg-sky-500" />}
                  </span>
                  <span className="text-2xs opacity-75 mt-0.5">{item.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Quick Navigation Pages */}
          <div>
            <div className="flex items-center gap-2 px-3 py-1.5 text-2xs font-semibold uppercase tracking-wider text-slate-400">
              <SparklesIcon className="h-3.5 w-3.5 text-sky-500" />
              Quick Navigation
            </div>
            <div className="grid grid-cols-2 gap-2 mt-1">
              {[
                { label: 'All Donor Cases', path: '/cases' },
                { label: 'Corneal AI Analysis', path: '/analysis' },
                { label: 'Specialist Review Queue', path: '/review' },
                { label: 'System Audit History', path: '/audit' },
              ].map((nav) => (
                <button
                  key={nav.path}
                  onClick={() => {
                    navigate(nav.path);
                    onClose();
                  }}
                  className="flex items-center justify-between p-3 rounded-2xl border border-slate-100 bg-slate-50/50 text-xs font-medium text-slate-700 hover:bg-sky-50 hover:border-sky-200 hover:text-sky-900 transition-all">
                  <span>{nav.label}</span>
                  <ArrowRightIcon className="h-3.5 w-3.5 text-slate-400" />
                </button>
              ))}
            </div>
          </div>

          {/* Donor Cases Search Results */}
          <div>
            <div className="flex items-center gap-2 px-3 py-1.5 text-2xs font-semibold uppercase tracking-wider text-slate-400">
              <EyeIcon className="h-3.5 w-3.5 text-sky-500" />
              Matching Cases ({filteredCases.length})
            </div>
            <div className="space-y-1 mt-1">
              {filteredCases.slice(0, 5).map((c) => (
                <button
                  key={c.id}
                  onClick={() => handleSelectCase(c.id)}
                  className="flex items-center justify-between w-full p-3 rounded-2xl border border-transparent hover:border-slate-200 hover:bg-slate-50 transition-all text-left">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-semibold text-sky-700">{c.id}</span>
                      <span className="text-2xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-medium">
                        {c.donorCode}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mt-0.5">{c.diagnosis}</p>
                  </div>
                  <span className="text-2xs font-medium px-2.5 py-1 rounded-full bg-sky-100 text-sky-800">
                    {c.specialistDecision ? c.specialistDecision.suitability : 'Pending'}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between border-t border-slate-100 bg-slate-50 px-5 py-2.5 text-2xs text-slate-500">
          <span>Use <kbd className="px-1.5 py-0.5 rounded bg-surface border border-slate-200 font-mono">⌘K</kbd> to toggle</span>
          <span>NEBSL Corneal Intelligence Prototype</span>
        </div>
      </div>
    </div>
  );
}
