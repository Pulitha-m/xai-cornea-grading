import React from 'react';

/**
 * Displays a predicted eye-bank grade. Always rendered with the "Predicted"
 * framing in context — a grade shown here is a model output, never a decision.
 */
export function GradeBadge({ grade }: {grade: string | null;}) {
  if (!grade) {
    return <span className="text-xs text-ink-400">Not predicted</span>;
  }
  const tone =
  grade === 'A+' ?
  'border-ok-200 bg-ok-50 text-ok-700' :
  grade === 'A' ?
  'border-accent-200 bg-accent-50 text-accent-700' :
  'border-warn-200 bg-warn-50 text-warn-700';
  return (
    <span
      className={`inline-flex min-w-[2.25rem] justify-center rounded border px-1.5 py-0.5 font-mono text-xs font-medium ${tone}`}>
      
      {grade}
    </span>);

}