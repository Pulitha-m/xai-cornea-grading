import React, { useState } from 'react';
import { XIcon, UserPlusIcon, ShieldCheckIcon } from 'lucide-react';
import { Button } from '../ui/Button';
import type { Role } from '../../types/user';

interface AdminStaffModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AdminStaffModal({ isOpen, onClose }: AdminStaffModalProps) {
  const [name, setName] = useState('');
  const [staffId, setStaffId] = useState('');
  const [role, setRole] = useState<Role>('Technician');
  const [successMsg, setSuccessMsg] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !staffId) return;
    setSuccessMsg(true);
    setTimeout(() => {
      setSuccessMsg(false);
      setName('');
      setStaffId('');
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg rounded-3xl bg-surface p-6 shadow-pop border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-sky-100 text-sky-700">
              <UserPlusIcon className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Provision Staff Account</h3>
              <p className="text-xs text-slate-500">Assign role permissions and RBAC scope</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700">
            <XIcon className="h-4 w-4" />
          </button>
        </div>

        {successMsg ? (
          <div className="my-8 flex flex-col items-center justify-center text-center p-6 bg-emerald-50 rounded-2xl border border-emerald-200">
            <ShieldCheckIcon className="h-10 w-10 text-emerald-600 mb-2" />
            <h4 className="text-sm font-bold text-emerald-900">Staff Member Provisioned!</h4>
            <p className="text-xs text-emerald-700 mt-1">Credentials and access key sent to system audit.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-5 space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Dr. Kasun Jayawardena"
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 focus:border-sky-500 focus:bg-surface focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Staff ID</label>
              <input
                type="text"
                required
                value={staffId}
                onChange={(e) => setStaffId(e.target.value)}
                placeholder="e.g. NEB-S-9041"
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-2 font-mono text-sm text-slate-900 focus:border-sky-500 focus:bg-surface focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Assigned Role</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as Role)}
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 focus:border-sky-500 focus:bg-surface focus:outline-none">
                <option value="Technician">Eye-Bank Technician (Intake &amp; Image Upload)</option>
                <option value="Specialist">Specialist Reviewer (Clinical Sign-off)</option>
                <option value="Admin">System Administrator (Telemetry &amp; Auditing)</option>
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <Button type="button" variant="ghost" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" variant="primary">
                Provision Account
              </Button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
