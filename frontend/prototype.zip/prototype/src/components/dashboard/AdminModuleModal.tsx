import React, { useState } from 'react';
import { XIcon, CpuIcon, CheckCircle2Icon } from 'lucide-react';
import { Button } from '../ui/Button';

interface AdminModuleModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AdminModuleModal({ isOpen, onClose }: AdminModuleModalProps) {
  const [moduleName, setModuleName] = useState('');
  const [moduleId, setModuleId] = useState('');
  const [owner, setOwner] = useState('');
  const [endpoint, setEndpoint] = useState('');
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!moduleName || !endpoint) return;
    setSuccess(true);
    setTimeout(() => {
      setSuccess(false);
      setModuleName('');
      setModuleId('');
      setOwner('');
      setEndpoint('');
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg rounded-3xl bg-surface p-6 shadow-pop border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-amber-100 text-amber-700">
              <CpuIcon className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Register AI Analysis Module</h3>
              <p className="text-xs text-slate-500">Connect research neural network endpoint</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700">
            <XIcon className="h-4 w-4" />
          </button>
        </div>

        {success ? (
          <div className="my-8 flex flex-col items-center justify-center text-center p-6 bg-sky-50 rounded-2xl border border-sky-200">
            <CheckCircle2Icon className="h-10 w-10 text-sky-600 mb-2" />
            <h4 className="text-sm font-bold text-sky-900">AI Module Registered!</h4>
            <p className="text-xs text-sky-700 mt-1">Endpoint handshake completed successfully.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-5 space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Module Name</label>
              <input
                type="text"
                required
                value={moduleName}
                onChange={(e) => setModuleName(e.target.value)}
                placeholder="e.g. Endothelial Morphometry V3"
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 focus:border-sky-500 focus:bg-surface focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Module ID</label>
                <input
                  type="text"
                  required
                  value={moduleId}
                  onChange={(e) => setModuleId(e.target.value)}
                  placeholder="mod-morph-v3"
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-2 font-mono text-sm text-slate-900 focus:border-sky-500 focus:bg-surface focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Research Lead / Owner</label>
                <input
                  type="text"
                  required
                  value={owner}
                  onChange={(e) => setOwner(e.target.value)}
                  placeholder="Univ. BioLab Team A"
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 focus:border-sky-500 focus:bg-surface focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">API Endpoint URL</label>
              <input
                type="url"
                required
                value={endpoint}
                onChange={(e) => setEndpoint(e.target.value)}
                placeholder="https://ai.eyebank.lk/api/v1/morphometry"
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-2 font-mono text-xs text-slate-900 focus:border-sky-500 focus:bg-surface focus:outline-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <Button type="button" variant="ghost" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" variant="yellow">
                Connect Module Endpoint
              </Button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
