import React from 'react';

export interface Stat {
  label: string;
  value: number | string;
  note: string;
  emphasis?: boolean;
}

const COLUMNS: Record<number, string> = {
  2: 'sm:grid-cols-2',
  3: 'sm:grid-cols-3',
  4: 'grid-cols-2 lg:grid-cols-4'
};

export function StatStrip({ stats }: { stats: Stat[] }) {
  const columns = COLUMNS[stats.length] ?? 'sm:grid-cols-3';

  return (
    <div className={`grid gap-4 ${columns}`}>
      {stats.map((stat) => (
        <div
          key={stat.label}
          className={`rounded-3xl border p-5 shadow-bento transition-all hover:scale-[1.01] ${
            stat.emphasis
              ? 'border-amber-200 bg-amber-50/70 text-amber-900'
              : 'border-slate-200 bg-surface text-slate-900'
          }`}>
          <p className={`text-xs font-bold ${stat.emphasis ? 'text-amber-900' : 'text-slate-500'}`}>
            {stat.label}
          </p>
          <p className="mt-1 font-mono text-2xl font-extrabold leading-none">
            {stat.value}
          </p>
          <p className={`mt-1.5 text-2xs ${stat.emphasis ? 'text-amber-700 font-medium' : 'text-slate-400'}`}>
            {stat.note}
          </p>
        </div>
      ))}
    </div>
  );
}