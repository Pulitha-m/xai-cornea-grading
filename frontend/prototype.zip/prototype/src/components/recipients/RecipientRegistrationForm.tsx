import { useState } from "react";
import { toast } from "sonner";
import { Button } from "../ui/Button";
import { Panel } from "../ui/Panel";
import type { MatchingFixture } from "../../data/workflowFixtures";
import type { Branch } from "../../types/user";

export function RecipientRegistrationForm({ onSave, onCancel }: { onSave: (recipient: MatchingFixture) => void; onCancel: () => void }) {
  const [name, setName] = useState("");
  const [diagnosis, setDiagnosis] = useState("");
  const [severity, setSeverity] = useState("High");
  const [age, setAge] = useState("60");
  const [sex, setSex] = useState<"Female" | "Male">("Female");
  const [condition, setCondition] = useState("");
  const [previousTransplant, setPreviousTransplant] = useState("No previous transplant");
  const [graft, setGraft] = useState("Endothelial keratoplasty");
  const [branch, setBranch] = useState<Branch>("Colombo");
  const save = () => {
    if (!name.trim() || !diagnosis.trim()) {
      toast.error("Enter the recipient name and transplant indication.");
      return;
    }
    onSave({
      recipientId: `REC-2026-${String(Date.now()).slice(-3)}`,
      name,
      age: Number(age) || 60,
      sex,
      diagnosis,
      urgency: severity === "Emergency" ? "Emergency" : severity === "High" ? "High" : "Normal",
      bloodType: "Pending",
      assignedBranch: branch,
      status: "Waiting List",
      severity,
      clinicalCondition: condition,
      previousTransplant,
      requiredGraft: graft,
      registrationDate: new Date().toISOString().slice(0, 10),
      matchStatus: "Ready for comparison",
      evidence: [
        { label: "Eligibility", value: "Clinical review complete", weight: 25 },
        { label: "Disease compatibility", value: "Pending matching run", weight: 25 },
        { label: "Urgency", value: `${severity} priority`, weight: 25 },
        { label: "Graft requirement", value: graft, weight: 25 },
      ],
      nurseAction: "Run matching and compare candidates",
      doctorAction: "Review clinical evidence and sign off",
      allocationAction: "Pending Doctor approval",
      matchScore: undefined,
      matchedCaseId: null,
    });
    toast.success("Recipient added to the waiting list.");
  };
  return (
    <Panel title="Register new recipient" description="Doctor and Nurse / Technician can add an eligible recipient to the waiting list." className="border-sky-200">
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="text-xs font-bold text-slate-700">
          Recipient name
          <input value={name} onChange={(event) => setName(event.target.value)} className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 font-normal" placeholder="Full name" />
        </label>
        <label className="text-xs font-bold text-slate-700">
          Age
          <input type="number" value={age} onChange={(event) => setAge(event.target.value)} className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 font-normal" />
        </label>
        <label className="text-xs font-bold text-slate-700">
          Sex
          <select value={sex} onChange={(event) => setSex(event.target.value as "Female" | "Male")} className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 font-normal">
            <option>Female</option>
            <option>Male</option>
          </select>
        </label>
        <label className="text-xs font-bold text-slate-700">
          Branch
          <select value={branch} onChange={(event) => setBranch(event.target.value as Branch)} className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 font-normal">
            <option>Colombo</option>
            <option>Kandy</option>
            <option>Kurunegala</option>
          </select>
        </label>
        <label className="text-xs font-bold text-slate-700">
          Disease / transplant indication
          <input value={diagnosis} onChange={(event) => setDiagnosis(event.target.value)} className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 font-normal" placeholder="e.g. Fuchs dystrophy" />
        </label>
        <label className="text-xs font-bold text-slate-700">
          Disease severity
          <select value={severity} onChange={(event) => setSeverity(event.target.value)} className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 font-normal">
            <option>Emergency</option>
            <option>High</option>
            <option>Normal</option>
          </select>
        </label>
        <label className="text-xs font-bold text-slate-700">
          Clinical condition
          <input value={condition} onChange={(event) => setCondition(event.target.value)} className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 font-normal" placeholder="Relevant clinical factors" />
        </label>
        <label className="text-xs font-bold text-slate-700">
          Previous transplant history
          <select value={previousTransplant} onChange={(event) => setPreviousTransplant(event.target.value)} className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 font-normal">
            <option>No previous transplant</option>
            <option>Previous transplant</option>
          </select>
        </label>
        <label className="text-xs font-bold text-slate-700 sm:col-span-2">
          Required graft characteristics
          <input value={graft} onChange={(event) => setGraft(event.target.value)} className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 font-normal" placeholder="Graft type and required tissue characteristics" />
        </label>
      </div>
      <div className="mt-4 flex justify-end gap-2">
        <Button variant="secondary" size="sm" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="primary" size="sm" onClick={save}>
          Add to waiting list
        </Button>
      </div>
    </Panel>
  );
}
