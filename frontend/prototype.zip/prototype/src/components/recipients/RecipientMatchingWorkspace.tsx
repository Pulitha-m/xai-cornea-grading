import { useState } from "react";
import { toast } from "sonner";
import { CheckCircle2Icon, ChevronDownIcon, GitCompareArrowsIcon, SparklesIcon, TriangleAlertIcon } from "lucide-react";
import { Button } from "../ui/Button";
import { Panel } from "../ui/Panel";
import type { AvailableCorneaFixture, MatchingFixture } from "../../data/workflowFixtures";

interface RankedCornea extends AvailableCorneaFixture {
  score: number;
  strengths: string[];
  concerns: string[];
  contributions: { label: string; value: number }[];
}

function rankCorneas(recipient: MatchingFixture, corneas: AvailableCorneaFixture[]): RankedCornea[] {
  const urgencyBonus = recipient.urgency === "Emergency" ? 4 : recipient.urgency === "High" ? 2 : 0;
  return corneas
    .map((cornea, index) => {
      const score = Math.round((cornea.suitability === "Suitable" ? 42 : 31) + cornea.ecd / 100 + (70 - cornea.cv) / 3 + cornea.hex / 6 + urgencyBonus - index * 2);
      const strengths = [cornea.suitability === "Suitable" ? "Suitable cornea" : "Potentially usable tissue", `High ECD — ${cornea.ecd}`, `Low CV — ${cornea.cv}%`, `Good HEX — ${cornea.hex}%`, cornea.diseaseScreen === "Clear" ? "Clear disease screen" : "Disease review required"];
      const concerns = cornea.suitability === "Marginal" ? ["Grade B", `Lower ECD than the leading candidate`, `Higher CV and lower HEX`, "Disease review required"] : index > 0 ? ["Slightly lower endothelial reserve", "Lower ranked compatibility contribution"] : [];
      return {
        ...cornea,
        score: Math.min(score, 99),
        strengths,
        concerns,
        contributions: [
          { label: "Corneal suitability", value: cornea.suitability === "Suitable" ? 95 : 72 },
          { label: "Endothelial quality", value: Math.min(99, Math.round(cornea.ecd / 30)) },
          { label: "Disease compatibility", value: cornea.diseaseScreen === "Clear" ? 96 : 68 },
          { label: "Recipient compatibility", value: Math.max(70, 94 - index * 5) },
          { label: "Historical evidence", value: Math.max(70, 90 - index * 6) },
        ],
      };
    })
    .sort((a, b) => b.score - a.score);
}

export function RecipientMatchingWorkspace({ recipient, corneas, can, role }: { recipient: MatchingFixture; corneas: AvailableCorneaFixture[]; can: (resource: "Recipient", action: "match" | "approve") => boolean; role: string | null }) {
  const [showWhy, setShowWhy] = useState<string | null>(null);
  const [compare, setCompare] = useState(false);
  const ranked = rankCorneas(recipient, corneas);
  const action = (message: string) => toast.success(message, { description: "Prototype handoff recorded for this recipient." });

  return (
    <Panel title="AI matching results" description={`Top 3 available corneas ranked for ${recipient.name}. AI ranking is decision support; Doctor approval remains required.`} className="border-sky-200">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-2xs font-extrabold uppercase tracking-wider text-sky-700">Recipient-specific ranking</p>
          <p className="mt-1 text-xs font-semibold text-slate-600">
            {recipient.diagnosis} · {recipient.urgency} priority · {recipient.bloodType}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" size="sm" onClick={() => setCompare((value) => !value)}>
            <GitCompareArrowsIcon className="h-4 w-4" />
            {compare ? "Close comparison" : "Compare top 3"}
          </Button>
          {can("Recipient", "match") && (
            <Button variant="primary" size="sm" onClick={() => action("AI matching run completed")}>
              <SparklesIcon className="h-4 w-4" />
              Find best matches
            </Button>
          )}
        </div>
      </div>
      <div className="grid gap-4 xl:grid-cols-3">
        {ranked.map((cornea, index) => {
          const isOpen = showWhy === cornea.corneaId;
          return (
            <article key={cornea.corneaId} className={`rounded-2xl border p-4 ${index === 0 ? "border-sky-300 bg-sky-50/70" : "border-slate-200 bg-white"}`}>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-2xs font-extrabold uppercase tracking-wider text-sky-700">#{index + 1} recommended</p>
                  <h3 className="mt-1 font-mono text-sm font-extrabold text-slate-900">{cornea.corneaId}</h3>
                </div>
                <div className="text-right">
                  <p className="text-xl font-black text-emerald-700">{cornea.score}%</p>
                  <p className="text-[10px] font-extrabold uppercase text-emerald-800">match score</p>
                </div>
              </div>
              <p className="mt-2 text-2xs font-semibold text-slate-500">
                Grade {cornea.grade} · {cornea.branch} · {cornea.donorCaseId}
              </p>
              <div className="mt-3 grid grid-cols-4 gap-1.5 text-center">
                <Metric label="ECD" value={String(cornea.ecd)} />
                <Metric label="CV" value={`${cornea.cv}%`} />
                <Metric label="HEX" value={`${cornea.hex}%`} />
                <Metric label="CHI" value={String(cornea.chi)} />
              </div>
              <p className={`mt-3 inline-flex rounded-full px-2 py-1 text-2xs font-extrabold ${cornea.suitability === "Suitable" ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-900"}`}>{cornea.suitability}</p>
              <p className="mt-2 text-2xs font-semibold text-slate-600">Disease: {cornea.diseaseScreen}</p>
              <p className="mt-1 text-2xs font-semibold text-slate-600">History: {cornea.historicalEvidence}</p>
              <button type="button" onClick={() => setShowWhy(isOpen ? null : cornea.corneaId)} className="mt-3 flex w-full items-center justify-between border-t border-slate-200 pt-3 text-left text-xs font-extrabold text-sky-800">
                <span>{isOpen ? "Hide explanation" : `Why ${index === 0 ? "#1?" : `#${index + 1}?`}`}</span>
                <ChevronDownIcon className={`h-4 w-4 transition-transform ${isOpen ? "rotate-180" : ""}`} />
              </button>
              {isOpen && (
                <div className="mt-3 space-y-3 text-xs">
                  <div>
                    <p className="font-extrabold text-emerald-800">Supporting factors</p>
                    <ul className="mt-1 space-y-1 text-slate-700">
                      {cornea.strengths.map((item) => (
                        <li key={item} className="flex gap-1.5">
                          <CheckCircle2Icon className="h-3.5 w-3.5 shrink-0 text-emerald-600" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                  {cornea.concerns.length > 0 && (
                    <div>
                      <p className="font-extrabold text-amber-900">Why ranked lower</p>
                      <ul className="mt-1 space-y-1 text-slate-700">
                        {cornea.concerns.map((item) => (
                          <li key={item} className="flex gap-1.5">
                            <TriangleAlertIcon className="h-3.5 w-3.5 shrink-0 text-amber-600" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  <div className="border-t border-slate-200 pt-2">
                    <p className="font-extrabold text-slate-700">Ranking contribution</p>
                    {cornea.contributions.map((item) => (
                      <div key={item.label} className="mt-1 flex justify-between text-2xs">
                        <span>{item.label}</span>
                        <strong>{item.value}</strong>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {can("Recipient", "match") && role !== "Doctor" && (
                <Button variant="secondary" size="sm" className="mt-3 w-full justify-center" onClick={() => action(`${cornea.corneaId} proposed to Doctor`)}>
                  Propose this match
                </Button>
              )}
              {role === "Doctor" && can("Recipient", "approve") && (
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <Button variant="primary" size="sm" onClick={() => action(`${cornea.corneaId} approved`)}>
                    Approve
                  </Button>
                  <Button variant="secondary" size="sm" onClick={() => action(`${cornea.corneaId} sent for further review`)}>
                    Review
                  </Button>
                </div>
              )}
            </article>
          );
        })}
      </div>
      {compare && (
        <div className="mt-4 overflow-x-auto rounded-2xl border border-slate-200">
          <table className="w-full min-w-[640px] text-left text-xs">
            <thead className="bg-slate-50 text-2xs font-extrabold uppercase tracking-wider text-slate-500">
              <tr>
                <th className="p-3">Factor</th>
                {ranked.map((item, index) => (
                  <th key={item.corneaId} className="p-3">
                    #{index + 1} {item.corneaId}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {["score", "grade", "ecd", "cv", "hex", "diseaseScreen", "suitability"].map((field) => (
                <tr key={field}>
                  <th className="p-3 font-bold capitalize text-slate-700">{field === "diseaseScreen" ? "Disease status" : field}</th>
                  {ranked.map((item) => (
                    <td key={item.corneaId} className="p-3 font-semibold text-slate-900">
                      {String(item[field as keyof RankedCornea])}
                      {field === "score" ? "%" : ""}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 p-4">
        <p className="text-2xs font-extrabold uppercase tracking-wider text-amber-900">Decision handoff</p>
        <div className="mt-2 grid gap-2 text-xs sm:grid-cols-4">
          <span>
            <strong>1. Technician</strong>
            <br />
            Reviews and proposes
          </span>
          <span>
            <strong>2. Doctor</strong>
            <br />
            Reviews evidence
          </span>
          <span>
            <strong>3. Doctor</strong>
            <br />
            Approves, rejects or requests review
          </span>
          <span>
            <strong>4. Manager</strong>
            <br />
            Allocates approved cornea
          </span>
        </div>
      </div>
    </Panel>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-white p-2">
      <p className="text-[10px] font-bold text-slate-500">{label}</p>
      <p className="text-xs font-extrabold text-slate-900">{value}</p>
    </div>
  );
}
