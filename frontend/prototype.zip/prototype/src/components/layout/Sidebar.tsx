import React from 'react';
import { NavLink } from 'react-router-dom';
import { SparklesIcon } from 'lucide-react';
import { useSession } from '../../contexts/SessionContext';
import { navGroupsForRole } from '../../utils/permissions';
import { AccountMenu } from './AccountMenu';

const groupLinkClass = ({ isActive }: { isActive: boolean }) =>
  [
    'flex items-center gap-3 rounded-2xl px-3.5 py-2.5 text-xs font-bold leading-normal transition-all duration-150 ease-out',
    isActive
      ? 'bg-sky-100 text-sky-900 border border-sky-200 shadow-card font-extrabold'
      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 font-semibold'
  ].join(' ');

const childLinkClass = ({ isActive }: { isActive: boolean }) =>
  [
    'flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold leading-normal transition-all duration-150 ease-out',
    isActive
      ? 'font-bold text-sky-800 bg-sky-50 border border-sky-100'
      : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100/70 font-medium'
  ].join(' ');

export function Sidebar() {
  const { role } = useSession();
  const groups = role ? navGroupsForRole(role) : [];

  return (
    <nav
      aria-label="Primary Navigation"
      className="flex h-full w-64 shrink-0 flex-col border-r border-slate-200/80 bg-surface shadow-2xs">

      {/* Brand Header Card with Prominent Big Logo (Text Removed) */}
      <div className="flex items-center justify-center px-5 py-5 shrink-0">
        <img
          src="/new-logo.png"
          alt="National Eye Bank of Sri Lanka"
          className="h-16 w-auto max-w-full object-contain"
        />
      </div>

      {/* Grouped Navigation List with Generous Spacing */}
      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-6">
        <div>
          <div className="px-3 pb-3 text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
            Operations &amp; Intelligence
          </div>
          <ul className="space-y-3">
            {groups.map((group) => (
              <li key={group.id} className="space-y-1">
                <NavLink to={group.to} end={group.end} className={groupLinkClass}>
                  {({ isActive }) => (
                    <>
                      <group.icon
                        className={`h-4 w-4 shrink-0 transition-colors ${isActive ? 'text-sky-700' : 'text-slate-400'
                          }`}
                      />
                      <span className="min-w-0 flex-1 truncate">{group.label}</span>
                    </>
                  )}
                </NavLink>

                {/* Sub-item Navigation List */}
                {group.items && group.items.length > 1 && (
                  <ul className="ml-5 mt-2 space-y-1.5 border-l-2 border-sky-100 pl-3 mb-2">
                    {group.items.map((item) => (
                      <li key={item.to}>
                        <NavLink to={item.to} end={item.end} className={childLinkClass}>
                          {({ isActive }) => (
                            <>
                              <span className={`h-1.5 w-1.5 rounded-full shrink-0 ${isActive ? 'bg-sky-600' : 'bg-slate-300'}`} />
                              <span className="truncate">{item.label}</span>
                            </>
                          )}
                        </NavLink>
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            ))}
          </ul>
        </div>

        {/* Demo Telemetry Scope Badge */}
        <div className="mx-1 p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200/80 shadow-2xs mt-6">
          <div className="flex items-center gap-1.5 text-2xs font-extrabold text-amber-900">
            <SparklesIcon className="h-3.5 w-3.5 text-amber-600 shrink-0" />
            Active Role Scope
          </div>
          <p className="text-2xs text-amber-800 mt-1 leading-relaxed">
            Currently acting as <strong className="font-extrabold">{role}</strong>. Use <kbd className="px-1 py-0.5 rounded bg-amber-100 font-mono font-bold text-[10px]">⌘K</kbd> to switch.
          </p>
        </div>
      </div>

      {/* Account Footer Menu */}
      <AccountMenu />
    </nav>
  );
}