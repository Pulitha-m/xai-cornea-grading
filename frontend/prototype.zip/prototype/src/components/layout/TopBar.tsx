import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { BellIcon, BuildingIcon, LayoutGridIcon, PlusIcon, SearchIcon, SparklesIcon, CheckCircle2Icon } from "lucide-react";
import { useSession } from "../../contexts/SessionContext";
import { useBranch, type BranchFilter } from "../../contexts/BranchContext";
import { CommandPalette } from "../ui/CommandPalette";
import { Button } from "../ui/Button";

export function TopBar() {
  const { user } = useSession();
  const { activeBranch, setActiveBranch } = useBranch();
  const navigate = useNavigate();
  const [isCommandOpen, setIsCommandOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [hasUnread, setHasUnread] = useState(true);
  const notifRef = useRef<HTMLDivElement>(null);

  const dateString = new Date().toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
  });

  useEffect(() => {
    if (!showNotifications) return;
    const handleClick = (e: MouseEvent) => {
      if (!notifRef.current?.contains(e.target as Node)) setShowNotifications(false);
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [showNotifications]);

  const notifications = [
    {
      id: "N-1",
      title: "Cornea requires Doctor clinical review",
      caseId: "NEB-2026-00125",
      branch: "Colombo",
      time: "12m ago",
      level: "Urgent",
      read: false,
    },
    {
      id: "N-2",
      title: "New Specular Microscopy image uploaded",
      caseId: "NEB-2026-00124",
      branch: "Kandy",
      time: "45m ago",
      level: "Action",
      read: false,
    },
    {
      id: "N-3",
      title: "Inter-branch tissue transfer requested to Kandy",
      caseId: "NEB-2026-00122",
      branch: "Colombo",
      time: "2h ago",
      level: "Info",
      read: true,
    },
  ];

  return (
    <>
      <header className="flex h-16 shrink-0 items-center justify-between gap-4 border-b border-slate-200/80 bg-surface px-6 md:px-8">
        {/* Left Side: Branch Selector & Live Status */}
        <div className="flex items-center gap-3">
          <img src="/new-logo.png" alt="NEBSL Logo" className="h-8 w-auto object-contain rounded-md sm:hidden" />

          {/* Persistent Branch Selector */}
          <div className="flex items-center gap-2 rounded-2xl border border-sky-200 bg-sky-50/80 px-3 py-1.5 shadow-2xs">
            <BuildingIcon className="h-4 w-4 text-sky-700 shrink-0" />
            <span className="hidden sm:inline text-2xs font-extrabold uppercase tracking-wider text-sky-800">Branch:</span>
            <select value={activeBranch} onChange={(e) => setActiveBranch(e.target.value as BranchFilter)} className="bg-transparent text-xs font-extrabold text-slate-900 focus:outline-none cursor-pointer">
              {(user?.role === "Admin" || (user?.allowedBranches.length ?? 0) > 1) && <option value="All Branches">All Branches (National)</option>}
              {(user?.role === "Admin" ? ["Colombo", "Kandy", "Kurunegala"] : (user?.allowedBranches ?? [])).map((branch) => (
                <option key={branch} value={branch}>
                  {branch} Branch
                </option>
              ))}
            </select>
          </div>

          <span className="hidden lg:inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200/80 text-2xs font-extrabold">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            NEBSL Live Active
          </span>
        </div>

        {/* Right Side: Command Palette Search, Actions, Notifications & Avatar */}
        <div className="flex items-center gap-3">
          {/* Search Trigger Input Box with ⌘K Badge */}
          <button onClick={() => setIsCommandOpen(true)} className="flex h-10 items-center gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 text-xs font-medium text-slate-500 hover:bg-slate-100 hover:border-slate-300 transition-all w-44 sm:w-60 md:w-72">
            <SearchIcon className="h-4 w-4 text-slate-400 shrink-0" />
            <span className="truncate text-left flex-1 font-semibold">Search cases, tasks, donors...</span>
            <kbd className="hidden sm:inline-flex items-center gap-0.5 rounded-md bg-surface px-2 py-0.5 font-mono text-[10px] font-bold text-slate-600 border border-slate-200 shadow-2xs">⌘K</kbd>
          </button>

          {/* Grid Shortcut Button */}
          <button onClick={() => setIsCommandOpen(true)} className="hidden sm:flex h-10 w-10 items-center justify-center rounded-2xl border border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100 transition-colors" title="Open Command Center">
            <LayoutGridIcon className="h-4 w-4" />
          </button>

          {/* Notifications Dropdown Drawer */}
          <div ref={notifRef} className="relative">
            <button
              onClick={() => {
                setShowNotifications((v) => !v);
                setHasUnread(false);
              }}
              className="relative flex h-10 w-10 items-center justify-center rounded-2xl border border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100 transition-colors"
              title="Notifications"
            >
              <BellIcon className="h-4 w-4" />
              {hasUnread && <span className="absolute top-2 right-2 h-2.5 w-2.5 rounded-full bg-amber-500 ring-2 ring-surface animate-bounce" />}
            </button>

            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-3xl border border-slate-200 bg-surface shadow-bento p-4 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-3">
                  <div className="flex items-center gap-2">
                    <BellIcon className="h-4 w-4 text-sky-700" />
                    <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider">Clinical Notifications</h4>
                  </div>
                  <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-sky-100 text-sky-800">3 Active</span>
                </div>

                <div className="space-y-2.5">
                  {notifications.map((n) => (
                    <div
                      key={n.id}
                      onClick={() => {
                        setShowNotifications(false);
                        navigate(`/cases/${n.caseId}`);
                      }}
                      className="group p-3 rounded-2xl bg-slate-50/80 border border-slate-200/80 hover:bg-sky-50/80 hover:border-sky-200 transition-all cursor-pointer"
                    >
                      <div className="flex items-center justify-between text-2xs font-extrabold mb-1">
                        <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-200">{n.level}</span>
                        <span className="text-slate-400">{n.time}</span>
                      </div>
                      <p className="text-xs font-bold text-slate-900 group-hover:text-sky-900 transition-colors">{n.title}</p>
                      <div className="flex items-center justify-between text-[10px] text-slate-500 font-semibold mt-1.5">
                        <span>
                          Case: <strong className="text-slate-800">{n.caseId}</strong>
                        </span>
                        <span className="text-sky-700 font-bold">{n.branch} Branch</span>
                      </div>
                    </div>
                  ))}
                </div>

                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full mt-3 justify-center text-xs font-bold text-sky-800"
                  onClick={() => {
                    setShowNotifications(false);
                    navigate("/my-work");
                  }}
                >
                  View All Tasks in My Work →
                </Button>
              </div>
            )}
          </div>

          {/* + New Case Action Button */}
          <Button variant="primary" size="md" onClick={() => navigate("/cases/new")} className="hidden sm:inline-flex shadow-sm">
            <PlusIcon className="h-4 w-4" />
            New Case
          </Button>
        </div>
      </header>

      {/* Global Command Palette Dialog */}
      <CommandPalette isOpen={isCommandOpen} onClose={() => setIsCommandOpen(false)} />
    </>
  );
}
