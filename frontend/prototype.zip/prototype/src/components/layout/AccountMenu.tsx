import React, { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ChevronsUpDownIcon, LogOutIcon, SettingsIcon } from "lucide-react";
import { useSession } from "../../contexts/SessionContext";

export function AccountMenu() {
  const { user, role, signOut } = useSession();
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!open) return;
    const handleClick = (event: MouseEvent) => {
      if (!containerRef.current?.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open]);

  if (!user) return null;

  const handleSignOut = () => {
    setOpen(false);
    signOut();
    navigate("/login", { replace: true });
  };

  return (
    <div ref={containerRef} className="relative border-t border-slate-100 p-3 shrink-0">
      {open && (
        <div role="menu" aria-label="Account Menu" className="absolute bottom-full left-3 right-3 mb-2 overflow-hidden rounded-2xl border border-slate-200 bg-surface shadow-pop p-1.5 animate-in fade-in slide-in-from-bottom-2 duration-150 z-50">
          <Link role="menuitem" to="/settings" onClick={() => setOpen(false)} className="flex items-center gap-2.5 px-3 py-2.5 mt-1 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50 hover:text-slate-900 transition-colors">
            <SettingsIcon className="h-4 w-4 text-slate-400 shrink-0" />
            System Settings
          </Link>

          <button role="menuitem" type="button" onClick={handleSignOut} className="flex w-full items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold text-rose-600 hover:bg-rose-50 transition-colors">
            <LogOutIcon className="h-4 w-4 text-rose-500 shrink-0" />
            Sign out
          </button>
        </div>
      )}

      <button type="button" aria-expanded={open} aria-haspopup="menu" onClick={() => setOpen((v) => !v)} className="flex w-full items-center gap-3 rounded-2xl p-2 text-left hover:bg-slate-100/70 transition-colors">
        <img
          src={
            role === "Specialist"
              ? "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=100&auto=format&fit=crop&q=80"
              : role === "Admin"
                ? "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
                : "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=100&auto=format&fit=crop&q=80"
          }
          alt={user.name}
          className="h-9 w-9 rounded-full object-cover border border-sky-300 shadow-2xs shrink-0"
        />
        <div className="min-w-0 flex-1">
          <span className="block truncate text-xs font-bold leading-tight text-slate-900">{user.name}</span>
          <span className="block truncate text-2xs font-bold text-sky-700">{user.title}</span>
        </div>
        <ChevronsUpDownIcon className="h-4 w-4 text-slate-400 shrink-0" />
      </button>
    </div>
  );
}
