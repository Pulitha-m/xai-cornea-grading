import React from 'react';
import { FlaskConicalIcon } from 'lucide-react';

/**
 * Subtle, always-visible reminder that every case shown is fictional
 * demonstration data and that AI outputs are decision support only.
 */
export function PrototypeNotice({ compact = false }: {compact?: boolean;}) {
  return (
    <div
      className={`flex items-center gap-1.5 rounded border border-line-strong bg-sunken text-2xs text-ink-500 ${
      compact ? 'px-2 py-0.5' : 'px-2.5 py-1'}`
      }
      title="All cases and values in this system are fictional demonstration data.">
      
      <FlaskConicalIcon className="h-3 w-3 shrink-0 text-ink-400" aria-hidden="true" />
      <span>Prototype / Demonstration Data</span>
    </div>);

}