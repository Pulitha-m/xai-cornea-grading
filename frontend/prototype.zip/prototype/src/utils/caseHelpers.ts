import { MODULE_IDS, moduleRegistry } from '../data/moduleRegistry';
import type { DonorCase, ModuleResult, ModuleStatus } from '../types/case';

export function getResult(donorCase: DonorCase, moduleId: string): ModuleResult {
  return (
    donorCase.modules[moduleId] ?? {
      moduleId,
      status: 'Unavailable',
      lastRun: null,
      resultSummary: null,
      confidence: null,
      quality: null,
      outputs: [],
      explanation: {
        available: false,
        methods: [],
        note: 'This module has not written any result to the case.'
      },
      version: null,
      inputsUsed: [],
      missingInputs: [],
      statusNote: 'No result record exists for this module on this case.'
    });

}

/** Predicted grade from the grading module, or null when unavailable. */
export function predictedGrade(donorCase: DonorCase): string | null {
  const result = getResult(donorCase, MODULE_IDS.grade);
  if (result.status !== 'Completed' && result.status !== 'Needs Review') return null;
  const output = result.outputs.find((o) => o.label === 'Predicted Grade');
  return output?.value ?? null;
}

export function diseaseAssessment(donorCase: DonorCase): string | null {
  const result = getResult(donorCase, MODULE_IDS.disease);
  if (result.status === 'Not Run' || result.status === 'Unavailable') return null;
  return result.outputs.find((o) => o.label === 'Disease Assessment')?.value ?? null;
}

/** Aggregate analysis progress across all registered modules that apply. */
export function analysisProgress(donorCase: DonorCase): {
  completed: number;
  total: number;
  label: string;
  status: ModuleStatus | 'Partial';
} {
  const applicable = moduleRegistry.filter((m) => m.id !== MODULE_IDS.followUp);
  const results = applicable.map((m) => getResult(donorCase, m.id));
  const completed = results.filter((r) => r.status === 'Completed').length;
  const running = results.some((r) => r.status === 'Running');
  const needsReview = results.some((r) => r.status === 'Needs Review');

  let status: ModuleStatus | 'Partial' = 'Not Run';
  if (running) status = 'Running';else
  if (needsReview) status = 'Needs Review';else
  if (completed === applicable.length) status = 'Completed';else
  if (completed > 0) status = 'Partial';

  return {
    completed,
    total: applicable.length,
    label: `${completed}/${applicable.length} modules`,
    status
  };
}

export function requiresSpecialistReview(donorCase: DonorCase): boolean {
  if (donorCase.reviewStatus === 'Specialist Reviewed') return false;
  return moduleRegistry.some((m) => getResult(donorCase, m.id).status === 'Needs Review');
}

export function missingInformation(donorCase: DonorCase): string[] {
  const missing = new Set<string>();
  if (donorCase.image.uploadStatus === 'Not uploaded') missing.add('Endothelial image');
  if (!donorCase.clinical.referenceEcd) missing.add('Reference ECD measurement');
  if (donorCase.clinical.slitLampFindings === 'Not yet recorded')
  missing.add('Slit lamp clinical observations');
  if (donorCase.donor.serology === 'Pending') missing.add('Serology results');
  if (!donorCase.transplant.recipientRef) missing.add('Recipient information');
  moduleRegistry.forEach((m) => {
    getResult(donorCase, m.id).missingInputs.forEach((i) => missing.add(i));
  });
  return Array.from(missing);
}

export function nextCaseId(existing: string[]): string {
  const numbers = existing.
  map((id) => Number(id.split('-').pop())).
  filter((n) => !Number.isNaN(n)) as number[];
  const next = (numbers.length ? Math.max(...numbers) : 0) + 1;
  return `NEB-2026-${String(next).padStart(6, '0')}`;
}

export const GRADE_OPTIONS = ['A+', 'A', 'B'] as const;