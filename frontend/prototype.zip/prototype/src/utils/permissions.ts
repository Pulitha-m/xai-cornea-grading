import type { ComponentType } from "react";
import { ActivityIcon, BrainCircuitIcon, ClipboardListIcon, FileTextIcon, LayoutDashboardIcon, StethoscopeIcon, PackageIcon, UsersIcon, CheckSquareIcon, BuildingIcon, ShieldCheckIcon, TruckIcon } from "lucide-react";
import type { Role } from "../types/user";

export type Resource = "Donor" | "AI" | "Recipient" | "Transplant" | "FollowUp" | "Inventory" | "Task" | "Branch" | "User" | "Audit" | "Report";

export type Action = "view" | "create" | "edit" | "evaluate" | "allocate" | "transfer" | "run" | "review" | "match" | "schedule" | "approve" | "reject" | "signoff" | "escalate" | "complete" | "assign" | "reassign" | "deactivate" | "generate" | "export" | "manage" | "update";

const ROLE_PERMISSIONS: Record<Role, Partial<Record<Resource, Action[]>>> = {
  Admin: {
    Donor: ["view", "create", "edit", "evaluate", "allocate", "transfer"],
    AI: ["view", "run", "review"],
    Recipient: ["view", "create", "edit", "match"],
    Transplant: ["view", "schedule", "approve", "complete"],
    FollowUp: ["view", "create", "edit"],
    Inventory: ["view", "update", "transfer"],
    Task: ["view", "create", "assign", "update", "complete", "reassign"],
    Branch: ["view", "create", "edit", "manage"],
    User: ["view", "create", "edit", "deactivate"],
    Audit: ["view"],
    Report: ["view", "generate", "export"],
  },
  Manager: {
    Donor: ["view", "create", "edit", "allocate", "transfer"],
    AI: ["view"],
    Recipient: ["view", "create", "edit", "match"],
    Transplant: ["view", "schedule"],
    FollowUp: ["view"],
    Inventory: ["view", "update", "transfer"],
    Task: ["view", "create", "assign", "update", "complete", "reassign"],
    Branch: ["view"],
    User: ["view"],
    Audit: ["view"],
    Report: ["view", "generate"],
  },
  Doctor: {
    Donor: ["view", "evaluate"],
    AI: ["view", "run", "review"],
    Recipient: ["view", "edit", "match", "review", "approve", "reject", "signoff"],
    Transplant: ["view", "approve", "complete"],
    FollowUp: ["view", "create", "edit", "review", "signoff"],
    Inventory: ["view"],
    Task: ["view", "update", "complete"],
    Branch: ["view"],
    User: ["view"],
    Audit: ["view"],
    Report: ["view"],
  },
  Nurse: {
    Donor: ["view", "create", "edit"],
    AI: ["view", "run"],
    Recipient: ["view", "match"],
    Transplant: ["view", "schedule"],
    FollowUp: ["view", "create", "edit", "escalate"],
    Inventory: ["view", "update"],
    Task: ["view", "update", "complete"],
    Branch: ["view"],
    User: ["view"],
    Audit: ["view"],
    Report: ["view"],
  },
  Attendant: {
    Donor: ["view"],
    AI: [],
    Recipient: [],
    Transplant: [],
    FollowUp: [],
    Inventory: ["view", "update"],
    Task: ["view", "update", "complete"],
    Branch: ["view"],
    User: [],
    Audit: [],
    Report: [],
  },
};

export function hasPermission(role: Role | null | undefined, resource: Resource, action: Action): boolean {
  if (!role) return false;
  const allowed = ROLE_PERMISSIONS[role]?.[resource];
  return allowed ? allowed.includes(action) : false;
}

export interface NavChild {
  to: string;
  label: string;
  end?: boolean;
}

export interface NavGroup {
  id: string;
  label: string;
  to: string;
  icon: ComponentType<{ className?: string }>;
  end?: boolean;
  items?: NavChild[];
}

export function navGroupsForRole(role: Role): NavGroup[] {
  switch (role) {
    case "Admin":
      return [
        { id: "dashboard", label: "Dashboard", to: "/", icon: LayoutDashboardIcon, end: true },
        { id: "my-work", label: "My Work", to: "/my-work", icon: CheckSquareIcon },
        { id: "branches", label: "Branches", to: "/admin/branches", icon: BuildingIcon },
        { id: "users", label: "Users & Staff", to: "/admin/users", icon: UsersIcon },
        {
          id: "cases",
          label: "Donor Cases",
          to: "/cases",
          icon: ClipboardListIcon,
          items: [{ to: "/cases", label: "All donor cases", end: true }],
        },
        { id: "inventory", label: "Inventory & Transfers", to: "/inventory", icon: PackageIcon },
        { id: "recipients", label: "Recipients & Matching", to: "/recipients", icon: UsersIcon },
        { id: "post-transplant", label: "Post-Transplant", to: "/post-transplant", icon: ActivityIcon },
        { id: "audit", label: "System Audit Logs", to: "/audit", icon: ShieldCheckIcon },
        { id: "reports", label: "Global Reports", to: "/reports", icon: FileTextIcon },
      ];

    case "Manager":
      return [
        { id: "dashboard", label: "Branch Dashboard", to: "/", icon: LayoutDashboardIcon, end: true },
        { id: "my-work", label: "My Work & Tasks", to: "/my-work", icon: CheckSquareIcon },
        {
          id: "cases",
          label: "Donor Cases",
          to: "/cases",
          icon: ClipboardListIcon,
          items: [{ to: "/cases", label: "All donor cases", end: true }],
        },
        { id: "inventory", label: "Tissue Inventory", to: "/inventory", icon: PackageIcon },
        { id: "recipients", label: "Recipients Waiting List", to: "/recipients", icon: UsersIcon },
        { id: "post-transplant", label: "Transplant Monitoring", to: "/post-transplant", icon: ActivityIcon },
        { id: "reports", label: "Branch Reports", to: "/reports", icon: FileTextIcon },
      ];

    case "Doctor":
      return [
        { id: "dashboard", label: "Clinical Dashboard", to: "/", icon: LayoutDashboardIcon, end: true },
        { id: "my-work", label: "My Work Queue", to: "/my-work", icon: CheckSquareIcon },
        {
          id: "cases",
          label: "Donor Corneas",
          to: "/cases",
          icon: ClipboardListIcon,
          items: [{ to: "/cases", label: "All donor cases", end: true }],
        },
        {
          id: "analysis",
          label: "AI Intelligence",
          to: "/analysis",
          icon: BrainCircuitIcon,
          items: [
            { to: "/analysis", label: "Module workspace" },
            { to: "/assessment", label: "Corneal assessment" },
          ],
        },
        { id: "recipients", label: "Recipient Matching", to: "/recipients", icon: StethoscopeIcon },
        { id: "post-transplant", label: "Post-Transplant Follow-up", to: "/post-transplant", icon: ActivityIcon },
        { id: "reports", label: "Clinical Reports", to: "/reports", icon: FileTextIcon },
      ];

    case "Nurse":
      return [
        { id: "dashboard", label: "Technician Dashboard", to: "/", icon: LayoutDashboardIcon, end: true },
        { id: "my-work", label: "My Operational Tasks", to: "/my-work", icon: CheckSquareIcon },
        {
          id: "cases",
          label: "Donor Intake",
          to: "/cases",
          icon: ClipboardListIcon,
          items: [
            { to: "/cases", label: "All donor cases", end: true },
            { to: "/cases/new", label: "New donor intake" },
          ],
        },
        {
          id: "analysis",
          label: "Imaging & Evaluation",
          to: "/analysis",
          icon: BrainCircuitIcon,
          items: [
            { to: "/analysis", label: "Module workspace" },
            { to: "/assessment", label: "Corneal assessment" },
          ],
        },
        { id: "inventory", label: "Storage Inventory", to: "/inventory", icon: PackageIcon },
        { id: "recipients", label: "Recipient Matching", to: "/recipients", icon: StethoscopeIcon },
        { id: "post-transplant", label: "Post-Transplant Follow-up", to: "/post-transplant", icon: ActivityIcon },
      ];

    case "Attendant":
      return [
        { id: "dashboard", label: "Attendant Dashboard", to: "/", icon: LayoutDashboardIcon, end: true },
        { id: "my-work", label: "My Tasks", to: "/my-work", icon: CheckSquareIcon },
        { id: "inventory", label: "Storage & Transfers", to: "/inventory", icon: PackageIcon },
      ];

    default:
      return [];
  }
}
