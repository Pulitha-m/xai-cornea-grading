import type { CorneaStatus, DonorStatus } from "../types/case";
import type { Role } from "../types/user";

const DONOR_TRANSITIONS: Record<DonorStatus, DonorStatus | null> = {
  Registered: "Screened",
  Screened: "Approved",
  Approved: "Tissue Collected",
  "Tissue Collected": "Evaluation Pending",
  "Evaluation Pending": "Evaluated",
  Evaluated: "Available",
  Available: "Allocated",
  Allocated: "Transplanted",
  Transplanted: "Closed",
  Closed: null,
};

const CORNEA_TRANSITIONS: Record<CorneaStatus, CorneaStatus | null> = {
  Collected: "Processing",
  Processing: "Image Pending",
  "Image Pending": "Image Uploaded",
  "Image Uploaded": "AI Analysis",
  "AI Analysis": "Expert Review",
  "Expert Review": "Suitable",
  Suitable: "Available",
  Marginal: "Available",
  "Not Suitable": null,
  Available: "Reserved",
  Reserved: "Allocated",
  Allocated: "Transplanted",
  Transplanted: "Follow-up",
  "Follow-up": "Completed",
  Completed: null,
};

const ROLE_TRANSITIONS: Record<Role, string[]> = {
  Admin: ["*"],
  Manager: ["Available->Allocated", "Reserved->Allocated"],
  Doctor: ["AI Analysis->Expert Review", "Expert Review->Suitable", "Expert Review->Marginal", "Expert Review->Not Suitable", "Allocated->Transplanted"],
  Nurse: ["Registered->Screened", "Approved->Tissue Collected", "Tissue Collected->Evaluation Pending", "Processing->Image Pending", "Image Pending->Image Uploaded"],
  Attendant: [],
};

function canPerform(role: Role, from: string, to: string): boolean {
  return ROLE_TRANSITIONS[role].includes("*") || ROLE_TRANSITIONS[role].includes(`${from}->${to}`);
}

export function nextDonorStatus(status: DonorStatus): DonorStatus | null {
  return DONOR_TRANSITIONS[status];
}

export function nextCorneaStatus(status: CorneaStatus): CorneaStatus | null {
  return CORNEA_TRANSITIONS[status];
}

export function canTransitionDonor(role: Role, from: DonorStatus, to: DonorStatus): boolean {
  return nextDonorStatus(from) === to && canPerform(role, from, to);
}

export function canTransitionCornea(role: Role, from: CorneaStatus, to: CorneaStatus): boolean {
  return nextCorneaStatus(from) === to && canPerform(role, from, to);
}
