import { MODULE_IDS } from './moduleRegistry';
import type {
  AuditEntry,
  DonorCase,
  FollowUpPoint,
  ModuleResult } from
'../types/case';

/**
 * DEMONSTRATION FIXTURES — clearly fictional prototype cases.
 * These are not National Eye Bank records and no value here is a model output.
 * Every completed module result is tagged with the `demo-fixture` version.
 */

export const ENDOTHELIAL_IMAGES = {
  regular: "/2f3972fb-df4e-4a6b-8317-56066d847df8.jpg",

  moderate: "/0e3bda50-b21c-45d9-97b8-c8b3cdf6aae4.jpg",

  degraded: "/d828916d-acdd-4ef0-bbb4-3f73aa55e0ee.jpg",

  sparse: "/3a3b1033-322b-4393-aa08-6f1c06f783f9.jpg"

};

const DEMO_VERSION = 'demo-fixture';

export function emptyModuleResult(
moduleId: string,
overrides: Partial<ModuleResult> = {})
: ModuleResult {
  return {
    moduleId,
    status: 'Not Run',
    lastRun: null,
    resultSummary: null,
    confidence: null,
    quality: null,
    outputs: [],
    explanation: {
      available: false,
      methods: [],
      note: 'No analysis has been run for this case.'
    },
    version: null,
    inputsUsed: [],
    missingInputs: [],
    ...overrides
  };
}

const NOT_CONNECTED_NOTE =
'Analysis not yet connected — no model endpoint is registered for this module in the prototype.';

const EXPLANATION_PENDING = (methods: string[]) => ({
  available: false,
  methods,
  note:
  'Explanation artefacts are produced by the research module. None are available in this prototype, so no explanation is shown.'
});

/* ---------- NEB-2026-000123 ---------- */

const case123Modules: Record<string, ModuleResult> = {
  [MODULE_IDS.cellular]: {
    moduleId: MODULE_IDS.cellular,
    status: 'Completed',
    lastRun: '2026-08-17T10:30:00',
    resultSummary: 'Cellular analysis complete — quality acceptable',
    confidence: null,
    quality: 'Acceptable',
    version: DEMO_VERSION,
    inputsUsed: ['Endothelial image (NEB-000123-EN-01.tif)', 'Capture metadata'],
    missingInputs: [],
    outputs: [
    { label: 'ECD', value: '2,684', unit: 'cells/mm²', provenance: 'AI Analysis', reference: 'Eye-bank reference ≥ 2,000' },
    { label: 'CV', value: '31', unit: '%', provenance: 'AI Analysis', reference: 'Reference ≤ 40%' },
    { label: 'HEX', value: '64', unit: '%', provenance: 'AI Analysis', reference: 'Reference ≥ 55%' },
    { label: 'Mean Cell Area', value: '372', unit: 'µm²', provenance: 'AI Analysis' },
    { label: 'Compactness', value: '0.86', provenance: 'AI Analysis' },
    { label: 'Analysis Quality', value: 'Acceptable', provenance: 'AI Analysis', note: 'ROI covered 78% of usable frame' }],

    explanation: EXPLANATION_PENDING(['ROI overlay', 'Cell detection overlay', 'Per-cell measurements'])
  },
  [MODULE_IDS.grade]: {
    moduleId: MODULE_IDS.grade,
    status: 'Completed',
    lastRun: '2026-08-17T10:34:00',
    resultSummary: 'Predicted grade A',
    confidence: 0.81,
    quality: null,
    version: DEMO_VERSION,
    inputsUsed: ['Donor information', 'Clinical observations', 'Endothelial image', 'Cellular biomarkers'],
    missingInputs: [],
    outputs: [
    { label: 'Predicted Grade', value: 'A', provenance: 'AI Prediction' },
    { label: 'Confidence', value: '0.81', provenance: 'AI Prediction' },
    { label: 'Input modalities', value: 'Tabular + image + biomarkers', provenance: 'AI Prediction' },
    { label: 'Explanation status', value: 'Not generated', provenance: 'AI Prediction' }],

    explanation: EXPLANATION_PENDING(['SHAP', 'Grad-CAM', 'Feature importance', 'Image explanation'])
  },
  [MODULE_IDS.disease]: {
    moduleId: MODULE_IDS.disease,
    status: 'Needs Review',
    lastRun: '2026-08-17T10:36:00',
    resultSummary: 'Endothelial dystrophy indicators — specialist review requested',
    confidence: 0.62,
    quality: 'Acceptable',
    version: DEMO_VERSION,
    inputsUsed: ['Endothelial image', 'Clinical observations'],
    missingInputs: ['Donor ophthalmic history'],
    statusNote:
    'Model confidence below the review threshold (0.75). Flagged for specialist review rather than reported as a finding.',
    outputs: [
    { label: 'Disease Assessment', value: 'Endothelial dystrophy indicators', provenance: 'AI Prediction' },
    { label: 'Severity', value: 'Mild', provenance: 'AI Prediction' },
    { label: 'Corneal Health Index (CHI)', value: '71 / 100', provenance: 'AI Prediction' },
    { label: 'Explanation', value: null, provenance: 'AI Prediction', note: 'No explanation artefact available' }],

    explanation: EXPLANATION_PENDING(['Region attribution', 'Indicator breakdown'])
  },
  [MODULE_IDS.decision]: {
    moduleId: MODULE_IDS.decision,
    status: 'Needs Review',
    lastRun: '2026-08-17T10:41:00',
    resultSummary: 'Evidence consolidated — pending specialist review',
    confidence: null,
    quality: null,
    version: DEMO_VERSION,
    inputsUsed: ['Donor information', 'Clinical observations', 'Cellular biomarkers', 'Grade prediction', 'Disease assessment'],
    missingInputs: ['Recipient information', 'Donor ophthalmic history'],
    outputs: [
    { label: 'Evidence items', value: '5 of 6 available', provenance: 'AI Analysis' },
    { label: 'Potential concerns', value: '2 raised', provenance: 'AI Analysis' },
    { label: 'Specialist review', value: 'Required', provenance: 'AI Analysis' }],

    explanation: EXPLANATION_PENDING(['Evidence traceability', 'Concern attribution'])
  },
  [MODULE_IDS.followUp]: emptyModuleResult(MODULE_IDS.followUp, {
    statusNote: 'Case has not proceeded to transplantation. Follow-up monitoring is not applicable yet.'
  })
};

/* ---------- NEB-2026-000124 ---------- */

const case124Modules: Record<string, ModuleResult> = {
  [MODULE_IDS.cellular]: {
    moduleId: MODULE_IDS.cellular,
    status: 'Needs Review',
    lastRun: '2026-08-16T14:12:00',
    resultSummary: 'Image quality insufficient for reliable measurement',
    confidence: null,
    quality: 'Insufficient',
    version: DEMO_VERSION,
    inputsUsed: ['Endothelial image (NEB-000124-EN-01.tif)'],
    missingInputs: ['Re-capture with even illumination'],
    statusNote:
    'Usable region of interest below threshold. Measurements are withheld rather than reported at low reliability.',
    outputs: [
    { label: 'ECD', value: null, unit: 'cells/mm²', provenance: 'AI Analysis', note: 'Withheld — insufficient image quality' },
    { label: 'CV', value: null, unit: '%', provenance: 'AI Analysis', note: 'Withheld' },
    { label: 'HEX', value: null, unit: '%', provenance: 'AI Analysis', note: 'Withheld' },
    { label: 'Mean Cell Area', value: null, unit: 'µm²', provenance: 'AI Analysis', note: 'Withheld' },
    { label: 'Compactness', value: null, provenance: 'AI Analysis', note: 'Withheld' },
    { label: 'Analysis Quality', value: 'Insufficient', provenance: 'AI Analysis' }],

    explanation: EXPLANATION_PENDING(['ROI overlay', 'Cell detection overlay'])
  },
  [MODULE_IDS.grade]: {
    moduleId: MODULE_IDS.grade,
    status: 'Completed',
    lastRun: '2026-08-16T14:20:00',
    resultSummary: 'Predicted grade B — low confidence',
    confidence: 0.58,
    quality: null,
    version: DEMO_VERSION,
    inputsUsed: ['Donor information', 'Clinical observations'],
    missingInputs: ['Cellular biomarkers', 'Usable endothelial image'],
    statusNote:
    'Prediction produced from tabular inputs only. Image and biomarker modalities were unavailable.',
    outputs: [
    { label: 'Predicted Grade', value: 'B', provenance: 'AI Prediction' },
    { label: 'Confidence', value: '0.58', provenance: 'AI Prediction' },
    { label: 'Input modalities', value: 'Tabular only', provenance: 'AI Prediction' },
    { label: 'Explanation status', value: 'Not generated', provenance: 'AI Prediction' }],

    explanation: EXPLANATION_PENDING(['SHAP', 'Feature importance'])
  },
  [MODULE_IDS.disease]: emptyModuleResult(MODULE_IDS.disease, {
    statusNote: 'Not analysed. A usable endothelial image is required before this module can run.'
  }),
  [MODULE_IDS.decision]: emptyModuleResult(MODULE_IDS.decision),
  [MODULE_IDS.followUp]: emptyModuleResult(MODULE_IDS.followUp, {
    statusNote: 'Case has not proceeded to transplantation.'
  })
};

/* ---------- NEB-2026-000125 (transplanted, follow-up active) ---------- */

const followUp125: FollowUpPoint[] = [
{ label: 'Baseline', date: '2026-02-14', ecd: 2740, cv: 29, hex: 68, recorded: true },
{ label: '1 month', date: '2026-03-16', ecd: 2510, cv: 32, hex: 65, recorded: true },
{ label: '3 months', date: '2026-05-14', ecd: 2320, cv: 34, hex: 62, recorded: true },
{ label: '6 months', date: '2026-08-12', ecd: 2185, cv: 36, hex: 60, recorded: true },
{ label: '1 year', date: null, ecd: null, cv: null, hex: null, recorded: false }];


const case125Modules: Record<string, ModuleResult> = {
  [MODULE_IDS.cellular]: {
    moduleId: MODULE_IDS.cellular,
    status: 'Completed',
    lastRun: '2026-02-10T09:05:00',
    resultSummary: 'Cellular analysis complete — quality good',
    confidence: null,
    quality: 'Good',
    version: DEMO_VERSION,
    inputsUsed: ['Endothelial image (NEB-000125-EN-01.tif)', 'Capture metadata'],
    missingInputs: [],
    outputs: [
    { label: 'ECD', value: '2,740', unit: 'cells/mm²', provenance: 'AI Analysis', reference: 'Eye-bank reference ≥ 2,000' },
    { label: 'CV', value: '29', unit: '%', provenance: 'AI Analysis', reference: 'Reference ≤ 40%' },
    { label: 'HEX', value: '68', unit: '%', provenance: 'AI Analysis', reference: 'Reference ≥ 55%' },
    { label: 'Mean Cell Area', value: '365', unit: 'µm²', provenance: 'AI Analysis' },
    { label: 'Compactness', value: '0.89', provenance: 'AI Analysis' },
    { label: 'Analysis Quality', value: 'Good', provenance: 'AI Analysis' }],

    explanation: EXPLANATION_PENDING(['ROI overlay', 'Cell detection overlay', 'Per-cell measurements'])
  },
  [MODULE_IDS.grade]: {
    moduleId: MODULE_IDS.grade,
    status: 'Completed',
    lastRun: '2026-02-10T09:11:00',
    resultSummary: 'Predicted grade A+',
    confidence: 0.9,
    quality: null,
    version: DEMO_VERSION,
    inputsUsed: ['Donor information', 'Clinical observations', 'Endothelial image', 'Cellular biomarkers'],
    missingInputs: [],
    outputs: [
    { label: 'Predicted Grade', value: 'A+', provenance: 'AI Prediction' },
    { label: 'Confidence', value: '0.90', provenance: 'AI Prediction' },
    { label: 'Input modalities', value: 'Tabular + image + biomarkers', provenance: 'AI Prediction' },
    { label: 'Explanation status', value: 'Not generated', provenance: 'AI Prediction' }],

    explanation: EXPLANATION_PENDING(['SHAP', 'Grad-CAM', 'Feature importance', 'Image explanation'])
  },
  [MODULE_IDS.disease]: {
    moduleId: MODULE_IDS.disease,
    status: 'Completed',
    lastRun: '2026-02-10T09:14:00',
    resultSummary: 'No disease indicators detected',
    confidence: 0.88,
    quality: 'Good',
    version: DEMO_VERSION,
    inputsUsed: ['Endothelial image', 'Clinical observations', 'Donor history'],
    missingInputs: [],
    outputs: [
    { label: 'Disease Assessment', value: 'No disease indicators detected', provenance: 'AI Prediction' },
    { label: 'Severity', value: 'None', provenance: 'AI Prediction' },
    { label: 'Corneal Health Index (CHI)', value: '92 / 100', provenance: 'AI Prediction' },
    { label: 'Explanation', value: null, provenance: 'AI Prediction', note: 'No explanation artefact available' }],

    explanation: EXPLANATION_PENDING(['Region attribution', 'Indicator breakdown'])
  },
  [MODULE_IDS.decision]: {
    moduleId: MODULE_IDS.decision,
    status: 'Completed',
    lastRun: '2026-02-11T08:20:00',
    resultSummary: 'Evidence complete — specialist decision recorded',
    confidence: null,
    quality: null,
    version: DEMO_VERSION,
    inputsUsed: ['Donor information', 'Clinical observations', 'Cellular biomarkers', 'Grade prediction', 'Disease assessment', 'Recipient information'],
    missingInputs: [],
    outputs: [
    { label: 'Evidence items', value: '6 of 6 available', provenance: 'AI Analysis' },
    { label: 'Potential concerns', value: 'None raised', provenance: 'AI Analysis' },
    { label: 'Specialist review', value: 'Completed', provenance: 'Specialist Assessment' }],

    explanation: EXPLANATION_PENDING(['Evidence traceability'])
  },
  [MODULE_IDS.followUp]: {
    moduleId: MODULE_IDS.followUp,
    status: 'Completed',
    lastRun: '2026-08-13T11:02:00',
    resultSummary: 'Trajectory within expected range at 6 months',
    confidence: null,
    quality: 'Monitoring active',
    version: DEMO_VERSION,
    inputsUsed: ['Baseline', '1 month', '3 months', '6 months measurements'],
    missingInputs: ['1 year measurements'],
    outputs: [
    { label: 'Trajectory Status', value: 'Within expected range', provenance: 'AI Analysis' },
    { label: 'Anomaly Status', value: 'No anomaly flagged', provenance: 'AI Analysis' },
    { label: 'Cumulative ECD change', value: '−20.3', unit: '%', provenance: 'Reference Measurement', reference: 'Baseline 2,740 → 2,185 cells/mm²' }],

    explanation: EXPLANATION_PENDING(['Trajectory comparison', 'Deviation attribution'])
  }
};

/* ---------- NEB-2026-000127 (running / unavailable states) ---------- */

const case127Modules: Record<string, ModuleResult> = {
  [MODULE_IDS.cellular]: emptyModuleResult(MODULE_IDS.cellular, {
    status: 'Running',
    lastRun: '2026-08-17T11:48:00',
    resultSummary: 'Analysis in progress',
    inputsUsed: ['Endothelial image (NEB-000127-EN-01.tif)'],
    statusNote: 'Queued at 11:48. Results will attach to this case when the run finishes.',
    explanation: {
      available: false,
      methods: ['ROI overlay', 'Cell detection overlay'],
      note: 'Explanation artefacts are not available while a run is in progress.'
    }
  }),
  [MODULE_IDS.grade]: emptyModuleResult(MODULE_IDS.grade, {
    missingInputs: ['Cellular biomarkers (optional)'],
    statusNote:
    'Not run. This module does not require any other module to complete first — it can run on the donor, clinical and image inputs already recorded.'
  }),
  [MODULE_IDS.disease]: emptyModuleResult(MODULE_IDS.disease, {
    status: 'Unavailable',
    statusNote: NOT_CONNECTED_NOTE,
    explanation: {
      available: false,
      methods: ['Region attribution', 'Indicator breakdown'],
      note: 'Module endpoint unavailable. No explanation can be produced.'
    }
  }),
  [MODULE_IDS.decision]: emptyModuleResult(MODULE_IDS.decision, {
    missingInputs: ['Grade prediction', 'Disease assessment', 'Cellular biomarkers'],
    statusNote:
    'Not run. Decision support will consolidate whatever evidence is available and list the rest as missing information.'
  }),
  [MODULE_IDS.followUp]: emptyModuleResult(MODULE_IDS.followUp, {
    statusNote: 'Case has not proceeded to transplantation.'
  })
};

/* ---------- NEB-2026-000128 (withheld from allocation) ---------- */

const case128Modules: Record<string, ModuleResult> = {
  [MODULE_IDS.cellular]: {
    moduleId: MODULE_IDS.cellular,
    status: 'Completed',
    lastRun: '2026-08-12T15:41:00',
    resultSummary: 'Reduced cell density measured',
    confidence: null,
    quality: 'Acceptable',
    version: DEMO_VERSION,
    inputsUsed: ['Endothelial image (NEB-000128-EN-01.tif)', 'Capture metadata'],
    missingInputs: [],
    outputs: [
    { label: 'ECD', value: '1,845', unit: 'cells/mm²', provenance: 'AI Analysis', reference: 'Eye-bank reference ≥ 2,000' },
    { label: 'CV', value: '43', unit: '%', provenance: 'AI Analysis', reference: 'Reference ≤ 40%' },
    { label: 'HEX', value: '51', unit: '%', provenance: 'AI Analysis', reference: 'Reference ≥ 55%' },
    { label: 'Mean Cell Area', value: '542', unit: 'µm²', provenance: 'AI Analysis' },
    { label: 'Compactness', value: '0.74', provenance: 'AI Analysis' },
    { label: 'Analysis Quality', value: 'Acceptable', provenance: 'AI Analysis' }],

    explanation: EXPLANATION_PENDING(['ROI overlay', 'Cell detection overlay', 'Per-cell measurements'])
  },
  [MODULE_IDS.grade]: {
    moduleId: MODULE_IDS.grade,
    status: 'Completed',
    lastRun: '2026-08-12T15:45:00',
    resultSummary: 'Predicted grade B',
    confidence: 0.84,
    quality: null,
    version: DEMO_VERSION,
    inputsUsed: ['Donor information', 'Clinical observations', 'Endothelial image', 'Cellular biomarkers'],
    missingInputs: [],
    outputs: [
    { label: 'Predicted Grade', value: 'B', provenance: 'AI Prediction' },
    { label: 'Confidence', value: '0.84', provenance: 'AI Prediction' },
    { label: 'Input modalities', value: 'Tabular + image + biomarkers', provenance: 'AI Prediction' },
    { label: 'Explanation status', value: 'Not generated', provenance: 'AI Prediction' }],

    explanation: EXPLANATION_PENDING(['SHAP', 'Grad-CAM', 'Feature importance', 'Image explanation'])
  },
  [MODULE_IDS.disease]: {
    moduleId: MODULE_IDS.disease,
    status: 'Completed',
    lastRun: '2026-08-12T15:48:00',
    resultSummary: 'Corneal oedema indicators — moderate',
    confidence: 0.79,
    quality: 'Acceptable',
    version: DEMO_VERSION,
    inputsUsed: ['Endothelial image', 'Clinical observations', 'Donor history'],
    missingInputs: [],
    outputs: [
    { label: 'Disease Assessment', value: 'Corneal oedema', provenance: 'AI Prediction' },
    { label: 'Severity', value: 'Moderate', provenance: 'AI Prediction' },
    { label: 'Corneal Health Index (CHI)', value: '48 / 100', provenance: 'AI Prediction' },
    { label: 'Explanation', value: null, provenance: 'AI Prediction', note: 'No explanation artefact available' }],

    explanation: EXPLANATION_PENDING(['Region attribution', 'Indicator breakdown'])
  },
  [MODULE_IDS.decision]: {
    moduleId: MODULE_IDS.decision,
    status: 'Completed',
    lastRun: '2026-08-13T09:02:00',
    resultSummary: 'Concerns raised — specialist decision recorded',
    confidence: null,
    quality: null,
    version: DEMO_VERSION,
    inputsUsed: ['Donor information', 'Clinical observations', 'Cellular biomarkers', 'Grade prediction', 'Disease assessment'],
    missingInputs: ['Recipient information'],
    outputs: [
    { label: 'Evidence items', value: '5 of 6 available', provenance: 'AI Analysis' },
    { label: 'Potential concerns', value: '3 raised', provenance: 'AI Analysis' },
    { label: 'Specialist review', value: 'Completed', provenance: 'Specialist Assessment' }],

    explanation: EXPLANATION_PENDING(['Evidence traceability', 'Concern attribution'])
  },
  [MODULE_IDS.followUp]: emptyModuleResult(MODULE_IDS.followUp, {
    statusNote: 'Case was withheld from allocation. Follow-up monitoring is not applicable.'
  })
};

const emptyFollowUp = (): FollowUpPoint[] => [
{ label: 'Baseline', date: null, ecd: null, cv: null, hex: null, recorded: false },
{ label: '1 month', date: null, ecd: null, cv: null, hex: null, recorded: false },
{ label: '3 months', date: null, ecd: null, cv: null, hex: null, recorded: false },
{ label: '6 months', date: null, ecd: null, cv: null, hex: null, recorded: false },
{ label: '1 year', date: null, ecd: null, cv: null, hex: null, recorded: false }];


export const demoCases: DonorCase[] = [
{
  caseId: 'NEB-2026-000123',
  donor: {
    donorId: 'DNR-2026-0451',
    age: 54,
    sex: 'Male',
    collectionDate: '2026-08-16',
    eye: 'Right (OD)',
    causeOfDeath: 'Myocardial infarction',
    deathToPreservationHours: 9.5,
    serology: 'Non-reactive (HIV, HBV, HCV, Syphilis)',
    relevantHistory: 'No known ocular surgery. Type 2 diabetes, 6 years, oral medication.'
  },
  clinical: {
    slitLampFindings: 'Clear cornea, no infiltrates. Fine peripheral striae.',
    epithelialStatus: 'Intact, mild punctate staining inferiorly',
    stromalClarity: 'Clear',
    endothelialFolds: 'Mild central folds',
    arcusSenilis: 'Peripheral, 1.0 mm',
    storageMedium: 'Optisol-GS',
    storageTemperatureC: 4,
    preservationDate: '2026-08-16',
    referenceEcd: 2700,
    observedBy: 'K. Fernando (Technician)',
    observationNotes: 'Tissue handled within protocol window. No stromal oedema noted at intake.'
  },
  image: {
    fileName: 'NEB-000123-EN-01.tif',
    uploadedAt: '2026-08-17T10:22:00',
    uploadStatus: 'Uploaded',
    qualityLabel: 'Acceptable',
    qualityNote: 'Placeholder quality label — automated image quality scoring is not connected.',
    previewUrl: ENDOTHELIAL_IMAGES.regular,
    magnification: '×200 specular',
    captureDevice: 'Specular microscope (bench unit 2)'
  },
  modules: case123Modules,
  reviewStatus: 'Pending Review',
  assignedReviewer: 'Dr. A. Perera',
  lastUpdated: '2026-08-17T10:41:00',
  createdBy: 'K. Fernando (Technician)',
  createdAt: '2026-08-17T09:58:00',
  transplant: {
    intent: 'Not allocated',
    recipientRef: null,
    procedure: null,
    surgeryDate: null,
    surgeon: null
  },
  followUp: emptyFollowUp(),
  specialistDecision: null,
  notes: [
  {
    id: 'n-123-1',
    author: 'K. Fernando (Technician)',
    createdAt: '2026-08-17T10:05:00',
    body: 'Second specular capture attempted; first frame discarded due to reflection artefact.'
  }]

},
{
  caseId: 'NEB-2026-000124',
  donor: {
    donorId: 'DNR-2026-0452',
    age: 67,
    sex: 'Female',
    collectionDate: '2026-08-15',
    eye: 'Left (OS)',
    causeOfDeath: 'Cerebrovascular accident',
    deathToPreservationHours: 14,
    serology: 'Non-reactive (HIV, HBV, HCV, Syphilis)',
    relevantHistory: 'Cataract surgery, left eye, 2019. Hypertension.'
  },
  clinical: {
    slitLampFindings: 'Mild stromal haze centrally. Pseudophakic.',
    epithelialStatus: 'Small central defect, 0.8 mm',
    stromalClarity: 'Mild haze',
    endothelialFolds: 'Moderate folds',
    arcusSenilis: 'Peripheral, 1.8 mm',
    storageMedium: 'Optisol-GS',
    storageTemperatureC: 4,
    preservationDate: '2026-08-16',
    referenceEcd: null,
    observedBy: 'S. Jayasuriya (Technician)',
    observationNotes: 'Prior intraocular surgery recorded. Recapture of endothelial image requested.'
  },
  image: {
    fileName: 'NEB-000124-EN-01.tif',
    uploadedAt: '2026-08-16T14:04:00',
    uploadStatus: 'Uploaded',
    qualityLabel: 'Insufficient',
    qualityNote:
    'Placeholder quality label — uneven illumination and focus loss reported by the technician at capture.',
    previewUrl: ENDOTHELIAL_IMAGES.degraded,
    magnification: '×200 specular',
    captureDevice: 'Specular microscope (bench unit 1)'
  },
  modules: case124Modules,
  reviewStatus: 'Awaiting Information',
  assignedReviewer: 'Dr. A. Perera',
  lastUpdated: '2026-08-16T14:26:00',
  createdBy: 'S. Jayasuriya (Technician)',
  createdAt: '2026-08-16T13:40:00',
  transplant: {
    intent: 'Not allocated',
    recipientRef: null,
    procedure: null,
    surgeryDate: null,
    surgeon: null
  },
  followUp: emptyFollowUp(),
  specialistDecision: null,
  notes: [
  {
    id: 'n-124-1',
    author: 'Dr. A. Perera',
    createdAt: '2026-08-16T16:10:00',
    body: 'Do not proceed on the tabular-only grade prediction. Recapture the endothelial image before review.'
  }]

},
{
  caseId: 'NEB-2026-000125',
  donor: {
    donorId: 'DNR-2026-0118',
    age: 41,
    sex: 'Male',
    collectionDate: '2026-02-09',
    eye: 'Right (OD)',
    causeOfDeath: 'Road traffic accident (non-ocular)',
    deathToPreservationHours: 6,
    serology: 'Non-reactive (HIV, HBV, HCV, Syphilis)',
    relevantHistory: 'No ocular history recorded. No systemic disease reported.'
  },
  clinical: {
    slitLampFindings: 'Clear cornea, no abnormality detected.',
    epithelialStatus: 'Intact',
    stromalClarity: 'Clear',
    endothelialFolds: 'None',
    arcusSenilis: 'None',
    storageMedium: 'Optisol-GS',
    storageTemperatureC: 4,
    preservationDate: '2026-02-09',
    referenceEcd: 2750,
    observedBy: 'K. Fernando (Technician)',
    observationNotes: 'Short death-to-preservation interval. Tissue in excellent condition at intake.'
  },
  image: {
    fileName: 'NEB-000125-EN-01.tif',
    uploadedAt: '2026-02-10T08:55:00',
    uploadStatus: 'Uploaded',
    qualityLabel: 'Good',
    qualityNote: 'Placeholder quality label — automated image quality scoring is not connected.',
    previewUrl: ENDOTHELIAL_IMAGES.regular,
    magnification: '×200 specular',
    captureDevice: 'Specular microscope (bench unit 2)'
  },
  modules: case125Modules,
  reviewStatus: 'Specialist Reviewed',
  assignedReviewer: 'Dr. N. Wickramasinghe',
  lastUpdated: '2026-08-13T11:02:00',
  createdBy: 'K. Fernando (Technician)',
  createdAt: '2026-02-10T08:30:00',
  transplant: {
    intent: 'Transplanted',
    recipientRef: 'RCP-2026-0087',
    procedure: 'DSAEK',
    surgeryDate: '2026-02-14',
    surgeon: 'Dr. N. Wickramasinghe'
  },
  followUp: followUp125,
  specialistDecision: {
    outcome: 'Released for transplantation',
    decidedBy: 'Dr. N. Wickramasinghe',
    decidedAt: '2026-02-11T08:40:00',
    rationale:
    'Donor and clinical findings unremarkable, reference ECD consistent with cellular analysis. AI-supported assessment reviewed and agreed.'
  },
  notes: [
  {
    id: 'n-125-1',
    author: 'Dr. N. Wickramasinghe',
    createdAt: '2026-08-13T11:10:00',
    body: '6-month graft assessment clear. Continue scheduled monitoring to 1 year.'
  }]

},
{
  caseId: 'NEB-2026-000126',
  donor: {
    donorId: 'DNR-2026-0453',
    age: 29,
    sex: 'Female',
    collectionDate: '2026-08-17',
    eye: 'Left (OS)',
    causeOfDeath: 'Drowning',
    deathToPreservationHours: 11,
    serology: 'Pending',
    relevantHistory: 'No ocular history recorded.'
  },
  clinical: {
    slitLampFindings: 'Not yet recorded',
    epithelialStatus: 'Not yet recorded',
    stromalClarity: 'Not yet recorded',
    endothelialFolds: 'Not yet recorded',
    arcusSenilis: 'None',
    storageMedium: 'Optisol-GS',
    storageTemperatureC: 4,
    preservationDate: '2026-08-17',
    referenceEcd: null,
    observedBy: 'S. Jayasuriya (Technician)',
    observationNotes: 'Case opened at intake. Clinical assessment pending bench availability.'
  },
  image: {
    fileName: '—',
    uploadedAt: '',
    uploadStatus: 'Not uploaded',
    qualityLabel: null,
    qualityNote: 'No endothelial image has been uploaded for this case.',
    previewUrl: null,
    magnification: null,
    captureDevice: null
  },
  modules: {
    [MODULE_IDS.cellular]: emptyModuleResult(MODULE_IDS.cellular, {
      missingInputs: ['Endothelial image']
    }),
    [MODULE_IDS.grade]: emptyModuleResult(MODULE_IDS.grade, {
      missingInputs: ['Clinical observations', 'Endothelial image']
    }),
    [MODULE_IDS.disease]: emptyModuleResult(MODULE_IDS.disease, {
      missingInputs: ['Endothelial image', 'Clinical observations']
    }),
    [MODULE_IDS.decision]: emptyModuleResult(MODULE_IDS.decision),
    [MODULE_IDS.followUp]: emptyModuleResult(MODULE_IDS.followUp, {
      statusNote: 'Case has not proceeded to transplantation.'
    })
  },
  reviewStatus: 'Awaiting Information',
  assignedReviewer: null,
  lastUpdated: '2026-08-17T11:15:00',
  createdBy: 'S. Jayasuriya (Technician)',
  createdAt: '2026-08-17T11:15:00',
  transplant: {
    intent: 'Not allocated',
    recipientRef: null,
    procedure: null,
    surgeryDate: null,
    surgeon: null
  },
  followUp: emptyFollowUp(),
  specialistDecision: null,
  notes: []
},
{
  caseId: 'NEB-2026-000127',
  donor: {
    donorId: 'DNR-2026-0454',
    age: 60,
    sex: 'Male',
    collectionDate: '2026-08-17',
    eye: 'Right (OD)',
    causeOfDeath: 'Respiratory failure',
    deathToPreservationHours: 12.5,
    serology: 'Non-reactive (HIV, HBV, HCV, Syphilis)',
    relevantHistory: 'Pterygium excision, right eye, 2015.'
  },
  clinical: {
    slitLampFindings: 'Peripheral nasal scarring from prior excision. Central cornea clear.',
    epithelialStatus: 'Intact',
    stromalClarity: 'Clear centrally',
    endothelialFolds: 'Mild',
    arcusSenilis: 'Peripheral, 1.2 mm',
    storageMedium: 'Optisol-GS',
    storageTemperatureC: 4,
    preservationDate: '2026-08-17',
    referenceEcd: 2400,
    observedBy: 'K. Fernando (Technician)',
    observationNotes: 'Scar located outside intended graft zone.'
  },
  image: {
    fileName: 'NEB-000127-EN-01.tif',
    uploadedAt: '2026-08-17T11:44:00',
    uploadStatus: 'Uploaded',
    qualityLabel: 'Pending assessment',
    qualityNote: 'Placeholder quality label — automated image quality scoring is not connected.',
    previewUrl: ENDOTHELIAL_IMAGES.moderate,
    magnification: '×200 specular',
    captureDevice: 'Specular microscope (bench unit 1)'
  },
  modules: case127Modules,
  reviewStatus: 'Under Review',
  assignedReviewer: 'Dr. A. Perera',
  lastUpdated: '2026-08-17T11:48:00',
  createdBy: 'K. Fernando (Technician)',
  createdAt: '2026-08-17T11:30:00',
  transplant: {
    intent: 'Not allocated',
    recipientRef: null,
    procedure: null,
    surgeryDate: null,
    surgeon: null
  },
  followUp: emptyFollowUp(),
  specialistDecision: null,
  notes: []
},
{
  caseId: 'NEB-2026-000128',
  donor: {
    donorId: 'DNR-2026-0430',
    age: 74,
    sex: 'Female',
    collectionDate: '2026-08-11',
    eye: 'Left (OS)',
    causeOfDeath: 'Renal failure',
    deathToPreservationHours: 18,
    serology: 'Non-reactive (HIV, HBV, HCV, Syphilis)',
    relevantHistory: 'Long-standing glaucoma, topical treatment. Cataract surgery 2016.'
  },
  clinical: {
    slitLampFindings: 'Central stromal oedema. Guttata suspected on retroillumination.',
    epithelialStatus: 'Microcystic change centrally',
    stromalClarity: 'Reduced — central oedema',
    endothelialFolds: 'Marked',
    arcusSenilis: 'Peripheral, 2.2 mm',
    storageMedium: 'Optisol-GS',
    storageTemperatureC: 4,
    preservationDate: '2026-08-12',
    referenceEcd: 1900,
    observedBy: 'S. Jayasuriya (Technician)',
    observationNotes: 'Extended death-to-preservation interval. Oedema present at intake.'
  },
  image: {
    fileName: 'NEB-000128-EN-01.tif',
    uploadedAt: '2026-08-12T15:30:00',
    uploadStatus: 'Uploaded',
    qualityLabel: 'Acceptable',
    qualityNote: 'Placeholder quality label — automated image quality scoring is not connected.',
    previewUrl: ENDOTHELIAL_IMAGES.sparse,
    magnification: '×200 specular',
    captureDevice: 'Specular microscope (bench unit 2)'
  },
  modules: case128Modules,
  reviewStatus: 'Specialist Reviewed',
  assignedReviewer: 'Dr. N. Wickramasinghe',
  lastUpdated: '2026-08-13T09:14:00',
  createdBy: 'S. Jayasuriya (Technician)',
  createdAt: '2026-08-12T15:10:00',
  transplant: {
    intent: 'Withheld from allocation',
    recipientRef: null,
    procedure: null,
    surgeryDate: null,
    surgeon: null
  },
  followUp: emptyFollowUp(),
  specialistDecision: {
    outcome: 'Withheld from allocation — specialist decision',
    decidedBy: 'Dr. N. Wickramasinghe',
    decidedAt: '2026-08-13T09:10:00',
    rationale:
    'Reference ECD and cellular measurements below eye-bank threshold with central oedema on slit lamp. Decision made on clinical grounds; AI-supported assessment reviewed as one input.'
  },
  notes: [
  {
    id: 'n-128-1',
    author: 'Dr. N. Wickramasinghe',
    createdAt: '2026-08-13T09:12:00',
    body: 'Consider retaining for research use subject to consent records.'
  }]

}];


export const demoAuditLog: AuditEntry[] = [
{ id: 'a1', timestamp: '2026-08-17T11:48:00', caseId: 'NEB-2026-000127', module: 'Cellular Intelligence', action: 'Analysis started', status: 'Running', user: 'K. Fernando', resultVersion: null },
{ id: 'a2', timestamp: '2026-08-17T11:30:00', caseId: 'NEB-2026-000127', module: 'Case Management', action: 'Case created', status: 'Completed', user: 'K. Fernando', resultVersion: null },
{ id: 'a3', timestamp: '2026-08-17T11:15:00', caseId: 'NEB-2026-000126', module: 'Case Management', action: 'Case created', status: 'Completed', user: 'S. Jayasuriya', resultVersion: null },
{ id: 'a4', timestamp: '2026-08-17T10:41:00', caseId: 'NEB-2026-000123', module: 'Transplant Decision Support', action: 'Evidence consolidated', status: 'Needs Review', user: 'System', resultVersion: 'demo-fixture' },
{ id: 'a5', timestamp: '2026-08-17T10:36:00', caseId: 'NEB-2026-000123', module: 'Disease Intelligence', action: 'Analysis completed — flagged for review', status: 'Needs Review', user: 'System', resultVersion: 'demo-fixture' },
{ id: 'a6', timestamp: '2026-08-17T10:34:00', caseId: 'NEB-2026-000123', module: 'Expert Grade Prediction', action: 'Analysis completed', status: 'Completed', user: 'System', resultVersion: 'demo-fixture' },
{ id: 'a7', timestamp: '2026-08-17T10:30:00', caseId: 'NEB-2026-000123', module: 'Cellular Intelligence', action: 'Analysis completed', status: 'Completed', user: 'System', resultVersion: 'demo-fixture' },
{ id: 'a8', timestamp: '2026-08-17T10:22:00', caseId: 'NEB-2026-000123', module: 'Endothelial Image', action: 'Image uploaded', status: 'Completed', user: 'K. Fernando', resultVersion: null },
{ id: 'a9', timestamp: '2026-08-16T16:10:00', caseId: 'NEB-2026-000124', module: 'Specialist Review', action: 'Clinical note added', status: 'Completed', user: 'Dr. A. Perera', resultVersion: null },
{ id: 'a10', timestamp: '2026-08-16T14:26:00', caseId: 'NEB-2026-000124', module: 'Cellular Intelligence', action: 'Measurements withheld — image quality insufficient', status: 'Needs Review', user: 'System', resultVersion: 'demo-fixture' },
{ id: 'a11', timestamp: '2026-08-16T14:20:00', caseId: 'NEB-2026-000124', module: 'Expert Grade Prediction', action: 'Analysis completed on partial inputs', status: 'Completed', user: 'System', resultVersion: 'demo-fixture' },
{ id: 'a12', timestamp: '2026-08-13T11:02:00', caseId: 'NEB-2026-000125', module: 'Post-Transplant Follow-up Monitoring', action: '6-month measurements recorded', status: 'Completed', user: 'Dr. N. Wickramasinghe', resultVersion: 'demo-fixture' },
{ id: 'a13', timestamp: '2026-08-13T09:14:00', caseId: 'NEB-2026-000128', module: 'Specialist Review', action: 'Specialist decision recorded', status: 'Completed', user: 'Dr. N. Wickramasinghe', resultVersion: null },
{ id: 'a14', timestamp: '2026-08-13T09:02:00', caseId: 'NEB-2026-000128', module: 'Transplant Decision Support', action: 'Evidence consolidated', status: 'Completed', user: 'System', resultVersion: 'demo-fixture' },
{ id: 'a15', timestamp: '2026-08-12T15:48:00', caseId: 'NEB-2026-000128', module: 'Disease Intelligence', action: 'Analysis completed', status: 'Completed', user: 'System', resultVersion: 'demo-fixture' },
{ id: 'a16', timestamp: '2026-08-12T15:30:00', caseId: 'NEB-2026-000128', module: 'Endothelial Image', action: 'Image uploaded', status: 'Completed', user: 'S. Jayasuriya', resultVersion: null },
{ id: 'a17', timestamp: '2026-02-11T08:40:00', caseId: 'NEB-2026-000125', module: 'Specialist Review', action: 'Specialist decision recorded', status: 'Completed', user: 'Dr. N. Wickramasinghe', resultVersion: null }];


export const REVIEWERS = ['Dr. A. Perera', 'Dr. N. Wickramasinghe', 'Dr. M. Silva'];