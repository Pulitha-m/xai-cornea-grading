import type { Role, RoleProfile, StaffUser } from '../types/user';

export const ROLE_PROFILES: RoleProfile[] = [
  {
    role: 'Admin',
    label: 'Administrator',
    title: 'National Eye Bank System Administrator',
    summary: 'Oversees multi-branch operations, staff permissions, audit logs, system & AI configuration.',
    scope: ['All branches access', 'User & staff management', 'System audit logs', 'Global reporting'],
  },
  {
    role: 'Manager',
    label: 'Branch Manager',
    title: 'NEBSL Branch Manager & Operations Director',
    summary: 'Oversees branch operations, staff task coordination, inventory, recipient waiting lists, and transfers.',
    scope: ['Branch operations oversight', 'Tissue inventory & transfers', 'Staff task allocation', 'Transplant planning'],
  },
  {
    role: 'Doctor',
    label: 'Ophthalmic Surgeon & Doctor',
    title: 'Eye Bank Clinical Director & Ophthalmic Surgeon',
    summary: 'Evaluates donor corneas, reviews specular AI & CHI data, performs recipient matching & clinical decisions.',
    scope: ['Clinical review sign-off', 'AI explainability & CHI review', 'Donor-recipient matching', 'Post-transplant follow-up'],
  },
  {
    role: 'Nurse',
    label: 'Nurse / Technician',
    title: 'Senior Eye Bank Nurse & Clinical Technician',
    summary: 'Handles donor intake, tissue collection, specular microscopy imaging, quality check, and processing.',
    scope: ['Donor intake registration', 'Specular image upload', 'Quality check verification', 'Tissue preparation'],
  },
  {
    role: 'Attendant',
    label: 'Attendant / Support Staff',
    title: 'Eye Bank Logistics & Support Attendant',
    summary: 'Executes operational logistics: tissue transport, storage movement, delivery confirmations, and supplies.',
    scope: ['Transport container prep', 'Storage tissue movement', 'Delivery confirmation', 'Simple touch task UI'],
  },
];

export const DEMO_STAFF: Record<Role, StaffUser> = {
  Admin: {
    staffId: 'NEB-A-3011',
    name: 'R. Gunasekara',
    role: 'Admin',
    branch: 'Colombo',
    allowedBranches: ['Colombo', 'Kandy', 'Kurunegala'],
    title: 'National System Administrator',
    displayName: 'R. Gunasekara (Administrator)',
  },
  Manager: {
    staffId: 'NEB-M-2010',
    name: 'H. Jayawardena',
    role: 'Manager',
    branch: 'Colombo',
    allowedBranches: ['Colombo', 'Kandy', 'Kurunegala'],
    title: 'Colombo Branch Manager',
    displayName: 'H. Jayawardena (Manager)',
  },
  Doctor: {
    staffId: 'NEB-S-2087',
    name: 'Dr. A. Perera',
    role: 'Doctor',
    branch: 'Colombo',
    allowedBranches: ['Colombo', 'Kandy'],
    title: 'Consultant Ophthalmic Surgeon',
    displayName: 'Dr. A. Perera (Doctor)',
  },
  Nurse: {
    staffId: 'NEB-T-1042',
    name: 'K. Fernando',
    role: 'Nurse',
    branch: 'Kandy',
    allowedBranches: ['Kandy'],
    title: 'Senior Eye-Bank Nurse & Technician',
    displayName: 'K. Fernando (Nurse/Tech)',
  },
  Attendant: {
    staffId: 'NEB-ATT-409',
    name: 'S. Bandara',
    role: 'Attendant',
    branch: 'Colombo',
    allowedBranches: ['Colombo'],
    title: 'Logistics & Support Attendant',
    displayName: 'S. Bandara (Attendant)',
  },
};

export function getRoleProfile(role: Role): RoleProfile {
  return ROLE_PROFILES.find((profile) => profile.role === role) ?? ROLE_PROFILES[0];
}