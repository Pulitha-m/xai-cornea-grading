import type { Branch } from "../types/user";
import type { RecipientProfile } from "../types/case";

export interface AvailableCorneaFixture {
  corneaId: string;
  donorCaseId: string;
  branch: Branch;
  grade: "A+" | "A" | "B";
  ecd: number;
  cv: number;
  hex: number;
  diseaseScreen: string;
  chi: number;
  historicalEvidence: string;
  suitability: "Suitable" | "Marginal";
}

export interface MatchingFixture extends RecipientProfile {
  matchStatus: "Ready for comparison" | "Proposed to Doctor" | "Approved for allocation" | "Needs clinical review";
  evidence: { label: string; value: string; weight: number }[];
  nurseAction: string;
  doctorAction: string;
  allocationAction: string;
  severity?: string;
  clinicalCondition?: string;
  previousTransplant?: string;
  requiredGraft?: string;
  registrationDate?: string;
}

export interface FollowUpFixture {
  caseId: string;
  recipientName: string;
  surgeon: string;
  surgeryDate: string;
  branch: Branch;
  visitLabel: "1 month" | "3 months" | "6 months" | "1 year";
  baselineEcd: number;
  currentEcd: number;
  ecdLossPercent: number;
  currentCv: number;
  currentHex: number;
  graftHealth: "Optimal" | "Stable" | "Caution" | "Rejection Risk";
  status: "Due" | "Completed" | "Overdue";
  imageStatus: "Uploaded" | "Pending";
  observations: string;
}

export const RECIPIENT_MATCHING_FIXTURES: MatchingFixture[] = [
  {
    recipientId: "REC-2026-041",
    name: "S. K. Perera",
    age: 58,
    sex: "Male",
    diagnosis: "Pseudophakic Bullous Keratopathy (PBK)",
    urgency: "Emergency",
    bloodType: "O positive",
    assignedBranch: "Colombo",
    status: "Waiting List",
    matchScore: 96.4,
    matchedCaseId: "NEB-2026-00125",
    matchStatus: "Ready for comparison",
    evidence: [
      { label: "ECD reserve", value: "2,840 cells/mm²", weight: 30 },
      { label: "Disease fit", value: "Clear screen for PBK", weight: 25 },
      { label: "Urgency", value: "Emergency priority", weight: 25 },
      { label: "Preservation", value: "31 hours", weight: 20 },
    ],
    nurseAction: "Compare evidence and propose donor match",
    doctorAction: "Review clinical compatibility and approve or reject",
    allocationAction: "Reserve tissue and schedule transplant",
  },
  {
    recipientId: "REC-2026-039",
    name: "M. F. Nishtar",
    age: 34,
    sex: "Female",
    diagnosis: "Advanced Keratoconus (Post-Hydrops)",
    urgency: "High",
    bloodType: "A positive",
    assignedBranch: "Colombo",
    status: "Donor Match Proposed",
    matchScore: 92.1,
    matchedCaseId: "NEB-2026-00124",
    matchStatus: "Proposed to Doctor",
    evidence: [
      { label: "ECD reserve", value: "2,710 cells/mm²", weight: 28 },
      { label: "Disease fit", value: "Clear screen for keratoconus", weight: 27 },
      { label: "Urgency", value: "High priority", weight: 25 },
      { label: "Preservation", value: "28 hours", weight: 20 },
    ],
    nurseAction: "Proposal sent; await Doctor review",
    doctorAction: "Review proposal and record clinical rationale",
    allocationAction: "Pending Doctor approval",
  },
  {
    recipientId: "REC-2026-035",
    name: "W. M. Herath",
    age: 67,
    sex: "Male",
    diagnosis: "Fuchs Endothelial Corneal Dystrophy",
    urgency: "Normal",
    bloodType: "B positive",
    assignedBranch: "Kandy",
    status: "Eligible",
    matchScore: 88.7,
    matchedCaseId: "NEB-2026-00123",
    matchStatus: "Needs clinical review",
    evidence: [
      { label: "ECD reserve", value: "2,180 cells/mm²", weight: 20 },
      { label: "Disease fit", value: "Review required", weight: 25 },
      { label: "Urgency", value: "Normal priority", weight: 20 },
      { label: "Preservation", value: "42 hours", weight: 15 },
    ],
    nurseAction: "Flag marginal tissue for Doctor review",
    doctorAction: "Assess risk before accepting marginal tissue",
    allocationAction: "Blocked until clinical decision",
  },
  {
    recipientId: "REC-2026-028",
    name: "D. M. Jayasinghe",
    age: 42,
    sex: "Female",
    diagnosis: "Corneal Stromal Dystrophy (Granular)",
    urgency: "Normal",
    bloodType: "AB positive",
    assignedBranch: "Kurunegala",
    status: "Transplant Scheduled",
    matchedCaseId: "NEB-2026-00120",
    matchStatus: "Approved for allocation",
    evidence: [
      { label: "ECD reserve", value: "2,750 cells/mm²", weight: 32 },
      { label: "Disease fit", value: "Suitable for graft", weight: 28 },
      { label: "Urgency", value: "Normal priority", weight: 18 },
      { label: "Preservation", value: "24 hours", weight: 22 },
    ],
    nurseAction: "Monitor scheduled transplant handoff",
    doctorAction: "Clinical approval recorded",
    allocationAction: "Manager schedules transplant",
  },
];

export const AVAILABLE_CORNEA_FIXTURES: AvailableCorneaFixture[] = [
  { corneaId: "COR-2026-125-R", donorCaseId: "NEB-2026-00125", branch: "Colombo", grade: "A+", ecd: 2840, cv: 29, hex: 68, chi: 84, diseaseScreen: "Clear", historicalEvidence: "90% stable 1-year graft trajectory", suitability: "Suitable" },
  { corneaId: "COR-2026-124-L", donorCaseId: "NEB-2026-00124", branch: "Colombo", grade: "A", ecd: 2710, cv: 32, hex: 63, chi: 77, diseaseScreen: "Clear", historicalEvidence: "84% stable 1-year graft trajectory", suitability: "Suitable" },
  { corneaId: "COR-2026-123-R", donorCaseId: "NEB-2026-00123", branch: "Kandy", grade: "B", ecd: 2180, cv: 38, hex: 55, chi: 61, diseaseScreen: "Review required", historicalEvidence: "72% comparable outcome confidence", suitability: "Marginal" },
];

export const POST_TRANSPLANT_FIXTURES: FollowUpFixture[] = [
  {
    caseId: "NEB-2026-00120",
    recipientName: "D. M. Jayasinghe",
    surgeon: "Dr. A. Perera",
    surgeryDate: "2026-07-20",
    branch: "Colombo",
    visitLabel: "1 month",
    baselineEcd: 2750,
    currentEcd: 2610,
    ecdLossPercent: 5.1,
    currentCv: 31,
    currentHex: 62,
    graftHealth: "Optimal",
    status: "Completed",
    imageStatus: "Uploaded",
    observations: "Clear graft, no rejection indicators.",
  },
  {
    caseId: "NEB-2026-00118",
    recipientName: "K. L. Wickramasinghe",
    surgeon: "Dr. S. Wijesinghe",
    surgeryDate: "2026-05-15",
    branch: "Kandy",
    visitLabel: "3 months",
    baselineEcd: 2680,
    currentEcd: 2380,
    ecdLossPercent: 11.2,
    currentCv: 35,
    currentHex: 56,
    graftHealth: "Stable",
    status: "Completed",
    imageStatus: "Uploaded",
    observations: "Expected cell loss; continue routine monitoring.",
  },
  {
    caseId: "NEB-2026-00115",
    recipientName: "P. N. Cooray",
    surgeon: "Dr. A. Perera",
    surgeryDate: "2025-08-10",
    branch: "Colombo",
    visitLabel: "1 year",
    baselineEcd: 2800,
    currentEcd: 1950,
    ecdLossPercent: 30.3,
    currentCv: 44,
    currentHex: 42,
    graftHealth: "Caution",
    status: "Due",
    imageStatus: "Pending",
    observations: "Trajectory deviation requires Doctor review.",
  },
  {
    caseId: "NEB-2026-00112",
    recipientName: "N. R. Silva",
    surgeon: "Dr. S. Wijesinghe",
    surgeryDate: "2025-02-12",
    branch: "Kandy",
    visitLabel: "1 year",
    baselineEcd: 2890,
    currentEcd: 1680,
    ecdLossPercent: 41.9,
    currentCv: 49,
    currentHex: 38,
    graftHealth: "Rejection Risk",
    status: "Overdue",
    imageStatus: "Pending",
    observations: "AI anomaly alert: rapid endothelial decline.",
  },
];
