/**
 * MODULE REGISTRY
 *
 * Each AI research component registers itself here with metadata only. The
 * shared case-management UI renders every registered module generically, so a
 * new research module can be added by (1) appending an entry here and
 * (2) optionally registering a detail panel in components/modules/registry.tsx.
 *
 * Nothing in the core application hard-codes one module as the upstream
 * dependency of another. The shared Case ID is the only connection.
 */

export interface ModuleDefinition {
  id: string;
  name: string;
  /** Short statement of what the module is for. */
  purpose: string;
  /** Owning research workstream, shown in module metadata. */
  owner: string;
  /** Inputs the module expects from the shared case record. */
  expectedInputs: string[];
  /** Output fields the module publishes back to the case. */
  expectedOutputs: string[];
  /** Explanation methods the module intends to expose. */
  explanationMethods: string[];
  /** Whether a real model endpoint is connected in this prototype. */
  modelConnected: boolean;
  order: number;
}

export const MODULE_IDS = {
  cellular: "cellular-intelligence",
  grade: "expert-grade",
  disease: "disease-intelligence",
  decision: "decision-support",
  followUp: "followup-monitoring",
} as const;

export const moduleRegistry: ModuleDefinition[] = [
  {
    id: MODULE_IDS.cellular,
    name: "Cellular Intelligence",
    purpose: "Automated endothelial cellular analysis from specular microscopy images.",
    owner: "Research workstream 1",
    expectedInputs: ["Endothelial image", "Image capture metadata"],
    expectedOutputs: ["ECD", "CV", "HEX", "Mean cell area", "Compactness", "Analysis quality"],

    explanationMethods: ["ROI overlay", "Cell detection overlay", "Per-cell measurement table"],
    modelConnected: false,
    order: 1,
  },
  {
    id: MODULE_IDS.grade,
    name: "Expert Grade Prediction",
    purpose: "Predicts the eye-bank donor cornea grade (A+, A, B) for specialist review.",
    owner: "Research workstream 2",
    expectedInputs: ["Donor information", "Clinical observations", "Endothelial image", "Cellular biomarkers (optional)"],

    expectedOutputs: ["Predicted grade", "Confidence", "Contributing factors"],
    explanationMethods: ["SHAP", "Grad-CAM", "Feature importance", "Image explanation"],
    modelConnected: false,
    order: 2,
  },
  {
    id: MODULE_IDS.disease,
    name: "Disease Intelligence",
    purpose: "Assesses disease indicators and derives a Corneal Health Index (CHI).",
    owner: "Research workstream 3",
    expectedInputs: ["Endothelial image", "Clinical observations", "Donor history"],
    expectedOutputs: ["Disease assessment", "Severity", "Corneal Health Index (CHI)"],
    explanationMethods: ["Region attribution", "Indicator breakdown"],
    modelConnected: false,
    order: 3,
  },
];

export function getModuleDefinition(moduleId: string): ModuleDefinition | undefined {
  return moduleRegistry.find((m) => m.id === moduleId);
}

export function getModuleName(moduleId: string): string {
  return getModuleDefinition(moduleId)?.name ?? moduleId;
}

/**
 * Disease categories follow the research specification's category set. The set
 * is intentionally marked as provisional rather than invented per-case.
 */
export const DISEASE_CATEGORY_SET = ["No disease indicators detected", "Endothelial dystrophy indicators", "Corneal oedema", "Scarring / opacity", "Infective keratitis indicators", "Trauma-related change", "Indeterminate — insufficient evidence"];
