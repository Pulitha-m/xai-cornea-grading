import type { Branch, Role } from "./user";

export type DonorStatus = "Registered" | "Screened" | "Approved" | "Tissue Collected" | "Evaluation Pending" | "Evaluated" | "Available" | "Allocated" | "Transplanted" | "Closed";

export type CorneaStatus = "Collected" | "Processing" | "Image Pending" | "Image Uploaded" | "AI Analysis" | "Expert Review" | "Suitable" | "Marginal" | "Not Suitable" | "Available" | "Reserved" | "Allocated" | "Transplanted" | "Follow-up" | "Completed";

export type RecipientStatus = "Registered" | "Clinical Review" | "Eligible" | "Waiting List" | "Matching Pending" | "Donor Match Proposed" | "Doctor Review" | "Match Approved" | "Transplant Scheduled" | "Transplanted" | "Post-Transplant Monitoring";

export type TransplantStatus = "Planned" | "Scheduled" | "Prepared" | "In Progress" | "Completed" | "Post-Transplant Monitoring" | "Closed";

export type InventoryStatus = "Collected" | "Stored" | "Available" | "Reserved" | "Allocated" | "Transferred" | "Transplanted";

export type ModuleStatus = "Not Run" | "Running" | "Completed" | "Needs Review" | "Unavailable";

export type ReviewStatus = "Pending Review" | "Under Review" | "Specialist Reviewed" | "Awaiting Information";

export interface AuditEntry {
  id: string;
  timestamp: string;
  caseId: string;
  module: string;
  action: string;
  status: "Running" | "Completed" | "Needs Review" | "Unavailable" | "Failed";
  user: string;
  resultVersion: string | null;
}

export type CorneaGrade = "A+" | "A" | "B";

export type Provenance = "AI Prediction" | "AI Analysis" | "Reference Measurement" | "Specialist Assessment" | "Staff Entered";

export interface ModuleOutput {
  label: string;
  value: string | null;
  unit?: string;
  provenance: Provenance;
  reference?: string;
  note?: string;
}

export interface ModuleExplanation {
  available: boolean;
  methods: string[];
  note: string;
}

export interface ModuleResult {
  moduleId: string;
  status: ModuleStatus;
  lastRun: string | null;
  resultSummary: string | null;
  confidence: number | null;
  quality: string | null;
  outputs: ModuleOutput[];
  explanation: ModuleExplanation;
  version: string | null;
  inputsUsed: string[];
  missingInputs: string[];
  statusNote?: string;
}

export interface EndothelialImage {
  fileName: string;
  uploadedAt: string;
  uploadStatus: "Uploaded" | "Processing" | "Failed" | "Not uploaded";
  qualityLabel: string | null;
  qualityNote: string;
  previewUrl: string | null;
  magnification: string | null;
  captureDevice: string | null;
}

export interface DonorInformation {
  donorId: string;
  age: number;
  sex: "Male" | "Female";
  collectionDate: string;
  eye: "Right (OD)" | "Left (OS)";
  causeOfDeath: string;
  deathToPreservationHours: number | null;
  serology: string;
  relevantHistory: string;
  branch: Branch;
}

export interface ClinicalInformation {
  slitLampFindings: string;
  epithelialStatus: string;
  stromalClarity: string;
  endothelialFolds: string;
  arcusSenilis: string;
  storageMedium: string;
  storageTemperatureC: number | null;
  preservationDate: string;
  referenceEcd: number | null;
  observedBy: string;
  observationNotes: string;
}

export interface FollowUpPoint {
  label: "Baseline" | "1 month" | "3 months" | "6 months" | "1 year";
  date: string | null;
  ecd: number | null;
  cv: number | null;
  hex: number | null;
  graftHealth?: "Optimal" | "Stable" | "Caution" | "Rejection Risk";
  recorded: boolean;
  notes?: string;
}

export interface TransplantRecord {
  intent: "Not allocated" | "Allocated" | "Transplanted" | "Withheld from allocation";
  recipientRef: string | null;
  procedure: string | null;
  surgeryDate: string | null;
  surgeon: string | null;
  status: TransplantStatus;
}

export interface SpecialistDecision {
  outcome: "Suitable" | "Marginal" | "Not Suitable" | "Approved" | "Rejected" | "Further Review";
  decidedBy: string;
  decidedAt: string;
  rationale: string;
  signature: string;
}

export interface CaseOwnership {
  primaryOwner: string;
  currentRole: Role;
  currentUser: string;
  assignedBranch: Branch;
  nextAction: string;
}

export interface HandoffEntry {
  id: string;
  fromUser: string;
  toUser: string;
  fromRole: Role;
  toRole: Role;
  timestamp: string;
  branch: Branch;
  note: string;
}

export interface ClinicalNote {
  id: string;
  author: string;
  createdAt: string;
  body: string;
}

export interface RecipientProfile {
  recipientId: string;
  name: string;
  age: number;
  sex: "Male" | "Female";
  diagnosis: string;
  urgency: "Emergency" | "High" | "Normal";
  bloodType: string;
  assignedBranch: Branch;
  status: RecipientStatus;
  matchedCaseId?: string | null;
  matchScore?: number;
}

export interface BranchTransfer {
  transferId: string;
  caseId: string;
  corneaId: string;
  fromBranch: Branch;
  toBranch: Branch;
  requestedBy: string;
  approvedBy: string;
  transportStatus: "Requested" | "In Transit" | "Received" | "Completed";
  receivedBy: string | null;
  timestamp: string;
}

export interface DonorCase {
  caseId: string;
  branch: Branch;
  donorStatus: DonorStatus;
  corneaStatus: CorneaStatus;
  ownership: CaseOwnership;
  donor: DonorInformation;
  clinical: ClinicalInformation;
  image: EndothelialImage;
  modules: Record<string, ModuleResult>;
  reviewStatus: ReviewStatus;
  assignedReviewer: string | null;
  lastUpdated: string;
  createdBy: string;
  createdAt: string;
  transplant: TransplantRecord;
  followUp: FollowUpPoint[];
  specialistDecision: SpecialistDecision | null;
  notes: ClinicalNote[];
  handoffHistory: HandoffEntry[];
  matchedRecipientId?: string | null;
}
