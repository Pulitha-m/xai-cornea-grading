export type Role = 'Admin' | 'Manager' | 'Doctor' | 'Nurse' | 'Attendant';

export type Branch = 'Colombo' | 'Kandy' | 'Kurunegala';

export interface StaffUser {
  staffId: string;
  name: string;
  role: Role;
  branch: Branch;
  allowedBranches: Branch[];
  /** Role wording used in headers and audit entries, e.g. "Ophthalmic Surgeon & Specialist". */
  title: string;
  /** Name + role, written into audit entries and case records. */
  displayName: string;
}

export interface RoleProfile {
  role: Role;
  /** Label shown on the role card at sign-in. */
  label: string;
  title: string;
  summary: string;
  /** What this role is allowed to do, shown on the sign-in card. */
  scope: string[];
}