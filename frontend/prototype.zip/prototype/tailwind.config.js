export default {
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}'
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      colors: {
        canvas: '#f4f6f8',
        surface: '#ffffff',
        sunken: '#f8fafc',
        darkcard: '#1e293b',
        line: {
          DEFAULT: '#f1f5f9',
          strong: '#e2e8f0',
        },
        ink: {
          900: '#0f172a',
          700: '#334155',
          500: '#64748b',
          400: '#94a3b8',
        },
        accent: {
          50: '#f0f9ff',
          100: '#e0f2fe',
          200: '#bae6fd',
          500: '#0ea5e9',
          600: '#0284c7',
          700: '#0369a1',
          900: '#0c4a6e',
        },
        amber: {
          50: '#fefce8',
          100: '#fef9c3',
          200: '#fef08a',
          400: '#facc15',
          500: '#eab308',
          600: '#ca8a04',
          700: '#a16207',
        },
        ok: { 50: '#ecfdf5', 100: '#d1fae5', 200: '#a7f3d0', 600: '#059669', 700: '#047857' },
        warn: { 50: '#fffbeb', 100: '#fef3c7', 200: '#fde68a', 600: '#d97706', 700: '#b45309' },
        alert: { 50: '#fff1f2', 100: '#ffe4e6', 200: '#fecdd3', 600: '#e11d48', 700: '#be123c' },
      },
      fontSize: {
        '2xs': ['0.6875rem', { lineHeight: '1rem' }],
      },
      borderRadius: {
        '3xl': '1.5rem',
        '2xl': '1rem',
      },
      boxShadow: {
        bento: '0 4px 20px -2px rgba(15, 23, 42, 0.04), 0 2px 6px -1px rgba(15, 23, 42, 0.02)',
        card: '0 1px 3px rgba(15, 23, 42, 0.05)',
        pop: '0 12px 32px -4px rgba(15, 23, 42, 0.12)',
        glow: '0 0 20px -3px rgba(2, 132, 199, 0.25)',
      },
    },
  },
  plugins: [],
}

